package org.json.simple;

import java.io.IOException;
import java.io.Writer;

public interface JSONStreamAware {
  void writeJSONString(Writer paramWriter) throws IOException;
}


/* Location:              C:\Users\Administrator\Desktop\ShitClient\HayBale-1.0.1-b8.jar!\org\json\simple\JSONStreamAware.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */