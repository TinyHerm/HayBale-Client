package org.spongepowered.asm.lib.util;

import java.util.Map;
import org.spongepowered.asm.lib.Label;

public interface Textifiable {
  void textify(StringBuffer paramStringBuffer, Map<Label, String> paramMap);
}


/* Location:              C:\Users\Administrator\Desktop\ShitClient\HayBale-1.0.1-b8.jar!\org\spongepowered\asm\li\\util\Textifiable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */