package me.luxtix.haybale.mixin.mixins.accessors;

public interface ICPacketPlayer {
  void setOnGround(boolean paramBoolean);
  
  void setX(double paramDouble);
  
  void setY(double paramDouble);
  
  void setZ(double paramDouble);
  
  void setYaw(float paramFloat);
  
  void setPitch(float paramFloat);
}


/* Location:              C:\Users\Administrator\Desktop\ShitClient\HayBale-1.0.1-b8.jar!\me\luxtix\haybale\mixin\mixins\accessors\ICPacketPlayer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */