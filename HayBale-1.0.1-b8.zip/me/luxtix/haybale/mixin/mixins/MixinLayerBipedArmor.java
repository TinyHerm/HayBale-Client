/*    */ package me.luxtix.haybale.mixin.mixins;
/*    */ 
/*    */ import net.minecraft.client.model.ModelBiped;
/*    */ import net.minecraft.client.renderer.entity.RenderLivingBase;
/*    */ import net.minecraft.client.renderer.entity.layers.LayerArmorBase;
/*    */ import net.minecraft.client.renderer.entity.layers.LayerBipedArmor;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ 
/*    */ @Mixin({LayerBipedArmor.class})
/*    */ public abstract class MixinLayerBipedArmor
/*    */   extends LayerArmorBase<ModelBiped> {
/*    */   public MixinLayerBipedArmor(RenderLivingBase<?> rendererIn) {
/* 13 */     super(rendererIn);
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\ShitClient\HayBale-1.0.1-b8.jar!\me\luxtix\haybale\mixin\mixins\MixinLayerBipedArmor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */