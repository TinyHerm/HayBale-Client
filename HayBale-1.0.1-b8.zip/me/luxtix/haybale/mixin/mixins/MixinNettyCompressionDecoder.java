/*    */ package me.luxtix.haybale.mixin.mixins;
/*    */ 
/*    */ import me.luxtix.haybale.features.modules.misc.Bypass;
/*    */ import net.minecraft.network.NettyCompressionDecoder;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.Constant;
/*    */ import org.spongepowered.asm.mixin.injection.ModifyConstant;
/*    */ 
/*    */ @Mixin({NettyCompressionDecoder.class})
/*    */ public abstract class MixinNettyCompressionDecoder {
/*    */   @ModifyConstant(method = {"decode"}, constant = {@Constant(intValue = 2097152)})
/*    */   private int decodeHook(int n) {
/* 13 */     if (Bypass.getInstance().isOn() && ((Boolean)(Bypass.getInstance()).packets.getValue()).booleanValue() && ((Boolean)(Bypass.getInstance()).noLimit.getValue()).booleanValue()) {
/* 14 */       return Integer.MAX_VALUE;
/*    */     }
/* 16 */     return n;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\ShitClient\HayBale-1.0.1-b8.jar!\me\luxtix\haybale\mixin\mixins\MixinNettyCompressionDecoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */