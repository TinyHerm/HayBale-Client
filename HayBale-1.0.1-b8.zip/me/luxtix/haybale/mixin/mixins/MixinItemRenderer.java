/*    */ package me.luxtix.haybale.mixin.mixins;
/*    */ 
/*    */ import me.luxtix.haybale.features.modules.render.NoRender;
/*    */ import me.luxtix.haybale.features.modules.render.SmallShield;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.entity.AbstractClientPlayer;
/*    */ import net.minecraft.client.renderer.GlStateManager;
/*    */ import net.minecraft.client.renderer.ItemRenderer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.EnumHand;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.Redirect;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ @Mixin({ItemRenderer.class})
/*    */ public abstract class MixinItemRenderer {
/*    */   private boolean injection = true;
/*    */   
/*    */   @Shadow
/*    */   public abstract void func_187457_a(AbstractClientPlayer paramAbstractClientPlayer, float paramFloat1, float paramFloat2, EnumHand paramEnumHand, float paramFloat3, ItemStack paramItemStack, float paramFloat4);
/*    */   
/*    */   @Inject(method = {"renderItemInFirstPerson(Lnet/minecraft/client/entity/AbstractClientPlayer;FFLnet/minecraft/util/EnumHand;FLnet/minecraft/item/ItemStack;F)V"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void renderItemInFirstPersonHook(AbstractClientPlayer player, float p_187457_2_, float p_187457_3_, EnumHand hand, float p_187457_5_, ItemStack stack, float p_187457_7_, CallbackInfo info) {
/* 27 */     if (this.injection) {
/* 28 */       info.cancel();
/* 29 */       SmallShield offset = SmallShield.getINSTANCE();
/* 30 */       float xOffset = 0.0F;
/* 31 */       float yOffset = 0.0F;
/* 32 */       this.injection = false;
/* 33 */       if (hand == EnumHand.MAIN_HAND) {
/* 34 */         if (offset.isOn() && player.func_184614_ca() != ItemStack.field_190927_a) {
/* 35 */           xOffset = ((Float)offset.mainX.getValue()).floatValue();
/* 36 */           yOffset = ((Float)offset.mainY.getValue()).floatValue();
/*    */         } 
/* 38 */       } else if (!((Boolean)offset.normalOffset.getValue()).booleanValue() && offset.isOn() && player.func_184592_cb() != ItemStack.field_190927_a) {
/* 39 */         xOffset = ((Float)offset.offX.getValue()).floatValue();
/* 40 */         yOffset = ((Float)offset.offY.getValue()).floatValue();
/*    */       } 
/* 42 */       func_187457_a(player, p_187457_2_, p_187457_3_, hand, p_187457_5_ + xOffset, stack, p_187457_7_ + yOffset);
/* 43 */       this.injection = true;
/*    */     } 
/*    */   }
/*    */   
/*    */   @Redirect(method = {"renderArmFirstPerson"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/GlStateManager;translate(FFF)V", ordinal = 0))
/*    */   public void translateHook(float x, float y, float z) {
/* 49 */     SmallShield offset = SmallShield.getINSTANCE();
/* 50 */     boolean shiftPos = ((Minecraft.func_71410_x()).field_71439_g != null && (Minecraft.func_71410_x()).field_71439_g.func_184614_ca() != ItemStack.field_190927_a && offset.isOn());
/* 51 */     GlStateManager.func_179109_b(x + (shiftPos ? ((Float)offset.mainX.getValue()).floatValue() : 0.0F), y + (shiftPos ? ((Float)offset.mainY.getValue()).floatValue() : 0.0F), z);
/*    */   }
/*    */   
/*    */   @Inject(method = {"renderFireInFirstPerson"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void renderFireInFirstPersonHook(CallbackInfo info) {
/* 56 */     if (NoRender.getInstance().isOn() && ((Boolean)(NoRender.getInstance()).fire.getValue()).booleanValue()) {
/* 57 */       info.cancel();
/*    */     }
/*    */   }
/*    */   
/*    */   @Inject(method = {"renderSuffocationOverlay"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void renderSuffocationOverlay(CallbackInfo ci) {
/* 63 */     if (NoRender.getInstance().isOn() && ((Boolean)(NoRender.getInstance()).blocks.getValue()).booleanValue())
/* 64 */       ci.cancel(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\ShitClient\HayBale-1.0.1-b8.jar!\me\luxtix\haybale\mixin\mixins\MixinItemRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */