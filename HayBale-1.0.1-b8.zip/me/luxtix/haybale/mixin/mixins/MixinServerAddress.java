/*    */ package me.luxtix.haybale.mixin.mixins;
/*    */ 
/*    */ import me.luxtix.haybale.features.modules.client.ServerModule;
/*    */ import me.luxtix.haybale.mixin.mixins.accessors.IServerAddress;
/*    */ import net.minecraft.client.multiplayer.ServerAddress;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Redirect;
/*    */ 
/*    */ @Mixin({ServerAddress.class})
/*    */ public abstract class MixinServerAddress {
/*    */   @Redirect(method = {"fromString"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/multiplayer/ServerAddress;getServerAddress(Ljava/lang/String;)[Ljava/lang/String;"))
/*    */   private static String[] getServerAddressHook(String ip) {
/*    */     ServerModule module;
/*    */     int port;
/* 16 */     if (ip.equals((ServerModule.getInstance()).ip.getValue()) && (port = (module = ServerModule.getInstance()).getPort()) != -1) {
/* 17 */       return new String[] { (String)(ServerModule.getInstance()).ip.getValue(), Integer.toString(port) };
/*    */     }
/* 19 */     return IServerAddress.getServerAddress(ip);
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\ShitClient\HayBale-1.0.1-b8.jar!\me\luxtix\haybale\mixin\mixins\MixinServerAddress.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */