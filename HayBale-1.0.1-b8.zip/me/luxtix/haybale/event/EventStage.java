/*    */ package me.luxtix.haybale.event;
/*    */ 
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ 
/*    */ public class EventStage
/*    */   extends Event
/*    */ {
/*    */   private int stage;
/*    */   
/*    */   public EventStage() {}
/*    */   
/*    */   public EventStage(int stage) {
/* 13 */     this.stage = stage;
/*    */   }
/*    */   
/*    */   public int getStage() {
/* 17 */     return this.stage;
/*    */   }
/*    */   
/*    */   public void setStage(int stage) {
/* 21 */     this.stage = stage;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\ShitClient\HayBale-1.0.1-b8.jar!\me\luxtix\haybale\event\EventStage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */