/*    */ package me.luxtix.haybale.event.events;
/*    */ 
/*    */ import me.luxtix.haybale.event.EventStage;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ 
/*    */ public class BlockBreakingEvent
/*    */   extends EventStage {
/*    */   public BlockPos pos;
/*    */   public int breakingID;
/*    */   public int breakStage;
/*    */   
/*    */   public BlockBreakingEvent(BlockPos pos, int breakingID, int breakStage) {
/* 13 */     this.pos = pos;
/* 14 */     this.breakingID = breakingID;
/* 15 */     this.breakStage = breakStage;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\ShitClient\HayBale-1.0.1-b8.jar!\me\luxtix\haybale\event\events\BlockBreakingEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */