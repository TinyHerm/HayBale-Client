/*    */ package me.luxtix.haybale.event.events;
/*    */ 
/*    */ import me.luxtix.haybale.event.EventStage;
/*    */ 
/*    */ 
/*    */ public class PerspectiveEvent
/*    */   extends EventStage
/*    */ {
/*    */   private float aspect;
/*    */   
/*    */   public PerspectiveEvent(float f) {
/* 12 */     this.aspect = f;
/*    */   }
/*    */ 
/*    */   
/*    */   public float getAspect() {
/* 17 */     return this.aspect;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setAspect(float f) {
/* 22 */     this.aspect = f;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\ShitClient\HayBale-1.0.1-b8.jar!\me\luxtix\haybale\event\events\PerspectiveEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */