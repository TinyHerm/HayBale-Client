/*     */ package me.luxtix.haybale.event.events;
/*     */ 
/*     */ import me.luxtix.haybale.event.EventStage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RenderItemEvent
/*     */   extends EventStage
/*     */ {
/*     */   double mainX;
/*     */   double mainY;
/*     */   double mainZ;
/*     */   double offX;
/*     */   double offY;
/*     */   double offZ;
/*     */   double mainRAngel;
/*     */   double mainRx;
/*     */   double mainRy;
/*     */   double mainRz;
/*     */   
/*     */   public RenderItemEvent(double mainX, double mainY, double mainZ, double offX, double offY, double offZ, double mainRAngel, double mainRx, double mainRy, double mainRz, double offRAngel, double offRx, double offRy, double offRz, double mainHandScaleX, double mainHandScaleY, double mainHandScaleZ, double offHandScaleX, double offHandScaleY, double offHandScaleZ) {
/*  26 */     this.mainX = mainX;
/*  27 */     this.mainY = mainY;
/*  28 */     this.mainZ = mainZ;
/*  29 */     this.offX = offX;
/*  30 */     this.offY = offY;
/*  31 */     this.offZ = offZ;
/*  32 */     this.mainRAngel = mainRAngel;
/*  33 */     this.mainRx = mainRx;
/*  34 */     this.mainRy = mainRy;
/*  35 */     this.mainRz = mainRz;
/*  36 */     this.offRAngel = offRAngel;
/*  37 */     this.offRx = offRx;
/*  38 */     this.offRy = offRy;
/*  39 */     this.offRz = offRz;
/*  40 */     this.mainHandScaleX = mainHandScaleX;
/*  41 */     this.mainHandScaleY = mainHandScaleY;
/*  42 */     this.mainHandScaleZ = mainHandScaleZ;
/*  43 */     this.offHandScaleX = offHandScaleX;
/*  44 */     this.offHandScaleY = offHandScaleY;
/*  45 */     this.offHandScaleZ = offHandScaleZ;
/*     */   }
/*     */   double offRAngel; double offRx; double offRy; double offRz; double mainHandScaleX; double mainHandScaleY; double mainHandScaleZ; double offHandScaleX; double offHandScaleY; double offHandScaleZ;
/*     */   public void setMainX(double v) {
/*  49 */     this.mainX = v;
/*     */   }
/*     */   
/*     */   public void setMainY(double v) {
/*  53 */     this.mainY = v;
/*     */   }
/*     */   
/*     */   public void setMainZ(double v) {
/*  57 */     this.mainZ = v;
/*     */   }
/*     */   
/*     */   public void setOffX(double v) {
/*  61 */     this.offX = v;
/*     */   }
/*     */   
/*     */   public void setOffY(double v) {
/*  65 */     this.offY = v;
/*     */   }
/*     */   
/*     */   public void setOffZ(double v) {
/*  69 */     this.offZ = v;
/*     */   }
/*     */   
/*     */   public void setOffRAngel(double v) {
/*  73 */     this.offRAngel = v;
/*     */   }
/*     */   
/*     */   public void setOffRx(double v) {
/*  77 */     this.offRx = v;
/*     */   }
/*     */   
/*     */   public void setOffRy(double v) {
/*  81 */     this.offRy = v;
/*     */   }
/*     */   
/*     */   public void setOffRz(double v) {
/*  85 */     this.offRz = v;
/*     */   }
/*     */   
/*     */   public void setMainRAngel(double v) {
/*  89 */     this.mainRAngel = v;
/*     */   }
/*     */   
/*     */   public void setMainRx(double v) {
/*  93 */     this.mainRx = v;
/*     */   }
/*     */   
/*     */   public void setMainRy(double v) {
/*  97 */     this.mainRy = v;
/*     */   }
/*     */   
/*     */   public void setMainRz(double v) {
/* 101 */     this.mainRz = v;
/*     */   }
/*     */   
/*     */   public void setMainHandScaleX(double v) {
/* 105 */     this.mainHandScaleX = v;
/*     */   }
/*     */   
/*     */   public void setMainHandScaleY(double v) {
/* 109 */     this.mainHandScaleY = v;
/*     */   }
/*     */   
/*     */   public void setMainHandScaleZ(double v) {
/* 113 */     this.mainHandScaleZ = v;
/*     */   }
/*     */   
/*     */   public void setOffHandScaleX(double v) {
/* 117 */     this.offHandScaleX = v;
/*     */   }
/*     */   
/*     */   public void setOffHandScaleY(double v) {
/* 121 */     this.offHandScaleY = v;
/*     */   }
/*     */   
/*     */   public void setOffHandScaleZ(double v) {
/* 125 */     this.offHandScaleZ = v;
/*     */   }
/*     */ 
/*     */   
/*     */   public double getMainX() {
/* 130 */     return this.mainX;
/*     */   }
/*     */   
/*     */   public double getMainY() {
/* 134 */     return this.mainY;
/*     */   }
/*     */   
/*     */   public double getMainZ() {
/* 138 */     return this.mainZ;
/*     */   }
/*     */   
/*     */   public double getOffX() {
/* 142 */     return this.offX;
/*     */   }
/*     */   
/*     */   public double getOffY() {
/* 146 */     return this.offY;
/*     */   }
/*     */   
/*     */   public double getOffZ() {
/* 150 */     return this.offZ;
/*     */   }
/*     */   
/*     */   public double getMainRAngel() {
/* 154 */     return this.mainRAngel;
/*     */   }
/*     */   
/*     */   public double getMainRx() {
/* 158 */     return this.mainRx;
/*     */   }
/*     */   
/*     */   public double getMainRy() {
/* 162 */     return this.mainRy;
/*     */   }
/*     */   
/*     */   public double getMainRz() {
/* 166 */     return this.mainRz;
/*     */   }
/*     */   
/*     */   public double getOffRAngel() {
/* 170 */     return this.offRAngel;
/*     */   }
/*     */   
/*     */   public double getOffRx() {
/* 174 */     return this.offRx;
/*     */   }
/*     */   
/*     */   public double getOffRy() {
/* 178 */     return this.offRy;
/*     */   }
/*     */   
/*     */   public double getOffRz() {
/* 182 */     return this.offRz;
/*     */   }
/*     */   
/*     */   public double getMainHandScaleX() {
/* 186 */     return this.mainHandScaleX;
/*     */   }
/*     */   
/*     */   public double getMainHandScaleY() {
/* 190 */     return this.mainHandScaleY;
/*     */   }
/*     */   
/*     */   public double getMainHandScaleZ() {
/* 194 */     return this.mainHandScaleZ;
/*     */   }
/*     */   
/*     */   public double getOffHandScaleX() {
/* 198 */     return this.offHandScaleX;
/*     */   }
/*     */   
/*     */   public double getOffHandScaleY() {
/* 202 */     return this.offHandScaleY;
/*     */   }
/*     */   
/*     */   public double getOffHandScaleZ() {
/* 206 */     return this.offHandScaleZ;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\ShitClient\HayBale-1.0.1-b8.jar!\me\luxtix\haybale\event\events\RenderItemEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */