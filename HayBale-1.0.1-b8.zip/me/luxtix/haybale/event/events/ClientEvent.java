/*    */ package me.luxtix.haybale.event.events;
/*    */ 
/*    */ import me.luxtix.haybale.event.EventStage;
/*    */ import me.luxtix.haybale.features.Feature;
/*    */ import me.luxtix.haybale.features.setting.Setting;
/*    */ import net.minecraftforge.fml.common.eventhandler.Cancelable;
/*    */ 
/*    */ @Cancelable
/*    */ public class ClientEvent
/*    */   extends EventStage {
/*    */   private Feature feature;
/*    */   private Setting setting;
/*    */   
/*    */   public ClientEvent(int stage, Feature feature) {
/* 15 */     super(stage);
/* 16 */     this.feature = feature;
/*    */   }
/*    */   
/*    */   public ClientEvent(Setting setting) {
/* 20 */     super(2);
/* 21 */     this.setting = setting;
/*    */   }
/*    */   
/*    */   public Feature getFeature() {
/* 25 */     return this.feature;
/*    */   }
/*    */   
/*    */   public Setting getSetting() {
/* 29 */     return this.setting;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\ShitClient\HayBale-1.0.1-b8.jar!\me\luxtix\haybale\event\events\ClientEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */