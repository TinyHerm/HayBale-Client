/*    */ package me.luxtix.haybale.event.events;
/*    */ 
/*    */ import javax.sound.midi.ShortMessage;
/*    */ import me.luxtix.haybale.event.EventStage;
/*    */ 
/*    */ public class TickEvent
/*    */   extends EventStage {
/*    */   public static ShortMessage Phase;
/*    */   private final int stage;
/*    */   
/*    */   public TickEvent(int stage) {
/* 12 */     this.stage = stage;
/*    */   }
/*    */   
/*    */   public final int getStage() {
/* 16 */     return this.stage;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\ShitClient\HayBale-1.0.1-b8.jar!\me\luxtix\haybale\event\events\TickEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */