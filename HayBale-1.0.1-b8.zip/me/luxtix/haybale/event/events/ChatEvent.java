/*    */ package me.luxtix.haybale.event.events;
/*    */ 
/*    */ import me.luxtix.haybale.event.EventStage;
/*    */ import net.minecraftforge.fml.common.eventhandler.Cancelable;
/*    */ 
/*    */ @Cancelable
/*    */ public class ChatEvent
/*    */   extends EventStage {
/*    */   private final String msg;
/*    */   
/*    */   public ChatEvent(String msg) {
/* 12 */     this.msg = msg;
/*    */   }
/*    */   
/*    */   public String getMsg() {
/* 16 */     return this.msg;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\ShitClient\HayBale-1.0.1-b8.jar!\me\luxtix\haybale\event\events\ChatEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */