/*     */ package me.luxtix.haybale;
/*     */ import java.io.IOException;
/*     */ import me.luxtix.haybale.features.gui.custom.GuiCustomMainScreen;
/*     */ import me.luxtix.haybale.features.modules.misc.RPC;
/*     */ import me.luxtix.haybale.manager.ColorManager;
/*     */ import me.luxtix.haybale.manager.ConfigManager;
/*     */ import me.luxtix.haybale.manager.EventManager;
/*     */ import me.luxtix.haybale.manager.FileManager;
/*     */ import me.luxtix.haybale.manager.FriendManager;
/*     */ import me.luxtix.haybale.manager.HoleManager;
/*     */ import me.luxtix.haybale.manager.InventoryManager;
/*     */ import me.luxtix.haybale.manager.NoStopManager;
/*     */ import me.luxtix.haybale.manager.NotificationManager;
/*     */ import me.luxtix.haybale.manager.PositionManager;
/*     */ import me.luxtix.haybale.manager.ReloadManager;
/*     */ import me.luxtix.haybale.manager.SafetyManager;
/*     */ import me.luxtix.haybale.manager.TextManager;
/*     */ import me.luxtix.haybale.manager.WaypointManager;
/*     */ import net.minecraftforge.fml.common.Mod.EventHandler;
/*     */ 
/*     */ @Mod(modid = "phobos", name = "Haybale", version = "1.0.1")
/*     */ public class Phobos {
/*  23 */   public static final Logger LOGGER = LogManager.getLogger("Phobos"); public static final String MODID = "Phobos";
/*     */   public static final String MODNAME = "HayBale";
/*     */   public static final String MODVER = "1.0.1";
/*     */   public static final String CHAT_SUFFIX = " ⏐ 3ᴀʀᴛʜʜ4ᴄᴋ";
/*     */   public static final String PHOBOS_SUFFIX = " ⏐ ᴘʜᴏʙᴏꜱ";
/*     */   public static ModuleManager moduleManager;
/*     */   public static SpeedManager speedManager;
/*     */   public static PositionManager positionManager;
/*     */   public static RotationManager rotationManager;
/*     */   public static CommandManager commandManager;
/*     */   public static EventManager eventManager;
/*     */   public static ConfigManager configManager;
/*     */   public static FileManager fileManager;
/*     */   public static FriendManager friendManager;
/*     */   public static TextManager textManager;
/*     */   public static ColorManager colorManager;
/*     */   public static ServerManager serverManager;
/*     */   public static PotionManager potionManager;
/*     */   public static InventoryManager inventoryManager;
/*     */   public static TimerManager timerManager;
/*     */   public static PacketManager packetManager;
/*     */   public static ReloadManager reloadManager;
/*     */   public static TotemPopManager totemPopManager;
/*     */   public static HoleManager holeManager;
/*     */   public static NotificationManager notificationManager;
/*     */   public static SafetyManager safetyManager;
/*     */   public static GuiCustomMainScreen customMainScreen;
/*     */   public static CosmeticsManager cosmeticsManager;
/*     */   public static NoStopManager baritoneManager;
/*     */   public static WaypointManager waypointManager;
/*     */   @Instance
/*     */   public static Phobos INSTANCE;
/*     */   private static boolean unloaded = false;
/*     */   
/*     */   public static void load() {
/*  58 */     LOGGER.info("\n\nsikis baslasin");
/*  59 */     unloaded = false;
/*  60 */     if (reloadManager != null) {
/*  61 */       reloadManager.unload();
/*  62 */       reloadManager = null;
/*     */     } 
/*  64 */     baritoneManager = new NoStopManager();
/*  65 */     totemPopManager = new TotemPopManager();
/*  66 */     timerManager = new TimerManager();
/*  67 */     packetManager = new PacketManager();
/*  68 */     serverManager = new ServerManager();
/*  69 */     colorManager = new ColorManager();
/*  70 */     textManager = new TextManager();
/*  71 */     moduleManager = new ModuleManager();
/*  72 */     speedManager = new SpeedManager();
/*  73 */     rotationManager = new RotationManager();
/*  74 */     positionManager = new PositionManager();
/*  75 */     commandManager = new CommandManager();
/*  76 */     eventManager = new EventManager();
/*  77 */     configManager = new ConfigManager();
/*  78 */     fileManager = new FileManager();
/*  79 */     friendManager = new FriendManager();
/*  80 */     potionManager = new PotionManager();
/*  81 */     inventoryManager = new InventoryManager();
/*  82 */     holeManager = new HoleManager();
/*  83 */     notificationManager = new NotificationManager();
/*  84 */     safetyManager = new SafetyManager();
/*  85 */     waypointManager = new WaypointManager();
/*  86 */     LOGGER.info("Initialized Managers");
/*  87 */     moduleManager.init();
/*  88 */     LOGGER.info("Modules loaded.");
/*  89 */     configManager.init();
/*  90 */     eventManager.init();
/*  91 */     LOGGER.info("EventManager loaded.");
/*  92 */     textManager.init(true);
/*  93 */     moduleManager.onLoad();
/*  94 */     totemPopManager.init();
/*  95 */     timerManager.init();
/*  96 */     if (((RPC)moduleManager.getModuleByClass(RPC.class)).isEnabled()) {
/*  97 */       DiscordPresence.start();
/*     */     }
/*  99 */     cosmeticsManager = new CosmeticsManager();
/* 100 */     LOGGER.info("Hay Bale initialized!\n");
/*     */   }
/*     */   
/*     */   public static void unload(boolean unload) {
/* 104 */     LOGGER.info("\n\nUnloading HayBale 1.0.1");
/* 105 */     if (unload) {
/* 106 */       reloadManager = new ReloadManager();
/* 107 */       reloadManager.init((commandManager != null) ? commandManager.getPrefix() : ".");
/*     */     } 
/* 109 */     if (baritoneManager != null) {
/* 110 */       baritoneManager.stop();
/*     */     }
/* 112 */     onUnload();
/* 113 */     eventManager = null;
/* 114 */     holeManager = null;
/* 115 */     timerManager = null;
/* 116 */     moduleManager = null;
/* 117 */     totemPopManager = null;
/* 118 */     serverManager = null;
/* 119 */     colorManager = null;
/* 120 */     textManager = null;
/* 121 */     speedManager = null;
/* 122 */     rotationManager = null;
/* 123 */     positionManager = null;
/* 124 */     commandManager = null;
/* 125 */     configManager = null;
/* 126 */     fileManager = null;
/* 127 */     friendManager = null;
/* 128 */     potionManager = null;
/* 129 */     inventoryManager = null;
/* 130 */     notificationManager = null;
/* 131 */     safetyManager = null;
/* 132 */     LOGGER.info("HayBale unloaded!\n");
/*     */   }
/*     */   
/*     */   public static void reload() {
/* 136 */     unload(false);
/* 137 */     load();
/*     */   }
/*     */   
/*     */   public static void onUnload() {
/* 141 */     if (!unloaded) {
/*     */       try {
/* 143 */         IRC.INSTANCE.disconnect();
/* 144 */       } catch (IOException e) {
/* 145 */         e.printStackTrace();
/*     */       } 
/* 147 */       eventManager.onUnload();
/* 148 */       moduleManager.onUnload();
/* 149 */       configManager.saveConfig(configManager.config.replaceFirst("phobos/", ""));
/* 150 */       moduleManager.onUnloadPost();
/* 151 */       timerManager.unload();
/* 152 */       unloaded = true;
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void preInit(FMLPreInitializationEvent event) {
/* 158 */     LOGGER.info("Luxotick is cute!!!");
/* 159 */     LOGGER.info("faggot above - NudTix");
/* 160 */     LOGGER.info("Luxotick wins again");
/* 161 */     LOGGER.info("LyFraude is gay");
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void init(FMLInitializationEvent event) {
/* 166 */     customMainScreen = new GuiCustomMainScreen();
/* 167 */     Display.setTitle("HayBale Client - v.1.0.1");
/* 168 */     load();
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\ShitClient\HayBale-1.0.1-b8.jar!\me\luxtix\haybale\Phobos.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */