/*    */ package me.luxtix.haybale.features.command.commands;
/*    */ 
/*    */ import me.luxtix.haybale.Phobos;
/*    */ import me.luxtix.haybale.features.command.Command;
/*    */ import me.luxtix.haybale.features.modules.client.ClickGui;
/*    */ 
/*    */ public class PrefixCommand
/*    */   extends Command {
/*    */   public PrefixCommand() {
/* 10 */     super("prefix", new String[] { "<char>" });
/*    */   }
/*    */ 
/*    */   
/*    */   public void execute(String[] commands) {
/* 15 */     if (commands.length == 1) {
/* 16 */       Command.sendMessage("§cSpecify a new prefix.");
/*    */       return;
/*    */     } 
/* 19 */     ((ClickGui)Phobos.moduleManager.getModuleByClass(ClickGui.class)).prefix.setValue(commands[0]);
/* 20 */     Command.sendMessage("Prefix set to §a" + Phobos.commandManager.getPrefix());
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\ShitClient\HayBale-1.0.1-b8.jar!\me\luxtix\haybale\features\command\commands\PrefixCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */