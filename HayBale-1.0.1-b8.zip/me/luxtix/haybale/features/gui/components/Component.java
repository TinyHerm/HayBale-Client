/*     */ package me.luxtix.haybale.features.gui.components;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.util.ArrayList;
/*     */ import me.luxtix.haybale.Phobos;
/*     */ import me.luxtix.haybale.features.Feature;
/*     */ import me.luxtix.haybale.features.gui.PhobosGui;
/*     */ import me.luxtix.haybale.features.gui.components.items.Item;
/*     */ import me.luxtix.haybale.features.gui.components.items.buttons.Button;
/*     */ import me.luxtix.haybale.features.modules.client.ClickGui;
/*     */ import me.luxtix.haybale.features.modules.client.Colors;
/*     */ import me.luxtix.haybale.features.modules.client.HUD;
/*     */ import me.luxtix.haybale.util.ColorUtil;
/*     */ import me.luxtix.haybale.util.MathUtil;
/*     */ import me.luxtix.haybale.util.RenderUtil;
/*     */ import net.minecraft.client.audio.ISound;
/*     */ import net.minecraft.client.audio.PositionedSoundRecord;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.init.SoundEvents;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ public class Component
/*     */   extends Feature
/*     */ {
/*  26 */   private final ArrayList<Item> items = new ArrayList<>();
/*     */   public boolean drag;
/*     */   private int x;
/*     */   private int y;
/*     */   private int x2;
/*     */   private int y2;
/*     */   private int width;
/*     */   private int height;
/*     */   private boolean open;
/*     */   private boolean hidden = false;
/*     */   
/*     */   public Component(String name, int x, int y, boolean open) {
/*  38 */     super(name);
/*  39 */     this.x = x;
/*  40 */     this.y = y;
/*  41 */     this.width = 88;
/*  42 */     this.height = 18;
/*  43 */     this.open = open;
/*  44 */     setupItems();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setupItems() {}
/*     */   
/*     */   private void drag(int mouseX, int mouseY) {
/*  51 */     if (!this.drag) {
/*     */       return;
/*     */     }
/*  54 */     this.x = this.x2 + mouseX;
/*  55 */     this.y = this.y2 + mouseY;
/*     */   }
/*     */   
/*     */   public void drawScreen(int mouseX, int mouseY, float partialTicks) {
/*  59 */     drag(mouseX, mouseY);
/*  60 */     float totalItemHeight = this.open ? (getTotalItemHeight() - 2.0F) : 0.0F;
/*  61 */     int color = -7829368;
/*  62 */     if (((Boolean)(ClickGui.getInstance()).devSettings.getValue()).booleanValue()) {
/*  63 */       int i = color = ((Boolean)(ClickGui.getInstance()).colorSync.getValue()).booleanValue() ? Colors.INSTANCE.getCurrentColorHex() : ColorUtil.toARGB(((Integer)(ClickGui.getInstance()).topRed.getValue()).intValue(), ((Integer)(ClickGui.getInstance()).topGreen.getValue()).intValue(), ((Integer)(ClickGui.getInstance()).topBlue.getValue()).intValue(), ((Integer)(ClickGui.getInstance()).topAlpha.getValue()).intValue());
/*     */     }
/*  65 */     if (((Boolean)(ClickGui.getInstance()).rainbowRolling.getValue()).booleanValue() && ((Boolean)(ClickGui.getInstance()).colorSync.getValue()).booleanValue() && ((Boolean)Colors.INSTANCE.rainbow.getValue()).booleanValue()) {
/*  66 */       RenderUtil.drawGradientRect(this.x, this.y - 1.5F, this.width, (this.height - 4), ((Integer)(HUD.getInstance()).colorMap.get(Integer.valueOf(MathUtil.clamp(this.y, 0, this.renderer.scaledHeight)))).intValue(), ((Integer)(HUD.getInstance()).colorMap.get(Integer.valueOf(MathUtil.clamp(this.y + this.height - 4, 0, this.renderer.scaledHeight)))).intValue());
/*     */     } else {
/*  68 */       RenderUtil.drawRect(this.x, this.y - 1.5F, (this.x + this.width), (this.y + this.height - 6), color);
/*     */     } 
/*  70 */     if (this.open) {
/*  71 */       RenderUtil.drawRect(this.x, this.y + 12.5F, (this.x + this.width), (this.y + this.height) + totalItemHeight, 1996488704);
/*  72 */       if (((Boolean)(ClickGui.getInstance()).outline.getValue()).booleanValue()) {
/*  73 */         if (((Boolean)(ClickGui.getInstance()).rainbowRolling.getValue()).booleanValue()) {
/*  74 */           GlStateManager.func_179090_x();
/*  75 */           GlStateManager.func_179147_l();
/*  76 */           GlStateManager.func_179118_c();
/*  77 */           GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
/*  78 */           GlStateManager.func_179103_j(7425);
/*  79 */           GL11.glBegin(1);
/*  80 */           Color currentColor = new Color(((Integer)(HUD.getInstance()).colorMap.get(Integer.valueOf(MathUtil.clamp(this.y, 0, this.renderer.scaledHeight)))).intValue());
/*  81 */           GL11.glColor4f(currentColor.getRed() / 255.0F, currentColor.getGreen() / 255.0F, currentColor.getBlue() / 255.0F, currentColor.getAlpha() / 255.0F);
/*  82 */           GL11.glVertex3f((this.x + this.width), this.y - 1.5F, 0.0F);
/*  83 */           GL11.glVertex3f(this.x, this.y - 1.5F, 0.0F);
/*  84 */           GL11.glVertex3f(this.x, this.y - 1.5F, 0.0F);
/*  85 */           float currentHeight = getHeight() - 1.5F;
/*  86 */           for (Item item : getItems()) {
/*  87 */             currentColor = new Color(((Integer)(HUD.getInstance()).colorMap.get(Integer.valueOf(MathUtil.clamp((int)(this.y + (currentHeight += item.getHeight() + 1.5F)), 0, this.renderer.scaledHeight)))).intValue());
/*  88 */             GL11.glColor4f(currentColor.getRed() / 255.0F, currentColor.getGreen() / 255.0F, currentColor.getBlue() / 255.0F, currentColor.getAlpha() / 255.0F);
/*  89 */             GL11.glVertex3f(this.x, this.y + currentHeight, 0.0F);
/*  90 */             GL11.glVertex3f(this.x, this.y + currentHeight, 0.0F);
/*     */           } 
/*  92 */           currentColor = new Color(((Integer)(HUD.getInstance()).colorMap.get(Integer.valueOf(MathUtil.clamp((int)((this.y + this.height) + totalItemHeight), 0, this.renderer.scaledHeight)))).intValue());
/*  93 */           GL11.glColor4f(currentColor.getRed() / 255.0F, currentColor.getGreen() / 255.0F, currentColor.getBlue() / 255.0F, currentColor.getAlpha() / 255.0F);
/*  94 */           GL11.glVertex3f((this.x + this.width), (this.y + this.height) + totalItemHeight, 0.0F);
/*  95 */           GL11.glVertex3f((this.x + this.width), (this.y + this.height) + totalItemHeight, 0.0F);
/*  96 */           for (Item item : getItems()) {
/*  97 */             currentColor = new Color(((Integer)(HUD.getInstance()).colorMap.get(Integer.valueOf(MathUtil.clamp((int)(this.y + (currentHeight -= item.getHeight() + 1.5F)), 0, this.renderer.scaledHeight)))).intValue());
/*  98 */             GL11.glColor4f(currentColor.getRed() / 255.0F, currentColor.getGreen() / 255.0F, currentColor.getBlue() / 255.0F, currentColor.getAlpha() / 255.0F);
/*  99 */             GL11.glVertex3f((this.x + this.width), this.y + currentHeight, 0.0F);
/* 100 */             GL11.glVertex3f((this.x + this.width), this.y + currentHeight, 0.0F);
/*     */           } 
/* 102 */           GL11.glVertex3f((this.x + this.width), this.y, 0.0F);
/* 103 */           GL11.glEnd();
/* 104 */           GlStateManager.func_179103_j(7424);
/* 105 */           GlStateManager.func_179084_k();
/* 106 */           GlStateManager.func_179141_d();
/* 107 */           GlStateManager.func_179098_w();
/*     */         } else {
/* 109 */           GlStateManager.func_179090_x();
/* 110 */           GlStateManager.func_179147_l();
/* 111 */           GlStateManager.func_179118_c();
/* 112 */           GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
/* 113 */           GlStateManager.func_179103_j(7425);
/* 114 */           GL11.glBegin(2);
/* 115 */           Color outlineColor = ((Boolean)(ClickGui.getInstance()).colorSync.getValue()).booleanValue() ? new Color(Colors.INSTANCE.getCurrentColorHex()) : new Color(Phobos.colorManager.getColorAsIntFullAlpha());
/* 116 */           GL11.glColor4f(outlineColor.getRed(), outlineColor.getGreen(), outlineColor.getBlue(), outlineColor.getAlpha());
/* 117 */           GL11.glVertex3f(this.x, this.y - 1.5F, 0.0F);
/* 118 */           GL11.glVertex3f((this.x + this.width), this.y - 1.5F, 0.0F);
/* 119 */           GL11.glVertex3f((this.x + this.width), (this.y + this.height) + totalItemHeight, 0.0F);
/* 120 */           GL11.glVertex3f(this.x, (this.y + this.height) + totalItemHeight, 0.0F);
/* 121 */           GL11.glEnd();
/* 122 */           GlStateManager.func_179103_j(7424);
/* 123 */           GlStateManager.func_179084_k();
/* 124 */           GlStateManager.func_179141_d();
/* 125 */           GlStateManager.func_179098_w();
/*     */         } 
/*     */       }
/*     */     } 
/* 129 */     Phobos.textManager.drawStringWithShadow(getName(), this.x + 3.0F, this.y - 4.0F - PhobosGui.getClickGui().getTextOffset(), -1);
/* 130 */     if (this.open) {
/* 131 */       float y = (getY() + getHeight()) - 3.0F;
/* 132 */       for (Item item : getItems()) {
/* 133 */         if (item.isHidden())
/* 134 */           continue;  item.setLocation(this.x + 2.0F, y);
/* 135 */         item.setWidth(getWidth() - 4);
/* 136 */         item.drawScreen(mouseX, mouseY, partialTicks);
/* 137 */         y += item.getHeight() + 1.5F;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
/* 143 */     if (mouseButton == 0 && isHovering(mouseX, mouseY)) {
/* 144 */       this.x2 = this.x - mouseX;
/* 145 */       this.y2 = this.y - mouseY;
/* 146 */       PhobosGui.getClickGui().getComponents().forEach(component -> {
/*     */             if (component.drag) {
/*     */               component.drag = false;
/*     */             }
/*     */           });
/* 151 */       this.drag = true;
/*     */       return;
/*     */     } 
/* 154 */     if (mouseButton == 1 && isHovering(mouseX, mouseY)) {
/* 155 */       this.open = !this.open;
/* 156 */       mc.func_147118_V().func_147682_a((ISound)PositionedSoundRecord.func_184371_a(SoundEvents.field_187909_gi, 1.0F));
/*     */       return;
/*     */     } 
/* 159 */     if (!this.open) {
/*     */       return;
/*     */     }
/* 162 */     getItems().forEach(item -> item.mouseClicked(mouseX, mouseY, mouseButton));
/*     */   }
/*     */   
/*     */   public void mouseReleased(int mouseX, int mouseY, int releaseButton) {
/* 166 */     if (releaseButton == 0) {
/* 167 */       this.drag = false;
/*     */     }
/* 169 */     if (!this.open) {
/*     */       return;
/*     */     }
/* 172 */     getItems().forEach(item -> item.mouseReleased(mouseX, mouseY, releaseButton));
/*     */   }
/*     */   
/*     */   public void onKeyTyped(char typedChar, int keyCode) {
/* 176 */     if (!this.open) {
/*     */       return;
/*     */     }
/* 179 */     getItems().forEach(item -> item.onKeyTyped(typedChar, keyCode));
/*     */   }
/*     */   
/*     */   public void addButton(Button button) {
/* 183 */     this.items.add(button);
/*     */   }
/*     */   
/*     */   public int getX() {
/* 187 */     return this.x;
/*     */   }
/*     */   
/*     */   public void setX(int x) {
/* 191 */     this.x = x;
/*     */   }
/*     */   
/*     */   public int getY() {
/* 195 */     return this.y;
/*     */   }
/*     */   
/*     */   public void setY(int y) {
/* 199 */     this.y = y;
/*     */   }
/*     */   
/*     */   public int getWidth() {
/* 203 */     return this.width;
/*     */   }
/*     */   
/*     */   public void setWidth(int width) {
/* 207 */     this.width = width;
/*     */   }
/*     */   
/*     */   public int getHeight() {
/* 211 */     return this.height;
/*     */   }
/*     */   
/*     */   public void setHeight(int height) {
/* 215 */     this.height = height;
/*     */   }
/*     */   
/*     */   public boolean isHidden() {
/* 219 */     return this.hidden;
/*     */   }
/*     */   
/*     */   public void setHidden(boolean hidden) {
/* 223 */     this.hidden = hidden;
/*     */   }
/*     */   
/*     */   public boolean isOpen() {
/* 227 */     return this.open;
/*     */   }
/*     */   
/*     */   public final ArrayList<Item> getItems() {
/* 231 */     return this.items;
/*     */   }
/*     */   
/*     */   private boolean isHovering(int mouseX, int mouseY) {
/* 235 */     return (mouseX >= getX() && mouseX <= getX() + getWidth() && mouseY >= getY() && mouseY <= getY() + getHeight() - (this.open ? 2 : 0));
/*     */   }
/*     */   
/*     */   private float getTotalItemHeight() {
/* 239 */     float height = 0.0F;
/* 240 */     for (Item item : getItems()) {
/* 241 */       height += item.getHeight() + 1.5F;
/*     */     }
/* 243 */     return height;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\ShitClient\HayBale-1.0.1-b8.jar!\me\luxtix\haybale\features\gui\components\Component.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */