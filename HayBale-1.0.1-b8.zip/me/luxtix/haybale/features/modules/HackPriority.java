/*   */ package me.luxtix.haybale.features.modules;
/*   */ 
/*   */ public enum HackPriority {
/* 4 */   Highest,
/* 5 */   High,
/* 6 */   Normal,
/* 7 */   Low,
/* 8 */   Lowest;
/*   */ }


/* Location:              C:\Users\Administrator\Desktop\ShitClient\HayBale-1.0.1-b8.jar!\me\luxtix\haybale\features\modules\HackPriority.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */