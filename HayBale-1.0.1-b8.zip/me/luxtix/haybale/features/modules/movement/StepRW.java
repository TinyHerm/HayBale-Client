/*    */ package me.luxtix.haybale.features.modules.movement;
/*    */ 
/*    */ import me.luxtix.haybale.features.modules.Module;
/*    */ import me.luxtix.haybale.features.setting.Setting;
/*    */ 
/*    */ public class StepRW
/*    */   extends Module {
/*  8 */   public Setting<Integer> height = register(new Setting("Height", Integer.valueOf(2), Integer.valueOf(0), Integer.valueOf(5)));
/*    */ 
/*    */   
/*    */   public StepRW() {
/* 12 */     super("StepRW", "Allows you to step up blocks", Module.Category.MOVEMENT, true, false, false);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void onUpdate() {
/* 19 */     if (fullNullCheck())
/* 20 */       return;  mc.field_71439_g.field_70138_W = 2.0F;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void onDisable() {
/* 26 */     super.onDisable();
/* 27 */     mc.field_71439_g.field_70138_W = 0.6F;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\ShitClient\HayBale-1.0.1-b8.jar!\me\luxtix\haybale\features\modules\movement\StepRW.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */