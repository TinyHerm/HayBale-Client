/*    */ package me.luxtix.haybale.features.modules.movement;
/*    */ 
/*    */ import me.luxtix.haybale.features.modules.Module;
/*    */ 
/*    */ public class EntityControl
/*    */   extends Module {
/*    */   public static EntityControl INSTANCE;
/*    */   
/*    */   public EntityControl() {
/* 10 */     super("EntityControl", "Control entities with the force or some shit", Module.Category.MOVEMENT, false, false, false);
/* 11 */     INSTANCE = this;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\ShitClient\HayBale-1.0.1-b8.jar!\me\luxtix\haybale\features\modules\movement\EntityControl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */