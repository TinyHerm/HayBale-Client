/*    */ package me.luxtix.haybale.features.modules.movement;
/*    */ import me.luxtix.haybale.features.modules.Module;
/*    */ import me.luxtix.haybale.util.EntityUtil2;
/*    */ import me.luxtix.haybale.util.PlayerUtil2;
/*    */ import me.luxtix.haybale.util.Timer;
/*    */ 
/*    */ public class Yport extends Module {
/*    */   Setting<Double> yPortSpeed;
/*    */   
/*    */   public Yport() {
/* 11 */     super("Yport", "YPort Speed.", Module.Category.MOVEMENT, false, false, false);
/*    */ 
/*    */     
/* 14 */     this.yPortSpeed = register(new Setting("YPort Speed", Double.valueOf(0.6D), Double.valueOf(0.5D), Double.valueOf(1.5D)));
/*    */ 
/*    */     
/* 17 */     this.timer = new Timer();
/*    */   }
/*    */   private double playerSpeed; private final Timer timer;
/*    */   public void onEnable() {
/* 21 */     this.playerSpeed = PlayerUtil2.getBaseMoveSpeed();
/*    */   }
/*    */ 
/*    */   
/*    */   public void onDisable() {
/* 26 */     EntityUtil2.resetTimer();
/* 27 */     this.timer.reset();
/*    */   }
/*    */ 
/*    */   
/*    */   public void onUpdate() {
/* 32 */     if (nullCheck()) {
/* 33 */       disable();
/*    */       
/*    */       return;
/*    */     } 
/* 37 */     if (!PlayerUtil2.isMoving((EntityLivingBase)mc.field_71439_g) || (mc.field_71439_g.func_70090_H() && mc.field_71439_g.func_180799_ab()) || mc.field_71439_g.field_70123_F) {
/*    */       return;
/*    */     }
/* 40 */     if (mc.field_71439_g.field_70122_E) {
/* 41 */       EntityUtil2.setTimer(1.15F);
/* 42 */       mc.field_71439_g.func_70664_aZ();
/* 43 */       PlayerUtil2.setSpeed((EntityLivingBase)mc.field_71439_g, PlayerUtil2.getBaseMoveSpeed() + ((Double)this.yPortSpeed.getValue()).doubleValue() / 10.0D);
/*    */     } else {
/* 45 */       mc.field_71439_g.field_70181_x = -1.0D;
/* 46 */       EntityUtil2.resetTimer();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\ShitClient\HayBale-1.0.1-b8.jar!\me\luxtix\haybale\features\modules\movement\Yport.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */