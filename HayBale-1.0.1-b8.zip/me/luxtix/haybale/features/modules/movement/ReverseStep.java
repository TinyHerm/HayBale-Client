/*    */ package me.luxtix.haybale.features.modules.movement;
/*    */ 
/*    */ import me.luxtix.haybale.Phobos;
/*    */ import me.luxtix.haybale.features.modules.Module;
/*    */ import me.luxtix.haybale.features.setting.Setting;
/*    */ import net.minecraft.entity.Entity;
/*    */ 
/*    */ public class ReverseStep extends Module {
/*  9 */   private final Setting<Integer> speed = register(new Setting("Speed", Integer.valueOf(8), Integer.valueOf(1), Integer.valueOf(20)));
/*    */   
/* 11 */   private final Setting<Boolean> inliquid = register(new Setting("Liquid", Boolean.valueOf(false)));
/*    */   
/* 13 */   private final Setting<Cancel> canceller = register(new Setting("CancelType", Cancel.None));
/*    */   
/* 15 */   private static ReverseStep INSTANCE = new ReverseStep();
/*    */   
/*    */   public ReverseStep() {
/* 18 */     super("ReverseStep", "rs", Module.Category.MOVEMENT, true, false, false);
/* 19 */     setInstance();
/*    */   }
/*    */   
/*    */   public static ReverseStep getInstance() {
/* 23 */     if (INSTANCE == null)
/* 24 */       INSTANCE = new ReverseStep(); 
/* 25 */     return INSTANCE;
/*    */   }
/*    */   
/*    */   private void setInstance() {
/* 29 */     INSTANCE = this;
/*    */   }
/*    */   
/*    */   public void onUpdate() {
/* 33 */     if (nullCheck())
/*    */       return; 
/* 35 */     if (mc.field_71439_g.func_70093_af() || mc.field_71439_g.field_70128_L || mc.field_71439_g.field_70123_F || !mc.field_71439_g.field_70122_E || (mc.field_71439_g.func_70090_H() && !((Boolean)this.inliquid.getValue()).booleanValue()) || (mc.field_71439_g.func_180799_ab() && !((Boolean)this.inliquid.getValue()).booleanValue()) || mc.field_71439_g.func_70617_f_() || mc.field_71474_y.field_74314_A.func_151470_d() || Phobos.moduleManager.isModuleEnabled("Burrow") || mc.field_71439_g.field_70145_X || Phobos.moduleManager.isModuleEnabled("Packetfly") || Phobos.moduleManager.isModuleEnabled("Phase") || (mc.field_71474_y.field_74311_E.func_151470_d() && this.canceller.getValue() == Cancel.Shift) || (mc.field_71474_y.field_74311_E.func_151470_d() && this.canceller.getValue() == Cancel.Both) || (mc.field_71474_y.field_74314_A.func_151470_d() && this.canceller.getValue() == Cancel.Space) || (mc.field_71474_y.field_74314_A.func_151470_d() && this.canceller.getValue() == Cancel.Both) || Phobos.moduleManager.isModuleEnabled("Strafe"))
/*    */       return; 
/* 37 */     for (double y = 0.0D; y < 90.5D; y += 0.01D) {
/* 38 */       if (!mc.field_71441_e.func_184144_a((Entity)mc.field_71439_g, mc.field_71439_g.func_174813_aQ().func_72317_d(0.0D, -y, 0.0D)).isEmpty()) {
/* 39 */         mc.field_71439_g.field_70181_x = (-((Integer)this.speed.getValue()).intValue() / 10.0F);
/*    */         break;
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   public enum Cancel {
/* 46 */     None, Space, Shift, Both;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\ShitClient\HayBale-1.0.1-b8.jar!\me\luxtix\haybale\features\modules\movement\ReverseStep.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */