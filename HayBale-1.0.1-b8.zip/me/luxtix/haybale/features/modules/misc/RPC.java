/*    */ package me.luxtix.haybale.features.modules.misc;
/*    */ 
/*    */ import me.luxtix.haybale.DiscordPresence;
/*    */ import me.luxtix.haybale.features.modules.Module;
/*    */ import me.luxtix.haybale.features.setting.Setting;
/*    */ 
/*    */ public class RPC
/*    */   extends Module {
/*    */   public static RPC INSTANCE;
/* 10 */   public Setting<Boolean> showIP = register(new Setting("ShowIP", Boolean.valueOf(true), "Shows the server IP in your discord presence."));
/* 11 */   public Setting<String> state = register(new Setting("State", "Winning with HayBale Beta 1.0.1 https://discord.gg/KTUmN8YhBd", "Sets the state of the DiscordRPC."));
/*    */   
/*    */   public RPC() {
/* 14 */     super("RPC", "Discord rich presence", Module.Category.MISC, false, false, false);
/* 15 */     INSTANCE = this;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onEnable() {
/* 20 */     DiscordPresence.start();
/*    */   }
/*    */ 
/*    */   
/*    */   public void onDisable() {
/* 25 */     DiscordPresence.stop();
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\ShitClient\HayBale-1.0.1-b8.jar!\me\luxtix\haybale\features\modules\misc\RPC.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */