/*    */ package me.luxtix.haybale.features.modules.render;
/*    */ 
/*    */ import me.luxtix.haybale.event.events.PerspectiveEvent;
/*    */ import me.luxtix.haybale.features.modules.Module;
/*    */ import me.luxtix.haybale.features.setting.Setting;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ 
/*    */ public class Aspect
/*    */   extends Module
/*    */ {
/* 11 */   public Setting<Float> aspect = register(new Setting("Alpha", Float.valueOf(1.0F), Float.valueOf(0.1F), Float.valueOf(5.0F)));
/*    */ 
/*    */   
/*    */   public Aspect() {
/* 15 */     super("Aspect", "Cool.", Module.Category.RENDER, true, false, false);
/*    */   }
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onPerspectiveEvent(PerspectiveEvent perspectiveEvent) {
/* 21 */     perspectiveEvent.setAspect(((Float)this.aspect.getValue()).floatValue());
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\ShitClient\HayBale-1.0.1-b8.jar!\me\luxtix\haybale\features\modules\render\Aspect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */