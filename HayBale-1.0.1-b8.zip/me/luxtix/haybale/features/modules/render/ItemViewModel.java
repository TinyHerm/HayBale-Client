/*    */ package me.luxtix.haybale.features.modules.render;
/*    */ 
/*    */ import me.luxtix.haybale.features.modules.Module;
/*    */ import me.luxtix.haybale.features.setting.Setting;
/*    */ 
/*    */ public class ItemViewModel extends Module {
/*    */   public static ItemViewModel INSTANCE;
/*    */   
/*    */   public ItemViewModel() {
/* 10 */     super("ItemViewModel", "Changes to the viewmodel.", Module.Category.RENDER, false, false, false);
/*    */ 
/*    */ 
/*    */     
/* 14 */     this.translateX = register(new Setting("TranslateX", Integer.valueOf(0), Integer.valueOf(-100), Integer.valueOf(100)));
/* 15 */     this.translateY = register(new Setting("TranslateY", Integer.valueOf(0), Integer.valueOf(-100), Integer.valueOf(100)));
/* 16 */     this.translateZ = register(new Setting("TranslateZ", Integer.valueOf(0), Integer.valueOf(-100), Integer.valueOf(100)));
/*    */     
/* 18 */     this.rotateX = register(new Setting("RotateX", Integer.valueOf(0), Integer.valueOf(-100), Integer.valueOf(100)));
/* 19 */     this.rotateY = register(new Setting("RotateY", Integer.valueOf(0), Integer.valueOf(-100), Integer.valueOf(100)));
/* 20 */     this.rotateZ = register(new Setting("RotateZ", Integer.valueOf(0), Integer.valueOf(-100), Integer.valueOf(100)));
/*    */     
/* 22 */     this.scaleX = register(new Setting("ScaleX", Integer.valueOf(100), Integer.valueOf(0), Integer.valueOf(100)));
/* 23 */     this.scaleY = register(new Setting("ScaleY", Integer.valueOf(100), Integer.valueOf(0), Integer.valueOf(100)));
/* 24 */     this.scaleZ = register(new Setting("ScaleZ", Integer.valueOf(100), Integer.valueOf(0), Integer.valueOf(100)));
/*    */     INSTANCE = this;
/*    */   }
/*    */   
/*    */   public final Setting<Integer> translateX;
/*    */   public final Setting<Integer> translateY;
/*    */   public final Setting<Integer> translateZ;
/*    */   public final Setting<Integer> rotateX;
/*    */   public final Setting<Integer> rotateY;
/*    */   public final Setting<Integer> rotateZ;
/*    */   public final Setting<Integer> scaleX;
/*    */   public final Setting<Integer> scaleY;
/*    */   public final Setting<Integer> scaleZ;
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\ShitClient\HayBale-1.0.1-b8.jar!\me\luxtix\haybale\features\modules\render\ItemViewModel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */