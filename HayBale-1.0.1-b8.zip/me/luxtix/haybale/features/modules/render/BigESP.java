/*   */ package me.luxtix.haybale.features.modules.render;
/*   */ 
/*   */ import me.luxtix.haybale.features.modules.Module;
/*   */ 
/*   */ public class BigESP
/*   */   extends Module {
/*   */   public BigESP() {
/* 8 */     super("BigModule", "Big fucking module", Module.Category.RENDER, true, false, false);
/*   */   }
/*   */ }


/* Location:              C:\Users\Administrator\Desktop\ShitClient\HayBale-1.0.1-b8.jar!\me\luxtix\haybale\features\modules\render\BigESP.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */