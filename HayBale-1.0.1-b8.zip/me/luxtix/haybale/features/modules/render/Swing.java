/*    */ package me.luxtix.haybale.features.modules.render;
/*    */ 
/*    */ import me.luxtix.haybale.features.modules.Module;
/*    */ import me.luxtix.haybale.features.setting.Setting;
/*    */ import net.minecraft.util.EnumHand;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Swing
/*    */   extends Module
/*    */ {
/* 13 */   private Setting<Hand> hand = register(new Setting("Hand", Hand.OFFHAND));
/*    */   public Swing() {
/* 15 */     super("Swing", "Changes the hand you swing with", Module.Category.RENDER, false, false, false);
/*    */   }
/*    */   
/*    */   public void onUpdate() {
/* 19 */     if (mc.field_71441_e == null)
/*    */       return; 
/* 21 */     if (((Hand)this.hand.getValue()).equals(Hand.OFFHAND)) {
/* 22 */       mc.field_71439_g.field_184622_au = EnumHand.OFF_HAND;
/*    */     }
/* 24 */     if (((Hand)this.hand.getValue()).equals(Hand.MAINHAND)) {
/* 25 */       mc.field_71439_g.field_184622_au = EnumHand.MAIN_HAND;
/*    */     }
/* 27 */     if (((Hand)this.hand.getValue()).equals(Hand.PACKETSWING) && 
/* 28 */       mc.field_71439_g.func_184614_ca().func_77973_b() instanceof net.minecraft.item.ItemSword && mc.field_71460_t.field_78516_c.field_187470_g >= 0.9D) {
/* 29 */       mc.field_71460_t.field_78516_c.field_187469_f = 1.0F;
/* 30 */       mc.field_71460_t.field_78516_c.field_187467_d = mc.field_71439_g.func_184614_ca();
/*    */     } 
/*    */   }
/*    */   
/*    */   public enum Hand
/*    */   {
/* 36 */     OFFHAND,
/* 37 */     MAINHAND,
/* 38 */     PACKETSWING;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\ShitClient\HayBale-1.0.1-b8.jar!\me\luxtix\haybale\features\modules\render\Swing.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */