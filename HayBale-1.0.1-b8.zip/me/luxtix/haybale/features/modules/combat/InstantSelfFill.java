/*     */ package me.luxtix.haybale.features.modules.combat;
/*     */ 
/*     */ import com.google.common.eventbus.Subscribe;
/*     */ import java.lang.reflect.Field;
/*     */ import me.luxtix.haybale.Phobos;
/*     */ import me.luxtix.haybale.features.command.Command;
/*     */ import me.luxtix.haybale.features.modules.Module;
/*     */ import me.luxtix.haybale.features.modules.movement.ReverseStep;
/*     */ import me.luxtix.haybale.features.setting.Setting;
/*     */ import me.luxtix.haybale.util.BlockUtil;
/*     */ import me.luxtix.haybale.util.InventoryUtil;
/*     */ import me.luxtix.haybale.util.ItemUtil;
/*     */ import me.luxtix.haybale.util.MappingUtil;
/*     */ import me.luxtix.haybale.util.WorldUtil;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketEntityAction;
/*     */ import net.minecraft.network.play.client.CPacketPlayer;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.Timer;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ 
/*     */ public class InstantSelfFill
/*     */   extends Module
/*     */ {
/*  29 */   private final Setting<Float> height = register(new Setting("TPHeight", Float.valueOf(5.0F), Float.valueOf(-20.0F), Float.valueOf(20.0F)));
/*  30 */   private final Setting<Float> extraboost = register(new Setting("Extra", Float.valueOf(0.0F), Float.valueOf(-10.0F), Float.valueOf(10.0F)));
/*  31 */   public final Setting<Page> page = register(new Setting("Block", Page.EChest));
/*  32 */   private final Setting<Boolean> packetJump = register(new Setting("PacketJump", Boolean.valueOf(false), v -> !((Boolean)this.timerfill.getValue()).booleanValue()));
/*  33 */   private final Setting<Boolean> timerfill = register(new Setting("TimerJump", Boolean.valueOf(true), v -> !((Boolean)this.packetJump.getValue()).booleanValue()));
/*  34 */   private final Setting<Boolean> autoCenter = register(new Setting("Center", Boolean.valueOf(false)));
/*  35 */   private final Setting<Boolean> rotate = register(new Setting("Rotate", Boolean.FALSE));
/*  36 */   private final Setting<Boolean> sneaking = register(new Setting("SneakPacket", Boolean.valueOf(false)));
/*  37 */   private final Setting<Boolean> offground = register(new Setting("Offground", Boolean.valueOf(false)));
/*  38 */   public BlockPos startPos = null;
/*     */   private BlockPos playerPos;
/*  40 */   private int hudAmount = 0;
/*     */   private int blockSlot;
/*     */   
/*     */   public InstantSelfFill() {
/*  44 */     super("Burrow", "b", Module.Category.COMBAT, true, false, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  49 */     if (((Boolean)this.timerfill.getValue()).booleanValue()) {
/*  50 */       setTimer(50.0F);
/*  51 */       Phobos.moduleManager.getModuleByName("ReverseStep").isEnabled();
/*  52 */       ReverseStep.getInstance().disable();
/*  53 */       this.playerPos = new BlockPos(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u, mc.field_71439_g.field_70161_v);
/*  54 */       if (mc.field_71441_e.func_180495_p(this.playerPos).func_177230_c().equals(Blocks.field_150343_Z)) {
/*  55 */         disable();
/*     */         return;
/*     */       } 
/*  58 */       mc.field_71439_g.func_70664_aZ();
/*     */     } 
/*  60 */     if (((Boolean)this.packetJump.getValue()).booleanValue()) {
/*  61 */       if (fullNullCheck()) {
/*  62 */         disable();
/*     */         return;
/*     */       } 
/*  65 */       Phobos.moduleManager.getModuleByName("ReverseStep").isEnabled();
/*  66 */       ReverseStep.getInstance().disable();
/*  67 */       if (this.page.getValue() == Page.EChest || this.page.getValue() == Page.Obsdidian) {
/*  68 */         this.startPos = new BlockPos(mc.field_71439_g.func_174791_d());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @Subscribe
/*     */   public void onUpdate() {
/*  76 */     int amount = 0;
/*  77 */     if (((Boolean)this.timerfill.getValue()).booleanValue()) {
/*  78 */       if (nullCheck()) {
/*     */         return;
/*     */       }
/*  81 */       if (mc.field_71439_g.field_70163_u > this.playerPos.func_177956_o() + 1.04D) {
/*  82 */         WorldUtil.placeBlock(this.playerPos, InventoryUtil.findHotbarBlock(Blocks.field_150343_Z));
/*  83 */         mc.field_71439_g.func_70664_aZ();
/*  84 */         disable();
/*     */       } 
/*     */     } 
/*  87 */     if (((Boolean)this.autoCenter.getValue()).booleanValue()) {
/*  88 */       Phobos.positionManager.setPositionPacket(this.startPos.func_177958_n() + 0.5D, this.startPos.func_177956_o(), this.startPos.func_177952_p() + 0.5D, true, true, true);
/*     */     }
/*  90 */     if (((Boolean)this.packetJump.getValue()).booleanValue()) {
/*  91 */       if (fullNullCheck()) {
/*     */         return;
/*     */       }
/*  94 */       int startSlot = mc.field_71439_g.field_71071_by.field_70461_c;
/*  95 */       if (this.page.getValue() == Page.EChest) {
/*  96 */         int enderSlot = ItemUtil.getItemFromHotbar(Item.func_150898_a(Blocks.field_150477_bB));
/*  97 */         ItemUtil.switchToHotbarSlot(enderSlot, false);
/*  98 */         if (enderSlot == -1) {
/*  99 */           Command.sendMessage("<" + getDisplayName() + "> out of echests.");
/* 100 */           disable();
/*     */           return;
/*     */         } 
/*     */       } 
/* 104 */       if (this.page.getValue() == Page.Obsdidian) {
/* 105 */         int obbySlot = ItemUtil.getItemFromHotbar(Item.func_150898_a(Blocks.field_150343_Z));
/* 106 */         ItemUtil.switchToHotbarSlot(obbySlot, false);
/* 107 */         if (obbySlot == -1) {
/* 108 */           Command.sendMessage("<" + getDisplayName() + "> out of obsidian.");
/* 109 */           disable();
/*     */           return;
/*     */         } 
/*     */       } 
/* 113 */       if (this.page.getValue() == Page.EChest || this.page.getValue() == Page.Obsdidian) {
/* 114 */         mc.func_147114_u().func_147297_a((Packet)new CPacketPlayer.Position(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + 0.4199999D + ((Float)this.extraboost.getValue()).floatValue(), mc.field_71439_g.field_70161_v, !((Boolean)this.offground.getValue()).booleanValue()));
/* 115 */         mc.func_147114_u().func_147297_a((Packet)new CPacketPlayer.Position(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + 0.7531999D + ((Float)this.extraboost.getValue()).floatValue(), mc.field_71439_g.field_70161_v, !((Boolean)this.offground.getValue()).booleanValue()));
/* 116 */         mc.func_147114_u().func_147297_a((Packet)new CPacketPlayer.Position(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + 1.0013359D + ((Float)this.extraboost.getValue()).floatValue(), mc.field_71439_g.field_70161_v, !((Boolean)this.offground.getValue()).booleanValue()));
/* 117 */         mc.func_147114_u().func_147297_a((Packet)new CPacketPlayer.Position(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + 1.1661092D + ((Float)this.extraboost.getValue()).floatValue(), mc.field_71439_g.field_70161_v, !((Boolean)this.offground.getValue()).booleanValue()));
/* 118 */         BlockUtil.placeBlock(this.startPos, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), true, false);
/* 119 */         mc.func_147114_u().func_147297_a((Packet)new CPacketPlayer.Position(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + ((Float)this.height.getValue()).floatValue(), mc.field_71439_g.field_70161_v, !((Boolean)this.offground.getValue()).booleanValue()));
/* 120 */         if (((Boolean)this.sneaking.getValue()).booleanValue()) {
/* 121 */           mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketEntityAction((Entity)mc.field_71439_g, CPacketEntityAction.Action.START_SNEAKING));
/* 122 */           mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketEntityAction((Entity)mc.field_71439_g, CPacketEntityAction.Action.STOP_SNEAKING));
/*     */         } 
/* 124 */         if (startSlot != -1) {
/* 125 */           ItemUtil.switchToHotbarSlot(startSlot, false);
/*     */         }
/* 127 */         disable();
/*     */       } 
/*     */     } 
/* 130 */     if (!this.settings.isEmpty()) {
/* 131 */       for (Setting setting : this.settings) {
/* 132 */         if (!(setting.getValue() instanceof Boolean) || !((Boolean)setting.getValue()).booleanValue() || setting.getName().equalsIgnoreCase("Enabled") || setting.getName().equalsIgnoreCase("drawn"))
/* 133 */           continue;  amount++;
/*     */       } 
/*     */     }
/* 136 */     this.hudAmount = amount;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/* 141 */     Phobos.moduleManager.getModuleByName("ReverseStep").isDisabled();
/* 142 */     ReverseStep.getInstance().enable();
/* 143 */     if (((Boolean)this.timerfill.getValue()).booleanValue()) {
/* 144 */       setTimer(1.0F);
/*     */     }
/*     */   }
/*     */   
/*     */   private void setTimer(float value) {
/*     */     try {
/* 150 */       Field timer = Minecraft.class.getDeclaredField(MappingUtil.timer);
/* 151 */       timer.setAccessible(true);
/* 152 */       Field tickLength = Timer.class.getDeclaredField(MappingUtil.tickLength);
/* 153 */       tickLength.setAccessible(true);
/* 154 */       tickLength.setFloat(timer.get(mc), 50.0F / value);
/*     */     }
/* 156 */     catch (Exception e) {
/* 157 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDisplayInfo() {
/* 163 */     if (this.hudAmount == 0) {
/* 164 */       return "";
/*     */     }
/* 166 */     return this.hudAmount + "";
/*     */   }
/*     */   
/*     */   public enum Page {
/* 170 */     EChest,
/* 171 */     Obsdidian,
/* 172 */     Soulsand;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\ShitClient\HayBale-1.0.1-b8.jar!\me\luxtix\haybale\features\modules\combat\InstantSelfFill.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */