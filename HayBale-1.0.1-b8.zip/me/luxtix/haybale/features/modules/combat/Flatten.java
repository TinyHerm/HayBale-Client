/*     */ package me.luxtix.haybale.features.modules.combat;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import me.luxtix.haybale.Phobos;
/*     */ import me.luxtix.haybale.features.modules.Module;
/*     */ import me.luxtix.haybale.features.setting.Setting;
/*     */ import me.luxtix.haybale.util.BlockUtil2;
/*     */ import me.luxtix.haybale.util.InventoryUtil2;
/*     */ import net.minecraft.block.BlockObsidian;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Flatten
/*     */   extends Module
/*     */ {
/*  24 */   private final Setting<Integer> blocksPerTick = register(new Setting("BlocksPerTick", Integer.valueOf(8), Integer.valueOf(1), Integer.valueOf(30)));
/*  25 */   private final Setting<Boolean> rotate = register(new Setting("Rotate", Boolean.valueOf(false)));
/*  26 */   private final Setting<Boolean> packet = register(new Setting("PacketPlace", Boolean.valueOf(false)));
/*  27 */   private final Setting<Float> distance = register(new Setting("TargetDistance", Float.valueOf(5.0F), Float.valueOf(0.0F), Float.valueOf(10.0F)));
/*  28 */   private final Setting<Boolean> autoDisable = register(new Setting("AutoDisable", Boolean.valueOf(true)));
/*  29 */   private final Vec3d[] offsetsDefault = new Vec3d[] { new Vec3d(0.0D, 0.0D, -1.0D), new Vec3d(0.0D, 0.0D, 1.0D), new Vec3d(1.0D, 0.0D, 0.0D), new Vec3d(-1.0D, 0.0D, 0.0D) };
/*     */   private EntityPlayer target;
/*     */   private int offsetStep;
/*     */   private int oldSlot;
/*     */   private boolean placing;
/*     */   
/*     */   public Flatten() {
/*  36 */     super("Flatten", "place blocks under player", Module.Category.COMBAT, true, false, false);
/*  37 */     this.offsetStep = 0;
/*  38 */     this.oldSlot = -1;
/*  39 */     this.placing = false;
/*     */   }
/*     */   
/*     */   public void onEnable() {
/*  43 */     this.oldSlot = mc.field_71439_g.field_71071_by.field_70461_c;
/*     */   }
/*     */   
/*     */   public void onDisable() {
/*  47 */     this.oldSlot = -1;
/*     */   }
/*     */   
/*     */   public void onUpdate() {
/*  51 */     EntityPlayer closest_target = findClosestTarget();
/*  52 */     int obbySlot = InventoryUtil2.findHotbarBlock(BlockObsidian.class);
/*  53 */     if (closest_target == null) {
/*  54 */       disable();
/*     */       return;
/*     */     } 
/*  57 */     List<Vec3d> place_targets = new ArrayList<>();
/*  58 */     Collections.addAll(place_targets, this.offsetsDefault);
/*  59 */     int blocks_placed = 0;
/*  60 */     while (blocks_placed < ((Integer)this.blocksPerTick.getValue()).intValue()) {
/*  61 */       if (this.offsetStep >= place_targets.size()) {
/*  62 */         this.offsetStep = 0;
/*     */         break;
/*     */       } 
/*  65 */       this.placing = true;
/*  66 */       BlockPos offset_pos = new BlockPos(place_targets.get(this.offsetStep));
/*  67 */       BlockPos target_pos = (new BlockPos(closest_target.func_174791_d())).func_177977_b().func_177982_a(offset_pos.func_177958_n(), offset_pos.func_177956_o(), offset_pos.func_177952_p());
/*  68 */       boolean should_try_place = mc.field_71441_e.func_180495_p(target_pos).func_185904_a().func_76222_j();
/*  69 */       for (Entity entity : mc.field_71441_e.func_72839_b((Entity)null, new AxisAlignedBB(target_pos))) {
/*  70 */         if (!(entity instanceof net.minecraft.entity.item.EntityItem) && !(entity instanceof net.minecraft.entity.item.EntityXPOrb)) {
/*  71 */           should_try_place = false;
/*     */           break;
/*     */         } 
/*     */       } 
/*  75 */       if (should_try_place) {
/*  76 */         place(target_pos, obbySlot, this.oldSlot);
/*  77 */         blocks_placed++;
/*     */       } 
/*  79 */       this.offsetStep++;
/*  80 */       this.placing = false;
/*     */     } 
/*  82 */     if (((Boolean)this.autoDisable.getValue()).booleanValue()) {
/*  83 */       disable();
/*     */     }
/*     */   }
/*     */   
/*     */   private void place(BlockPos pos, int slot, int oldSlot) {
/*  88 */     mc.field_71439_g.field_71071_by.field_70461_c = slot;
/*  89 */     mc.field_71442_b.func_78765_e();
/*  90 */     BlockUtil2.placeBlock(pos, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), mc.field_71439_g.func_70093_af());
/*  91 */     mc.field_71439_g.field_71071_by.field_70461_c = oldSlot;
/*  92 */     mc.field_71442_b.func_78765_e();
/*     */   }
/*     */   
/*     */   private EntityPlayer findClosestTarget() {
/*  96 */     if (mc.field_71441_e.field_73010_i.isEmpty()) {
/*  97 */       return null;
/*     */     }
/*  99 */     EntityPlayer closestTarget = null;
/* 100 */     for (EntityPlayer target : mc.field_71441_e.field_73010_i) {
/* 101 */       if (target == mc.field_71439_g || 
/* 102 */         !target.func_70089_S()) {
/*     */         continue;
/*     */       }
/* 105 */       if (Phobos.friendManager.isFriend(target.func_70005_c_())) {
/*     */         continue;
/*     */       }
/* 108 */       if (target.func_110143_aJ() <= 0.0F) {
/*     */         continue;
/*     */       }
/* 111 */       if (mc.field_71439_g.func_70032_d((Entity)target) > ((Float)this.distance.getValue()).floatValue()) {
/*     */         continue;
/*     */       }
/* 114 */       if (closestTarget != null && mc.field_71439_g.func_70032_d((Entity)target) > mc.field_71439_g.func_70032_d((Entity)closestTarget)) {
/*     */         continue;
/*     */       }
/* 117 */       closestTarget = target;
/*     */     } 
/*     */     
/* 120 */     return closestTarget;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\ShitClient\HayBale-1.0.1-b8.jar!\me\luxtix\haybale\features\modules\combat\Flatten.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */