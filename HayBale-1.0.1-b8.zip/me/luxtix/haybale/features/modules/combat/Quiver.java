/*    */ package me.luxtix.haybale.features.modules.combat;
/*    */ import java.util.List;
/*    */ import me.luxtix.haybale.features.modules.Module;
/*    */ import me.luxtix.haybale.features.setting.Setting;
/*    */ import me.luxtix.haybale.util.InventoryUtil2;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.init.Items;
/*    */ import net.minecraft.network.Packet;
/*    */ import net.minecraft.network.play.client.CPacketPlayer;
/*    */ import net.minecraft.potion.PotionUtils;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ 
/*    */ public class Quiver extends Module {
/* 14 */   private final Setting<Integer> tickDelay = register(new Setting("TickDelay", Integer.valueOf(3), Integer.valueOf(0), Integer.valueOf(8)));
/*    */   public Quiver() {
/* 16 */     super("Quiver", "Rotates and shoots yourself with good potion effects", Module.Category.COMBAT, true, false, false);
/*    */   }
/*    */   
/*    */   public void onUpdate() {
/* 20 */     if (mc.field_71439_g != null) {
/* 21 */       if (mc.field_71439_g.field_71071_by.func_70448_g().func_77973_b() instanceof net.minecraft.item.ItemBow && mc.field_71439_g.func_184587_cr() && mc.field_71439_g.func_184612_cw() >= ((Integer)this.tickDelay.getValue()).intValue()) {
/* 22 */         mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Rotation(mc.field_71439_g.field_71109_bG, -90.0F, mc.field_71439_g.field_70122_E));
/* 23 */         mc.field_71442_b.func_78766_c((EntityPlayer)mc.field_71439_g);
/*    */       } 
/* 25 */       List<Integer> arrowSlots = InventoryUtil2.getItemInventory(Items.field_185167_i);
/* 26 */       if (((Integer)arrowSlots.get(0)).intValue() == -1)
/* 27 */         return;  int speedSlot = -1;
/* 28 */       int strengthSlot = -1;
/* 29 */       for (Integer slot : arrowSlots) {
/*    */         
/* 31 */         if (PotionUtils.func_185191_c(mc.field_71439_g.field_71071_by.func_70301_a(slot.intValue())).getRegistryName().func_110623_a().contains("swiftness")) { speedSlot = slot.intValue(); continue; }
/* 32 */          if (((ResourceLocation)Objects.<ResourceLocation>requireNonNull(PotionUtils.func_185191_c(mc.field_71439_g.field_71071_by.func_70301_a(slot.intValue())).getRegistryName())).func_110623_a().contains("strength")) strengthSlot = slot.intValue();
/*    */       
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void onEnable() {}
/*    */ 
/*    */   
/*    */   private int findBow() {
/* 43 */     return InventoryUtil2.getItemHotbar((Item)Items.field_151031_f);
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\ShitClient\HayBale-1.0.1-b8.jar!\me\luxtix\haybale\features\modules\combat\Quiver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */