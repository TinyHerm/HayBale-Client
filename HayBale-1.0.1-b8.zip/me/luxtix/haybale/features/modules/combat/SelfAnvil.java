/*    */ package me.luxtix.haybale.features.modules.combat;
/*    */ import me.luxtix.haybale.features.modules.Module;
/*    */ import me.luxtix.haybale.features.setting.Setting;
/*    */ import me.luxtix.haybale.util.BlockUtil;
/*    */ import me.luxtix.haybale.util.EntityUtil2;
/*    */ import me.luxtix.haybale.util.InventoryUtil;
/*    */ import me.luxtix.haybale.util.PlayerUtil2;
/*    */ import net.minecraft.block.BlockAnvil;
/*    */ import net.minecraft.client.entity.EntityPlayerSP;
/*    */ import net.minecraft.util.EnumHand;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ 
/*    */ public class SelfAnvil extends Module {
/*    */   public SelfAnvil() {
/* 15 */     super("SelfAnvil", "Drops anvil on you.", Module.Category.COMBAT, true, false, false);
/*    */ 
/*    */     
/* 18 */     this.ammount = register(new Setting("Ammount", Integer.valueOf(1), Integer.valueOf(1), Integer.valueOf(2)));
/* 19 */     this.rotate = register(new Setting("Rotate", Boolean.valueOf(false)));
/*    */   }
/*    */   Setting<Integer> ammount; Setting<Boolean> rotate;
/*    */   private int placedAmmount;
/*    */   
/*    */   public void onEnable() {
/* 25 */     this.placedAmmount = 0;
/* 26 */     if (InventoryUtil.findHotbarBlock(BlockAnvil.class) == -1 || PlayerUtil2.findObiInHotbar() == -1) {
/* 27 */       disable();
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void onTick() {
/* 33 */     EntityPlayerSP entityPlayerSP = mc.field_71439_g;
/* 34 */     if (entityPlayerSP == null || this.placedAmmount >= ((Integer)this.ammount.getValue()).intValue())
/* 35 */       return;  BlockPos anvilPos = EntityUtil2.getFlooredPos((Entity)entityPlayerSP).func_177981_b(2);
/* 36 */     if (BlockUtil2.canPlaceBlock(anvilPos)) {
/* 37 */       placeAnvil(anvilPos);
/* 38 */       this.placedAmmount++;
/*    */     } else {
/* 40 */       placeObi(anvilPos.func_177977_b().func_177974_f());
/* 41 */       placeObi(anvilPos.func_177974_f());
/*    */     } 
/*    */   }
/*    */   
/*    */   private void placeAnvil(BlockPos pos) {
/* 46 */     int old = mc.field_71439_g.field_71071_by.field_70461_c;
/* 47 */     switchToSlot(InventoryUtil.findHotbarBlock(BlockAnvil.class));
/* 48 */     BlockUtil.placeBlock(pos, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), true, false);
/* 49 */     switchToSlot(old);
/* 50 */     toggle();
/*    */   }
/*    */   
/*    */   private void placeObi(BlockPos pos) {
/* 54 */     int old = mc.field_71439_g.field_71071_by.field_70461_c;
/* 55 */     switchToSlot(PlayerUtil2.findObiInHotbar());
/* 56 */     BlockUtil.placeBlock(pos, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), true, false);
/* 57 */     switchToSlot(old);
/*    */   }
/*    */ 
/*    */   
/*    */   private void switchToSlot(int slot) {
/* 62 */     mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketHeldItemChange(slot));
/* 63 */     mc.field_71439_g.field_71071_by.field_70461_c = slot;
/* 64 */     mc.field_71442_b.func_78765_e();
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\ShitClient\HayBale-1.0.1-b8.jar!\me\luxtix\haybale\features\modules\combat\SelfAnvil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */