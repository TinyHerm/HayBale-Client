/*     */ package me.luxtix.haybale.features.modules.combat;
/*     */ 
/*     */ import com.google.common.util.concurrent.AtomicDouble;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.stream.Collectors;
/*     */ import me.luxtix.haybale.Phobos;
/*     */ import me.luxtix.haybale.event.events.PacketEvent;
/*     */ import me.luxtix.haybale.event.events.UpdateWalkingPlayerEvent;
/*     */ import me.luxtix.haybale.features.modules.Module;
/*     */ import me.luxtix.haybale.features.modules.client.ClickGui;
/*     */ import me.luxtix.haybale.features.modules.client.ServerModule;
/*     */ import me.luxtix.haybale.features.setting.Setting;
/*     */ import me.luxtix.haybale.util.BlockUtil;
/*     */ import me.luxtix.haybale.util.DamageUtil;
/*     */ import me.luxtix.haybale.util.EntityUtil;
/*     */ import me.luxtix.haybale.util.InventoryUtil;
/*     */ import me.luxtix.haybale.util.MathUtil;
/*     */ import me.luxtix.haybale.util.RotationUtil;
/*     */ import me.luxtix.haybale.util.Timer;
/*     */ import net.minecraft.block.BlockPlanks;
/*     */ import net.minecraft.block.BlockWorkbench;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.client.gui.inventory.GuiContainer;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.inventory.ClickType;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketChatMessage;
/*     */ import net.minecraft.network.play.client.CPacketEntityAction;
/*     */ import net.minecraft.network.play.client.CPacketHeldItemChange;
/*     */ import net.minecraft.network.play.client.CPacketPlayer;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.tileentity.TileEntityBed;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.RayTraceResult;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.util.math.Vec3i;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ public class BedAura extends Module {
/*  50 */   private final Setting<Boolean> server = register(new Setting("Server", Boolean.valueOf(false)));
/*     */   
/*  52 */   private final Setting<Boolean> place = register(new Setting("Place", Boolean.valueOf(false)));
/*     */   
/*  54 */   private final Setting<Integer> placeDelay = register(new Setting("Placedelay", Integer.valueOf(50), Integer.valueOf(0), Integer.valueOf(500), v -> ((Boolean)this.place.getValue()).booleanValue()));
/*     */   
/*  56 */   private final Setting<Float> placeRange = register(new Setting("PlaceRange", Float.valueOf(6.0F), Float.valueOf(1.0F), Float.valueOf(10.0F), v -> ((Boolean)this.place.getValue()).booleanValue()));
/*     */   
/*  58 */   private final Setting<Boolean> extraPacket = register(new Setting("InsanePacket", Boolean.valueOf(false), v -> ((Boolean)this.place.getValue()).booleanValue()));
/*     */   
/*  60 */   private final Setting<Boolean> packet = register(new Setting("Packet", Boolean.valueOf(false), v -> ((Boolean)this.place.getValue()).booleanValue()));
/*     */   
/*  62 */   private final Setting<Boolean> explode = register(new Setting("Break", Boolean.valueOf(true)));
/*     */   
/*  64 */   private final Setting<BreakLogic> breakMode = register(new Setting("BreakMode", BreakLogic.ALL, v -> ((Boolean)this.explode.getValue()).booleanValue()));
/*     */   
/*  66 */   private final Setting<Integer> breakDelay = register(new Setting("Breakdelay", Integer.valueOf(50), Integer.valueOf(0), Integer.valueOf(500), v -> ((Boolean)this.explode.getValue()).booleanValue()));
/*     */   
/*  68 */   private final Setting<Float> breakRange = register(new Setting("BreakRange", Float.valueOf(6.0F), Float.valueOf(1.0F), Float.valueOf(10.0F), v -> ((Boolean)this.explode.getValue()).booleanValue()));
/*     */   
/*  70 */   private final Setting<Float> minDamage = register(new Setting("MinDamage", Float.valueOf(5.0F), Float.valueOf(1.0F), Float.valueOf(36.0F), v -> ((Boolean)this.explode.getValue()).booleanValue()));
/*     */   
/*  72 */   private final Setting<Float> range = register(new Setting("Range", Float.valueOf(10.0F), Float.valueOf(1.0F), Float.valueOf(12.0F), v -> ((Boolean)this.explode.getValue()).booleanValue()));
/*     */   
/*  74 */   private final Setting<Boolean> suicide = register(new Setting("Suicide", Boolean.valueOf(false), v -> ((Boolean)this.explode.getValue()).booleanValue()));
/*     */   
/*  76 */   private final Setting<Boolean> removeTiles = register(new Setting("RemoveTiles", Boolean.valueOf(false)));
/*     */   
/*  78 */   private final Setting<Boolean> rotate = register(new Setting("Rotate", Boolean.valueOf(false)));
/*     */   
/*  80 */   private final Setting<Boolean> oneDot15 = register(new Setting("1.15", Boolean.valueOf(false)));
/*     */   
/*  82 */   private final Setting<Logic> logic = register(new Setting("Logic", Logic.BREAKPLACE, v -> (((Boolean)this.place.getValue()).booleanValue() && ((Boolean)this.explode.getValue()).booleanValue())));
/*     */   
/*  84 */   private final Setting<Boolean> craft = register(new Setting("Craft", Boolean.valueOf(false)));
/*     */   
/*  86 */   private final Setting<Boolean> placeCraftingTable = register(new Setting("PlaceTable", Boolean.valueOf(false), v -> ((Boolean)this.craft.getValue()).booleanValue()));
/*     */   
/*  88 */   private final Setting<Boolean> openCraftingTable = register(new Setting("OpenTable", Boolean.valueOf(false), v -> ((Boolean)this.craft.getValue()).booleanValue()));
/*     */   
/*  90 */   private final Setting<Boolean> craftTable = register(new Setting("CraftTable", Boolean.valueOf(false), v -> ((Boolean)this.craft.getValue()).booleanValue()));
/*     */   
/*  92 */   private final Setting<Float> tableRange = register(new Setting("TableRange", Float.valueOf(6.0F), Float.valueOf(1.0F), Float.valueOf(10.0F), v -> ((Boolean)this.craft.getValue()).booleanValue()));
/*     */   
/*  94 */   private final Setting<Integer> craftDelay = register(new Setting("CraftDelay", Integer.valueOf(4), Integer.valueOf(1), Integer.valueOf(10), v -> ((Boolean)this.craft.getValue()).booleanValue()));
/*     */   
/*  96 */   private final Setting<Integer> tableSlot = register(new Setting("TableSlot", Integer.valueOf(8), Integer.valueOf(0), Integer.valueOf(8), v -> ((Boolean)this.craft.getValue()).booleanValue()));
/*     */   
/*  98 */   private final Setting<Boolean> sslot = register(new Setting("S-Slot", Boolean.valueOf(false)));
/*     */   
/* 100 */   private final Timer breakTimer = new Timer();
/*     */   
/* 102 */   private final Timer placeTimer = new Timer();
/*     */   
/* 104 */   private final Timer craftTimer = new Timer();
/*     */   
/* 106 */   private EntityPlayer target = null;
/*     */   
/*     */   private boolean sendRotationPacket = false;
/*     */   
/* 110 */   private final AtomicDouble yaw = new AtomicDouble(-1.0D);
/*     */   
/* 112 */   private final AtomicDouble pitch = new AtomicDouble(-1.0D);
/*     */   
/* 114 */   private final AtomicBoolean shouldRotate = new AtomicBoolean(false);
/*     */   
/*     */   private boolean one;
/*     */   
/*     */   private boolean two;
/*     */   
/*     */   private boolean three;
/*     */   
/*     */   private boolean four;
/*     */   
/*     */   private boolean five;
/*     */   
/*     */   private boolean six;
/*     */   
/*     */   private boolean seven;
/*     */   
/*     */   private boolean eight;
/*     */   
/*     */   private boolean nine;
/*     */   
/*     */   private boolean ten;
/*     */   
/* 136 */   private BlockPos maxPos = null;
/*     */   
/*     */   private boolean shouldCraft;
/*     */   
/* 140 */   private int craftStage = 0;
/*     */   
/* 142 */   private int lastCraftStage = -1;
/*     */   
/* 144 */   private int lastHotbarSlot = -1;
/*     */   
/* 146 */   private int bedSlot = -1;
/*     */   
/*     */   private BlockPos finalPos;
/*     */   
/*     */   private EnumFacing finalFacing;
/*     */   
/*     */   public BedAura() {
/* 153 */     super("BedAura", "AutoPlace and Break for beds", Module.Category.COMBAT, true, false, false);
/*     */   }
/*     */   
/*     */   public void onEnable() {
/* 157 */     if (!fullNullCheck() && shouldServer()) {
/* 158 */       mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketChatMessage("@Serverprefix" + (String)(ClickGui.getInstance()).prefix.getValue()));
/* 159 */       mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketChatMessage("@Server" + (String)(ClickGui.getInstance()).prefix.getValue() + "module BedBomb set Enabled true"));
/*     */     } 
/*     */   }
/*     */   
/*     */   public void onDisable() {
/* 164 */     if (!fullNullCheck() && shouldServer()) {
/* 165 */       mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketChatMessage("@Serverprefix" + (String)(ClickGui.getInstance()).prefix.getValue()));
/* 166 */       mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketChatMessage("@Server" + (String)(ClickGui.getInstance()).prefix.getValue() + "module BedBomb set Enabled false"));
/* 167 */       if (((Boolean)this.sslot.getValue()).booleanValue())
/* 168 */         mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketHeldItemChange(mc.field_71439_g.field_71071_by.field_70461_c)); 
/*     */     } 
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPacket(PacketEvent.Send event) {
/* 174 */     if (this.shouldRotate.get() && event.getPacket() instanceof CPacketPlayer) {
/* 175 */       CPacketPlayer packet = (CPacketPlayer)event.getPacket();
/* 176 */       packet.field_149476_e = (float)this.yaw.get();
/* 177 */       packet.field_149473_f = (float)this.pitch.get();
/* 178 */       this.shouldRotate.set(false);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean shouldServer() {
/* 183 */     return (ServerModule.getInstance().isConnected() && ((Boolean)this.server.getValue()).booleanValue());
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onUpdateWalkingPlayer(UpdateWalkingPlayerEvent event) {
/* 188 */     if (fullNullCheck() || (mc.field_71439_g.field_71093_bK != -1 && mc.field_71439_g.field_71093_bK != 1) || shouldServer())
/*     */       return; 
/* 190 */     if (event.getStage() == 0) {
/* 191 */       doBedBomb();
/* 192 */       if (this.shouldCraft && mc.field_71462_r instanceof net.minecraft.client.gui.inventory.GuiCrafting) {
/* 193 */         int woolSlot = InventoryUtil.findInventoryWool(false);
/* 194 */         int woodSlot = InventoryUtil.findInventoryBlock(BlockPlanks.class, true);
/* 195 */         if (woolSlot == -1 || woodSlot == -1) {
/* 196 */           mc.func_147108_a(null);
/* 197 */           mc.field_71462_r = null;
/* 198 */           this.shouldCraft = false;
/*     */           return;
/*     */         } 
/* 201 */         if (this.craftStage > 1 && !this.one) {
/* 202 */           mc.field_71442_b.func_187098_a(((GuiContainer)mc.field_71462_r).field_147002_h.field_75152_c, woolSlot, 0, ClickType.PICKUP, (EntityPlayer)mc.field_71439_g);
/* 203 */           mc.field_71442_b.func_187098_a(((GuiContainer)mc.field_71462_r).field_147002_h.field_75152_c, 1, 1, ClickType.PICKUP, (EntityPlayer)mc.field_71439_g);
/* 204 */           mc.field_71442_b.func_187098_a(((GuiContainer)mc.field_71462_r).field_147002_h.field_75152_c, woolSlot, 0, ClickType.PICKUP, (EntityPlayer)mc.field_71439_g);
/* 205 */           this.one = true;
/* 206 */         } else if (this.craftStage > 1 + ((Integer)this.craftDelay.getValue()).intValue() && !this.two) {
/* 207 */           mc.field_71442_b.func_187098_a(((GuiContainer)mc.field_71462_r).field_147002_h.field_75152_c, woolSlot, 0, ClickType.PICKUP, (EntityPlayer)mc.field_71439_g);
/* 208 */           mc.field_71442_b.func_187098_a(((GuiContainer)mc.field_71462_r).field_147002_h.field_75152_c, 2, 1, ClickType.PICKUP, (EntityPlayer)mc.field_71439_g);
/* 209 */           mc.field_71442_b.func_187098_a(((GuiContainer)mc.field_71462_r).field_147002_h.field_75152_c, woolSlot, 0, ClickType.PICKUP, (EntityPlayer)mc.field_71439_g);
/* 210 */           this.two = true;
/* 211 */         } else if (this.craftStage > 1 + ((Integer)this.craftDelay.getValue()).intValue() * 2 && !this.three) {
/* 212 */           mc.field_71442_b.func_187098_a(((GuiContainer)mc.field_71462_r).field_147002_h.field_75152_c, woolSlot, 0, ClickType.PICKUP, (EntityPlayer)mc.field_71439_g);
/* 213 */           mc.field_71442_b.func_187098_a(((GuiContainer)mc.field_71462_r).field_147002_h.field_75152_c, 3, 1, ClickType.PICKUP, (EntityPlayer)mc.field_71439_g);
/* 214 */           mc.field_71442_b.func_187098_a(((GuiContainer)mc.field_71462_r).field_147002_h.field_75152_c, woolSlot, 0, ClickType.PICKUP, (EntityPlayer)mc.field_71439_g);
/* 215 */           this.three = true;
/* 216 */         } else if (this.craftStage > 1 + ((Integer)this.craftDelay.getValue()).intValue() * 3 && !this.four) {
/* 217 */           mc.field_71442_b.func_187098_a(((GuiContainer)mc.field_71462_r).field_147002_h.field_75152_c, woodSlot, 0, ClickType.PICKUP, (EntityPlayer)mc.field_71439_g);
/* 218 */           mc.field_71442_b.func_187098_a(((GuiContainer)mc.field_71462_r).field_147002_h.field_75152_c, 4, 1, ClickType.PICKUP, (EntityPlayer)mc.field_71439_g);
/* 219 */           mc.field_71442_b.func_187098_a(((GuiContainer)mc.field_71462_r).field_147002_h.field_75152_c, woodSlot, 0, ClickType.PICKUP, (EntityPlayer)mc.field_71439_g);
/* 220 */           this.four = true;
/* 221 */         } else if (this.craftStage > 1 + ((Integer)this.craftDelay.getValue()).intValue() * 4 && !this.five) {
/* 222 */           mc.field_71442_b.func_187098_a(((GuiContainer)mc.field_71462_r).field_147002_h.field_75152_c, woodSlot, 0, ClickType.PICKUP, (EntityPlayer)mc.field_71439_g);
/* 223 */           mc.field_71442_b.func_187098_a(((GuiContainer)mc.field_71462_r).field_147002_h.field_75152_c, 5, 1, ClickType.PICKUP, (EntityPlayer)mc.field_71439_g);
/* 224 */           mc.field_71442_b.func_187098_a(((GuiContainer)mc.field_71462_r).field_147002_h.field_75152_c, woodSlot, 0, ClickType.PICKUP, (EntityPlayer)mc.field_71439_g);
/* 225 */           this.five = true;
/* 226 */         } else if (this.craftStage > 1 + ((Integer)this.craftDelay.getValue()).intValue() * 5 && !this.six) {
/* 227 */           mc.field_71442_b.func_187098_a(((GuiContainer)mc.field_71462_r).field_147002_h.field_75152_c, woodSlot, 0, ClickType.PICKUP, (EntityPlayer)mc.field_71439_g);
/* 228 */           mc.field_71442_b.func_187098_a(((GuiContainer)mc.field_71462_r).field_147002_h.field_75152_c, 6, 1, ClickType.PICKUP, (EntityPlayer)mc.field_71439_g);
/* 229 */           mc.field_71442_b.func_187098_a(((GuiContainer)mc.field_71462_r).field_147002_h.field_75152_c, woodSlot, 0, ClickType.PICKUP, (EntityPlayer)mc.field_71439_g);
/* 230 */           recheckBedSlots(woolSlot, woodSlot);
/* 231 */           mc.field_71442_b.func_187098_a(((GuiContainer)mc.field_71462_r).field_147002_h.field_75152_c, 0, 0, ClickType.QUICK_MOVE, (EntityPlayer)mc.field_71439_g);
/* 232 */           this.six = true;
/* 233 */           this.one = false;
/* 234 */           this.two = false;
/* 235 */           this.three = false;
/* 236 */           this.four = false;
/* 237 */           this.five = false;
/* 238 */           this.six = false;
/* 239 */           this.craftStage = -2;
/* 240 */           this.shouldCraft = false;
/*     */         } 
/* 242 */         this.craftStage++;
/*     */       } 
/* 244 */     } else if (event.getStage() == 1 && this.finalPos != null) {
/* 245 */       Vec3d hitVec = (new Vec3d((Vec3i)this.finalPos.func_177977_b())).func_72441_c(0.5D, 0.5D, 0.5D).func_178787_e((new Vec3d(this.finalFacing.func_176734_d().func_176730_m())).func_186678_a(0.5D));
/* 246 */       mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketEntityAction((Entity)mc.field_71439_g, CPacketEntityAction.Action.START_SNEAKING));
/* 247 */       InventoryUtil.switchToHotbarSlot(this.bedSlot, false);
/* 248 */       BlockUtil.rightClickBlock(this.finalPos.func_177977_b(), hitVec, (this.bedSlot == -2) ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, EnumFacing.UP, ((Boolean)this.packet.getValue()).booleanValue());
/* 249 */       mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketEntityAction((Entity)mc.field_71439_g, CPacketEntityAction.Action.STOP_SNEAKING));
/* 250 */       this.placeTimer.reset();
/* 251 */       this.finalPos = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void recheckBedSlots(int woolSlot, int woodSlot) {
/*     */     int i;
/* 257 */     for (i = 1; i <= 3; i++) {
/* 258 */       if (mc.field_71439_g.field_71070_bA.func_75138_a().get(i) == ItemStack.field_190927_a) {
/* 259 */         mc.field_71442_b.func_187098_a(1, woolSlot, 0, ClickType.PICKUP, (EntityPlayer)mc.field_71439_g);
/* 260 */         mc.field_71442_b.func_187098_a(1, i, 1, ClickType.PICKUP, (EntityPlayer)mc.field_71439_g);
/* 261 */         mc.field_71442_b.func_187098_a(1, woolSlot, 0, ClickType.PICKUP, (EntityPlayer)mc.field_71439_g);
/*     */       } 
/*     */     } 
/* 264 */     for (i = 4; i <= 6; i++) {
/* 265 */       if (mc.field_71439_g.field_71070_bA.func_75138_a().get(i) == ItemStack.field_190927_a) {
/* 266 */         mc.field_71442_b.func_187098_a(1, woodSlot, 0, ClickType.PICKUP, (EntityPlayer)mc.field_71439_g);
/* 267 */         mc.field_71442_b.func_187098_a(1, i, 1, ClickType.PICKUP, (EntityPlayer)mc.field_71439_g);
/* 268 */         mc.field_71442_b.func_187098_a(1, woodSlot, 0, ClickType.PICKUP, (EntityPlayer)mc.field_71439_g);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void incrementCraftStage() {
/* 274 */     if (this.craftTimer.passedMs(((Integer)this.craftDelay.getValue()).intValue())) {
/* 275 */       this.craftStage++;
/* 276 */       if (this.craftStage > 9)
/* 277 */         this.craftStage = 0; 
/* 278 */       this.craftTimer.reset();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void doBedBomb() {
/* 283 */     switch ((Logic)this.logic.getValue()) {
/*     */       case BREAKPLACE:
/* 285 */         mapBeds();
/* 286 */         breakBeds();
/* 287 */         placeBeds();
/*     */         break;
/*     */       case PLACEBREAK:
/* 290 */         mapBeds();
/* 291 */         placeBeds();
/* 292 */         breakBeds();
/*     */         break;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void breakBeds() {
/* 298 */     if (((Boolean)this.explode.getValue()).booleanValue() && this.breakTimer.passedMs(((Integer)this.breakDelay.getValue()).intValue()))
/* 299 */       if (this.breakMode.getValue() == BreakLogic.CALC) {
/* 300 */         if (this.maxPos != null) {
/* 301 */           Vec3d hitVec = (new Vec3d((Vec3i)this.maxPos)).func_72441_c(0.5D, 0.5D, 0.5D);
/* 302 */           float[] rotations = RotationUtil.getLegitRotations(hitVec);
/* 303 */           this.yaw.set(rotations[0]);
/* 304 */           if (((Boolean)this.rotate.getValue()).booleanValue()) {
/* 305 */             this.shouldRotate.set(true);
/* 306 */             this.pitch.set(rotations[1]);
/*     */           } 
/*     */           RayTraceResult result;
/* 309 */           EnumFacing facing = ((result = mc.field_71441_e.func_72933_a(new Vec3d(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + mc.field_71439_g.func_70047_e(), mc.field_71439_g.field_70161_v), new Vec3d(this.maxPos.func_177958_n() + 0.5D, this.maxPos.func_177956_o() - 0.5D, this.maxPos.func_177952_p() + 0.5D))) == null || result.field_178784_b == null) ? EnumFacing.UP : result.field_178784_b;
/* 310 */           BlockUtil.rightClickBlock(this.maxPos, hitVec, EnumHand.MAIN_HAND, facing, true);
/* 311 */           this.breakTimer.reset();
/*     */         } 
/*     */       } else {
/* 314 */         for (TileEntity entityBed : mc.field_71441_e.field_147482_g) {
/* 315 */           if (!(entityBed instanceof TileEntityBed) || mc.field_71439_g.func_174818_b(entityBed.func_174877_v()) > MathUtil.square(((Float)this.breakRange.getValue()).floatValue()))
/*     */             continue; 
/* 317 */           Vec3d hitVec = (new Vec3d((Vec3i)entityBed.func_174877_v())).func_72441_c(0.5D, 0.5D, 0.5D);
/* 318 */           float[] rotations = RotationUtil.getLegitRotations(hitVec);
/* 319 */           this.yaw.set(rotations[0]);
/* 320 */           if (((Boolean)this.rotate.getValue()).booleanValue()) {
/* 321 */             this.shouldRotate.set(true);
/* 322 */             this.pitch.set(rotations[1]);
/*     */           } 
/*     */           RayTraceResult result;
/* 325 */           EnumFacing facing = ((result = mc.field_71441_e.func_72933_a(new Vec3d(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + mc.field_71439_g.func_70047_e(), mc.field_71439_g.field_70161_v), new Vec3d(entityBed.func_174877_v().func_177958_n() + 0.5D, entityBed.func_174877_v().func_177956_o() - 0.5D, entityBed.func_174877_v().func_177952_p() + 0.5D))) == null || result.field_178784_b == null) ? EnumFacing.UP : result.field_178784_b;
/* 326 */           BlockUtil.rightClickBlock(entityBed.func_174877_v(), hitVec, EnumHand.MAIN_HAND, facing, true);
/* 327 */           this.breakTimer.reset();
/*     */         } 
/*     */       }  
/*     */   }
/*     */   
/*     */   private void mapBeds() {
/* 333 */     this.maxPos = null;
/* 334 */     float maxDamage = 0.5F;
/* 335 */     if (((Boolean)this.removeTiles.getValue()).booleanValue()) {
/* 336 */       ArrayList<BedData> removedBlocks = new ArrayList<>();
/* 337 */       for (TileEntity tile : mc.field_71441_e.field_147482_g) {
/* 338 */         if (!(tile instanceof TileEntityBed))
/*     */           continue; 
/* 340 */         TileEntityBed bed = (TileEntityBed)tile;
/* 341 */         BedData data = new BedData(tile.func_174877_v(), mc.field_71441_e.func_180495_p(tile.func_174877_v()), bed, bed.func_193050_e());
/* 342 */         removedBlocks.add(data);
/*     */       } 
/* 344 */       for (BedData data : removedBlocks)
/* 345 */         mc.field_71441_e.func_175698_g(data.getPos()); 
/* 346 */       for (BedData data : removedBlocks) {
/*     */         float selfDamage;
/*     */         BlockPos pos;
/* 349 */         if (!data.isHeadPiece() || mc.field_71439_g.func_174818_b(pos = data.getPos()) > MathUtil.square(((Float)this.breakRange.getValue()).floatValue()) || ((selfDamage = DamageUtil.calculateDamage(pos, (Entity)mc.field_71439_g)) + 1.0D >= EntityUtil.getHealth((Entity)mc.field_71439_g) && DamageUtil.canTakeDamage(((Boolean)this.suicide.getValue()).booleanValue())))
/*     */           continue; 
/* 351 */         for (EntityPlayer player : mc.field_71441_e.field_73010_i) {
/*     */           float damage;
/* 353 */           if (player.func_174818_b(pos) >= MathUtil.square(((Float)this.range.getValue()).floatValue()) || !EntityUtil.isValid((Entity)player, (((Float)this.range.getValue()).floatValue() + ((Float)this.breakRange.getValue()).floatValue())) || ((damage = DamageUtil.calculateDamage(pos, (Entity)player)) <= selfDamage && (damage <= ((Float)this.minDamage.getValue()).floatValue() || DamageUtil.canTakeDamage(((Boolean)this.suicide.getValue()).booleanValue())) && damage <= EntityUtil.getHealth((Entity)player)) || damage <= maxDamage)
/*     */             continue; 
/* 355 */           maxDamage = damage;
/* 356 */           this.maxPos = pos;
/*     */         } 
/*     */       } 
/* 359 */       for (BedData data : removedBlocks)
/* 360 */         mc.field_71441_e.func_175656_a(data.getPos(), data.getState()); 
/*     */     } else {
/* 362 */       for (TileEntity tile : mc.field_71441_e.field_147482_g) {
/*     */         float selfDamage;
/*     */         BlockPos pos;
/*     */         TileEntityBed bed;
/* 366 */         if (!(tile instanceof TileEntityBed) || !(bed = (TileEntityBed)tile).func_193050_e() || mc.field_71439_g.func_174818_b(pos = bed.func_174877_v()) > MathUtil.square(((Float)this.breakRange.getValue()).floatValue()) || ((selfDamage = DamageUtil.calculateDamage(pos, (Entity)mc.field_71439_g)) + 1.0D >= EntityUtil.getHealth((Entity)mc.field_71439_g) && DamageUtil.canTakeDamage(((Boolean)this.suicide.getValue()).booleanValue())))
/*     */           continue; 
/* 368 */         for (EntityPlayer player : mc.field_71441_e.field_73010_i) {
/*     */           float damage;
/* 370 */           if (player.func_174818_b(pos) >= MathUtil.square(((Float)this.range.getValue()).floatValue()) || !EntityUtil.isValid((Entity)player, (((Float)this.range.getValue()).floatValue() + ((Float)this.breakRange.getValue()).floatValue())) || ((damage = DamageUtil.calculateDamage(pos, (Entity)player)) <= selfDamage && (damage <= ((Float)this.minDamage.getValue()).floatValue() || DamageUtil.canTakeDamage(((Boolean)this.suicide.getValue()).booleanValue())) && damage <= EntityUtil.getHealth((Entity)player)) || damage <= maxDamage)
/*     */             continue; 
/* 372 */           maxDamage = damage;
/* 373 */           this.maxPos = pos;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void placeBeds() {
/* 380 */     if (((Boolean)this.place.getValue()).booleanValue() && this.placeTimer.passedMs(((Integer)this.placeDelay.getValue()).intValue()) && this.maxPos == null) {
/* 381 */       this.bedSlot = findBedSlot();
/* 382 */       if (this.bedSlot == -1)
/* 383 */         if (mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_151104_aV) {
/* 384 */           this.bedSlot = -2;
/*     */         } else {
/* 386 */           if (((Boolean)this.craft.getValue()).booleanValue() && !this.shouldCraft && EntityUtil.getClosestEnemy(((Float)this.placeRange.getValue()).floatValue()) != null)
/* 387 */             doBedCraft(); 
/*     */           return;
/*     */         }  
/* 390 */       this.lastHotbarSlot = mc.field_71439_g.field_71071_by.field_70461_c;
/* 391 */       this.target = EntityUtil.getClosestEnemy(((Float)this.placeRange.getValue()).floatValue());
/* 392 */       if (this.target != null) {
/* 393 */         BlockPos targetPos = new BlockPos(this.target.func_174791_d());
/* 394 */         placeBed(targetPos, true);
/* 395 */         if (((Boolean)this.craft.getValue()).booleanValue())
/* 396 */           doBedCraft(); 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void placeBed(BlockPos pos, boolean firstCheck) {
/* 402 */     if (mc.field_71441_e.func_180495_p(pos).func_177230_c() == Blocks.field_150324_C)
/*     */       return; 
/* 404 */     float damage = DamageUtil.calculateDamage(pos, (Entity)mc.field_71439_g);
/* 405 */     if (damage > EntityUtil.getHealth((Entity)mc.field_71439_g) + 0.5D) {
/* 406 */       if (firstCheck && ((Boolean)this.oneDot15.getValue()).booleanValue())
/* 407 */         placeBed(pos.func_177984_a(), false); 
/*     */       return;
/*     */     } 
/* 410 */     if (!mc.field_71441_e.func_180495_p(pos).func_185904_a().func_76222_j()) {
/* 411 */       if (firstCheck && ((Boolean)this.oneDot15.getValue()).booleanValue())
/* 412 */         placeBed(pos.func_177984_a(), false); 
/*     */       return;
/*     */     } 
/* 415 */     ArrayList<BlockPos> positions = new ArrayList<>();
/* 416 */     HashMap<BlockPos, EnumFacing> facings = new HashMap<>();
/* 417 */     for (EnumFacing facing : EnumFacing.values()) {
/*     */       BlockPos position;
/* 419 */       if (facing != EnumFacing.DOWN && facing != EnumFacing.UP && mc.field_71439_g.func_174818_b(position = pos.func_177972_a(facing)) <= MathUtil.square(((Float)this.placeRange.getValue()).floatValue()) && mc.field_71441_e.func_180495_p(position).func_185904_a().func_76222_j() && !mc.field_71441_e.func_180495_p(position.func_177977_b()).func_185904_a().func_76222_j()) {
/* 420 */         positions.add(position);
/* 421 */         facings.put(position, facing.func_176734_d());
/*     */       } 
/*     */     } 
/* 424 */     if (positions.isEmpty()) {
/* 425 */       if (firstCheck && ((Boolean)this.oneDot15.getValue()).booleanValue())
/* 426 */         placeBed(pos.func_177984_a(), false); 
/*     */       return;
/*     */     } 
/* 429 */     positions.sort(Comparator.comparingDouble(pos2 -> mc.field_71439_g.func_174818_b(pos2)));
/* 430 */     this.finalPos = positions.get(0);
/* 431 */     this.finalFacing = facings.get(this.finalPos);
/* 432 */     float[] rotation = RotationUtil.simpleFacing(this.finalFacing);
/* 433 */     if (!this.sendRotationPacket && ((Boolean)this.extraPacket.getValue()).booleanValue()) {
/* 434 */       RotationUtil.faceYawAndPitch(rotation[0], rotation[1]);
/* 435 */       this.sendRotationPacket = true;
/*     */     } 
/* 437 */     this.yaw.set(rotation[0]);
/* 438 */     this.pitch.set(rotation[1]);
/* 439 */     this.shouldRotate.set(true);
/* 440 */     Phobos.rotationManager.setPlayerRotations(rotation[0], rotation[1]);
/*     */   }
/*     */   
/*     */   public String getDisplayInfo() {
/* 444 */     if (this.target != null)
/* 445 */       return this.target.func_70005_c_(); 
/* 446 */     return null;
/*     */   }
/*     */   
/*     */   public void doBedCraft() {
/* 450 */     int woolSlot = InventoryUtil.findInventoryWool(false);
/* 451 */     int woodSlot = InventoryUtil.findInventoryBlock(BlockPlanks.class, true);
/* 452 */     if (woolSlot == -1 || woodSlot == -1) {
/* 453 */       if (mc.field_71462_r instanceof net.minecraft.client.gui.inventory.GuiCrafting) {
/* 454 */         mc.func_147108_a(null);
/* 455 */         mc.field_71462_r = null;
/*     */       } 
/*     */       return;
/*     */     } 
/*     */     List<?> targets;
/* 460 */     if (((Boolean)this.placeCraftingTable.getValue()).booleanValue() && BlockUtil.getBlockSphere(((Float)this.tableRange.getValue()).floatValue() - 1.0F, BlockWorkbench.class).size() == 0 && !(targets = (List)BlockUtil.getSphere(EntityUtil.getPlayerPos((EntityPlayer)mc.field_71439_g), ((Float)this.tableRange.getValue()).floatValue(), ((Float)this.tableRange.getValue()).intValue(), false, true, 0).stream().filter(pos -> (BlockUtil.isPositionPlaceable(pos, false) == 3)).sorted(Comparator.comparingInt(pos -> -safety(pos))).collect(Collectors.toList())).isEmpty()) {
/* 461 */       BlockPos target = (BlockPos)targets.get(0);
/* 462 */       int tableSlot = InventoryUtil.findHotbarBlock(BlockWorkbench.class);
/* 463 */       if (tableSlot != -1) {
/* 464 */         mc.field_71439_g.field_71071_by.field_70461_c = tableSlot;
/* 465 */         BlockUtil.placeBlock(target, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), true, false);
/*     */       } else {
/* 467 */         if (((Boolean)this.craftTable.getValue()).booleanValue())
/* 468 */           craftTable(); 
/* 469 */         if ((tableSlot = InventoryUtil.findHotbarBlock(BlockWorkbench.class)) != -1) {
/* 470 */           mc.field_71439_g.field_71071_by.field_70461_c = tableSlot;
/* 471 */           BlockUtil.placeBlock(target, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), true, false);
/*     */         } 
/*     */       } 
/*     */     } 
/* 475 */     if (((Boolean)this.openCraftingTable.getValue()).booleanValue()) {
/* 476 */       List<BlockPos> tables = BlockUtil.getBlockSphere(((Float)this.tableRange.getValue()).floatValue(), BlockWorkbench.class);
/* 477 */       tables.sort(Comparator.comparingDouble(pos -> mc.field_71439_g.func_174818_b(pos)));
/* 478 */       if (!tables.isEmpty() && !(mc.field_71462_r instanceof net.minecraft.client.gui.inventory.GuiCrafting)) {
/* 479 */         BlockPos target = tables.get(0);
/* 480 */         mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketEntityAction((Entity)mc.field_71439_g, CPacketEntityAction.Action.STOP_SNEAKING));
/* 481 */         if (mc.field_71439_g.func_174818_b(target) > MathUtil.square(((Float)this.breakRange.getValue()).floatValue()))
/*     */           return; 
/* 483 */         Vec3d hitVec = new Vec3d((Vec3i)target);
/* 484 */         float[] rotations = RotationUtil.getLegitRotations(hitVec);
/* 485 */         this.yaw.set(rotations[0]);
/* 486 */         if (((Boolean)this.rotate.getValue()).booleanValue()) {
/* 487 */           this.shouldRotate.set(true);
/* 488 */           this.pitch.set(rotations[1]);
/*     */         } 
/*     */         RayTraceResult result;
/* 491 */         EnumFacing facing = ((result = mc.field_71441_e.func_72933_a(new Vec3d(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + mc.field_71439_g.func_70047_e(), mc.field_71439_g.field_70161_v), new Vec3d(target.func_177958_n() + 0.5D, target.func_177956_o() - 0.5D, target.func_177952_p() + 0.5D))) == null || result.field_178784_b == null) ? EnumFacing.UP : result.field_178784_b;
/* 492 */         BlockUtil.rightClickBlock(target, hitVec, EnumHand.MAIN_HAND, facing, true);
/* 493 */         this.breakTimer.reset();
/* 494 */         if (mc.field_71439_g.func_70093_af())
/* 495 */           mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketEntityAction((Entity)mc.field_71439_g, CPacketEntityAction.Action.START_SNEAKING)); 
/*     */       } 
/* 497 */       this.shouldCraft = mc.field_71462_r instanceof net.minecraft.client.gui.inventory.GuiCrafting;
/* 498 */       this.craftStage = 0;
/* 499 */       this.craftTimer.reset();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void craftTable() {
/* 504 */     int woodSlot = InventoryUtil.findInventoryBlock(BlockPlanks.class, true);
/* 505 */     if (woodSlot != -1) {
/* 506 */       mc.field_71442_b.func_187098_a(0, woodSlot, 0, ClickType.PICKUP, (EntityPlayer)mc.field_71439_g);
/* 507 */       mc.field_71442_b.func_187098_a(0, 1, 1, ClickType.PICKUP, (EntityPlayer)mc.field_71439_g);
/* 508 */       mc.field_71442_b.func_187098_a(0, 2, 1, ClickType.PICKUP, (EntityPlayer)mc.field_71439_g);
/* 509 */       mc.field_71442_b.func_187098_a(0, 3, 1, ClickType.PICKUP, (EntityPlayer)mc.field_71439_g);
/* 510 */       mc.field_71442_b.func_187098_a(0, 4, 1, ClickType.PICKUP, (EntityPlayer)mc.field_71439_g);
/* 511 */       mc.field_71442_b.func_187098_a(0, 0, 0, ClickType.QUICK_MOVE, (EntityPlayer)mc.field_71439_g);
/* 512 */       int table = InventoryUtil.findInventoryBlock(BlockWorkbench.class, true);
/* 513 */       if (table != -1) {
/* 514 */         mc.field_71442_b.func_187098_a(0, table, 0, ClickType.PICKUP, (EntityPlayer)mc.field_71439_g);
/* 515 */         mc.field_71442_b.func_187098_a(0, ((Integer)this.tableSlot.getValue()).intValue(), 0, ClickType.PICKUP, (EntityPlayer)mc.field_71439_g);
/* 516 */         mc.field_71442_b.func_187098_a(0, table, 0, ClickType.PICKUP, (EntityPlayer)mc.field_71439_g);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void onToggle() {
/* 522 */     this.lastHotbarSlot = -1;
/* 523 */     this.bedSlot = -1;
/* 524 */     this.sendRotationPacket = false;
/* 525 */     this.target = null;
/* 526 */     this.yaw.set(-1.0D);
/* 527 */     this.pitch.set(-1.0D);
/* 528 */     this.shouldRotate.set(false);
/* 529 */     this.shouldCraft = false;
/*     */   }
/*     */   
/*     */   private int findBedSlot() {
/* 533 */     for (int i = 0; i < 9; ) {
/* 534 */       ItemStack stack = mc.field_71439_g.field_71071_by.func_70301_a(i);
/* 535 */       if (stack == ItemStack.field_190927_a || stack.func_77973_b() != Items.field_151104_aV) {
/* 536 */         i++;
/*     */         continue;
/*     */       } 
/* 539 */       return i;
/*     */     } 
/* 541 */     return -1;
/*     */   }
/*     */   
/*     */   private int safety(BlockPos pos) {
/* 545 */     int safety = 0;
/* 546 */     for (EnumFacing facing : EnumFacing.values()) {
/* 547 */       if (!mc.field_71441_e.func_180495_p(pos.func_177972_a(facing)).func_185904_a().func_76222_j())
/* 548 */         safety++; 
/*     */     } 
/* 550 */     return safety;
/*     */   }
/*     */   
/*     */   public enum BreakLogic {
/* 554 */     ALL, CALC;
/*     */   }
/*     */   
/*     */   public enum Logic {
/* 558 */     BREAKPLACE, PLACEBREAK;
/*     */   }
/*     */ 
/*     */   
/*     */   public static class BedData
/*     */   {
/*     */     private final BlockPos pos;
/*     */     
/*     */     private final IBlockState state;
/*     */     private final boolean isHeadPiece;
/*     */     private final TileEntityBed entity;
/*     */     
/*     */     public BedData(BlockPos pos, IBlockState state, TileEntityBed bed, boolean isHeadPiece) {
/* 571 */       this.pos = pos;
/* 572 */       this.state = state;
/* 573 */       this.entity = bed;
/* 574 */       this.isHeadPiece = isHeadPiece;
/*     */     }
/*     */     
/*     */     public BlockPos getPos() {
/* 578 */       return this.pos;
/*     */     }
/*     */     
/*     */     public IBlockState getState() {
/* 582 */       return this.state;
/*     */     }
/*     */     
/*     */     public boolean isHeadPiece() {
/* 586 */       return this.isHeadPiece;
/*     */     }
/*     */     
/*     */     public TileEntityBed getEntity() {
/* 590 */       return this.entity;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\ShitClient\HayBale-1.0.1-b8.jar!\me\luxtix\haybale\features\modules\combat\BedAura.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */