/*     */ package me.luxtix.haybale.features.modules.combat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import me.luxtix.haybale.Phobos;
/*     */ import me.luxtix.haybale.event.events.UpdateWalkingPlayerEvent;
/*     */ import me.luxtix.haybale.features.modules.Module;
/*     */ import me.luxtix.haybale.features.modules.client.ClickGui;
/*     */ import me.luxtix.haybale.features.modules.client.ServerModule;
/*     */ import me.luxtix.haybale.features.modules.player.BlockTweaks;
/*     */ import me.luxtix.haybale.features.modules.player.Freecam;
/*     */ import me.luxtix.haybale.features.setting.Bind;
/*     */ import me.luxtix.haybale.features.setting.Setting;
/*     */ import me.luxtix.haybale.util.BlockUtil;
/*     */ import me.luxtix.haybale.util.EntityUtil;
/*     */ import me.luxtix.haybale.util.InventoryUtil;
/*     */ import me.luxtix.haybale.util.MathUtil;
/*     */ import me.luxtix.haybale.util.Timer;
/*     */ import net.minecraft.block.BlockObsidian;
/*     */ import net.minecraft.block.BlockWeb;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketChatMessage;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraftforge.fml.common.eventhandler.EventPriority;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ import net.minecraftforge.fml.common.gameevent.InputEvent;
/*     */ import org.lwjgl.input.Keyboard;
/*     */ 
/*     */ public class HoleFiller extends Module {
/*  33 */   private static HoleFiller INSTANCE = new HoleFiller();
/*  34 */   private final Setting<Boolean> server = register(new Setting("Server", Boolean.valueOf(false)));
/*  35 */   private final Setting<Double> range = register(new Setting("PlaceRange", Double.valueOf(6.0D), Double.valueOf(0.0D), Double.valueOf(10.0D)));
/*  36 */   private final Setting<Integer> delay = register(new Setting("Delay/Place", Integer.valueOf(50), Integer.valueOf(0), Integer.valueOf(250)));
/*  37 */   private final Setting<Integer> blocksPerTick = register(new Setting("Block/Place", Integer.valueOf(8), Integer.valueOf(1), Integer.valueOf(20)));
/*  38 */   private final Setting<Boolean> rotate = register(new Setting("Rotate", Boolean.valueOf(true)));
/*  39 */   private final Setting<Boolean> raytrace = register(new Setting("Raytrace", Boolean.valueOf(false)));
/*  40 */   private final Setting<Boolean> disable = register(new Setting("Disable", Boolean.valueOf(true)));
/*  41 */   private final Setting<Integer> disableTime = register(new Setting("Ms/Disable", Integer.valueOf(200), Integer.valueOf(1), Integer.valueOf(250)));
/*  42 */   private final Setting<Boolean> offhand = register(new Setting("OffHand", Boolean.valueOf(true)));
/*  43 */   private final Setting<InventoryUtil.Switch> switchMode = register(new Setting("Switch", InventoryUtil.Switch.NORMAL));
/*  44 */   private final Setting<Boolean> onlySafe = register(new Setting("OnlySafe", Boolean.valueOf(true), v -> ((Boolean)this.offhand.getValue()).booleanValue()));
/*  45 */   private final Setting<Boolean> webSelf = register(new Setting("SelfWeb", Boolean.valueOf(false)));
/*  46 */   private final Setting<Boolean> highWeb = register(new Setting("HighWeb", Boolean.valueOf(false)));
/*  47 */   private final Setting<Boolean> freecam = register(new Setting("Freecam", Boolean.valueOf(false)));
/*  48 */   private final Setting<Boolean> midSafeHoles = register(new Setting("MidSafe", Boolean.valueOf(false)));
/*  49 */   private final Setting<Boolean> packet = register(new Setting("Packet", Boolean.valueOf(false)));
/*  50 */   private final Setting<Boolean> onGroundCheck = register(new Setting("OnGroundCheck", Boolean.valueOf(false)));
/*  51 */   private final Timer offTimer = new Timer();
/*  52 */   private final Timer timer = new Timer();
/*  53 */   private final Map<BlockPos, Integer> retries = new HashMap<>();
/*  54 */   private final Timer retryTimer = new Timer();
/*  55 */   public Setting<Mode> mode = register(new Setting("Mode", Mode.OBSIDIAN));
/*  56 */   public Setting<PlaceMode> placeMode = register(new Setting("PlaceMode", PlaceMode.ALL));
/*  57 */   private final Setting<Double> smartRange = register(new Setting("SmartRange", Double.valueOf(6.0D), Double.valueOf(0.0D), Double.valueOf(10.0D), v -> (this.placeMode.getValue() == PlaceMode.SMART)));
/*  58 */   public Setting<Bind> obbyBind = register(new Setting("Obsidian", new Bind(-1)));
/*  59 */   public Setting<Bind> webBind = register(new Setting("Webs", new Bind(-1)));
/*  60 */   public Mode currentMode = Mode.OBSIDIAN;
/*     */   private boolean accessedViaBind = false;
/*  62 */   private int targetSlot = -1;
/*  63 */   private int blocksThisTick = 0;
/*  64 */   private Offhand.Mode offhandMode = Offhand.Mode.CRYSTALS;
/*  65 */   private Offhand.Mode2 offhandMode2 = Offhand.Mode2.CRYSTALS;
/*     */   private boolean isSneaking;
/*     */   private boolean hasOffhand = false;
/*     */   private boolean placeHighWeb = false;
/*  69 */   private int lastHotbarSlot = -1;
/*     */   private boolean switchedItem = false;
/*     */   
/*     */   public HoleFiller() {
/*  73 */     super("HoleFiller", "Fills holes around you.", Module.Category.COMBAT, true, false, true);
/*  74 */     setInstance();
/*     */   }
/*     */   
/*     */   public static HoleFiller getInstance() {
/*  78 */     if (INSTANCE == null) {
/*  79 */       INSTANCE = new HoleFiller();
/*     */     }
/*  81 */     return INSTANCE;
/*     */   }
/*     */   
/*     */   private void setInstance() {
/*  85 */     INSTANCE = this;
/*     */   }
/*     */   
/*     */   private boolean shouldServer() {
/*  89 */     return (ServerModule.getInstance().isConnected() && ((Boolean)this.server.getValue()).booleanValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  94 */     if (fullNullCheck()) {
/*  95 */       disable();
/*     */     }
/*  97 */     if (!mc.field_71439_g.field_70122_E && ((Boolean)this.onGroundCheck.getValue()).booleanValue()) {
/*     */       return;
/*     */     }
/* 100 */     if (shouldServer()) {
/* 101 */       mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketChatMessage("@Serverprefix" + (String)(ClickGui.getInstance()).prefix.getValue()));
/* 102 */       mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketChatMessage("@Server" + (String)(ClickGui.getInstance()).prefix.getValue() + "module HoleFiller set Enabled true"));
/*     */       return;
/*     */     } 
/* 105 */     this.lastHotbarSlot = mc.field_71439_g.field_71071_by.field_70461_c;
/* 106 */     if (!this.accessedViaBind) {
/* 107 */       this.currentMode = (Mode)this.mode.getValue();
/*     */     }
/* 109 */     Offhand module = (Offhand)Phobos.moduleManager.getModuleByClass(Offhand.class);
/* 110 */     this.offhandMode = module.mode;
/* 111 */     this.offhandMode2 = module.currentMode;
/* 112 */     if (((Boolean)this.offhand.getValue()).booleanValue() && (EntityUtil.isSafe((Entity)mc.field_71439_g) || !((Boolean)this.onlySafe.getValue()).booleanValue())) {
/* 113 */       if (module.type.getValue() == Offhand.Type.NEW) {
/* 114 */         if (this.currentMode == Mode.WEBS) {
/* 115 */           module.setSwapToTotem(false);
/* 116 */           module.setMode(Offhand.Mode.WEBS);
/*     */         } else {
/* 118 */           module.setSwapToTotem(false);
/* 119 */           module.setMode(Offhand.Mode.OBSIDIAN);
/*     */         } 
/*     */       } else {
/* 122 */         if (this.currentMode == Mode.WEBS) {
/* 123 */           module.setMode(Offhand.Mode2.WEBS);
/*     */         } else {
/* 125 */           module.setMode(Offhand.Mode2.OBSIDIAN);
/*     */         } 
/* 127 */         if (!module.didSwitchThisTick) {
/* 128 */           module.doOffhand();
/*     */         }
/*     */       } 
/*     */     }
/* 132 */     Phobos.holeManager.update();
/* 133 */     this.offTimer.reset();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onTick() {
/* 138 */     if (isOn() && (((Integer)this.blocksPerTick.getValue()).intValue() != 1 || !((Boolean)this.rotate.getValue()).booleanValue())) {
/* 139 */       doHoleFill();
/*     */     }
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onUpdateWalkingPlayer(UpdateWalkingPlayerEvent event) {
/* 145 */     if (isOn() && event.getStage() == 0 && ((Integer)this.blocksPerTick.getValue()).intValue() == 1 && ((Boolean)this.rotate.getValue()).booleanValue()) {
/* 146 */       doHoleFill();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/* 152 */     if (((Boolean)this.offhand.getValue()).booleanValue()) {
/* 153 */       ((Offhand)Phobos.moduleManager.getModuleByClass(Offhand.class)).setMode(this.offhandMode);
/* 154 */       ((Offhand)Phobos.moduleManager.getModuleByClass(Offhand.class)).setMode(this.offhandMode2);
/*     */     } 
/* 156 */     switchItem(true);
/* 157 */     this.isSneaking = EntityUtil.stopSneaking(this.isSneaking);
/* 158 */     this.retries.clear();
/* 159 */     this.accessedViaBind = false;
/* 160 */     this.hasOffhand = false;
/*     */   }
/*     */   
/*     */   @SubscribeEvent(priority = EventPriority.NORMAL, receiveCanceled = true)
/*     */   public void onKeyInput(InputEvent.KeyInputEvent event) {
/* 165 */     if (Keyboard.getEventKeyState()) {
/* 166 */       if (((Bind)this.obbyBind.getValue()).getKey() == Keyboard.getEventKey()) {
/* 167 */         this.accessedViaBind = true;
/* 168 */         this.currentMode = Mode.OBSIDIAN;
/* 169 */         toggle();
/*     */       } 
/* 171 */       if (((Bind)this.webBind.getValue()).getKey() == Keyboard.getEventKey()) {
/* 172 */         this.accessedViaBind = true;
/* 173 */         this.currentMode = Mode.WEBS;
/* 174 */         toggle();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void doHoleFill() {
/*     */     ArrayList<BlockPos> targets;
/* 185 */     if (check()) {
/*     */       return;
/*     */     }
/* 188 */     if (this.placeHighWeb) {
/* 189 */       BlockPos pos = new BlockPos(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + 1.0D, mc.field_71439_g.field_70161_v);
/* 190 */       placeBlock(pos);
/* 191 */       this.placeHighWeb = false;
/*     */     } 
/* 193 */     if (((Boolean)this.midSafeHoles.getValue()).booleanValue()) {
/* 194 */       Object object1 = Phobos.holeManager.getMidSafety();
/* 195 */       synchronized (object1) {
/* 196 */         targets = new ArrayList<>(Phobos.holeManager.getMidSafety());
/*     */       } 
/*     */     } 
/* 199 */     Object object = Phobos.holeManager.getHoles();
/* 200 */     synchronized (object) {
/* 201 */       targets = new ArrayList<>(Phobos.holeManager.getHoles());
/*     */     } 
/* 203 */     for (BlockPos position : targets) {
/*     */       
/* 205 */       if (mc.field_71439_g.func_174818_b(position) > MathUtil.square(((Double)this.range.getValue()).doubleValue()) || (this.placeMode.getValue() == PlaceMode.SMART && !isPlayerInRange(position)))
/*     */         continue; 
/* 207 */       if (position.equals(new BlockPos(mc.field_71439_g.func_174791_d()))) {
/* 208 */         if (this.currentMode != Mode.WEBS || !((Boolean)this.webSelf.getValue()).booleanValue())
/* 209 */           continue;  if (((Boolean)this.highWeb.getValue()).booleanValue())
/* 210 */           this.placeHighWeb = true; 
/*     */       } 
/*     */       int placeability;
/* 213 */       if ((placeability = BlockUtil.isPositionPlaceable(position, ((Boolean)this.raytrace.getValue()).booleanValue())) == 1 && (this.currentMode == Mode.WEBS || this.switchMode.getValue() == InventoryUtil.Switch.SILENT || (BlockTweaks.getINSTANCE().isOn() && ((Boolean)(BlockTweaks.getINSTANCE()).noBlock.getValue()).booleanValue())) && (this.currentMode == Mode.WEBS || this.retries.get(position) == null || ((Integer)this.retries.get(position)).intValue() < 4)) {
/* 214 */         placeBlock(position);
/* 215 */         if (this.currentMode == Mode.WEBS)
/* 216 */           continue;  this.retries.put(position, Integer.valueOf((this.retries.get(position) == null) ? 1 : (((Integer)this.retries.get(position)).intValue() + 1)));
/*     */         continue;
/*     */       } 
/* 219 */       if (placeability != 3)
/* 220 */         continue;  placeBlock(position);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void placeBlock(BlockPos pos) {
/* 225 */     if (this.blocksThisTick < ((Integer)this.blocksPerTick.getValue()).intValue() && switchItem(false)) {
/*     */       
/* 227 */       boolean smartRotate = (((Integer)this.blocksPerTick.getValue()).intValue() == 1 && ((Boolean)this.rotate.getValue()).booleanValue()), bl = smartRotate;
/* 228 */       this.isSneaking = smartRotate ? BlockUtil.placeBlockSmartRotate(pos, this.hasOffhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, true, ((Boolean)this.packet.getValue()).booleanValue(), this.isSneaking) : BlockUtil.placeBlock(pos, this.hasOffhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), this.isSneaking);
/* 229 */       this.timer.reset();
/* 230 */       this.blocksThisTick++;
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isPlayerInRange(BlockPos pos) {
/* 235 */     for (EntityPlayer player : mc.field_71441_e.field_73010_i) {
/* 236 */       if (EntityUtil.isntValid((Entity)player, ((Double)this.smartRange.getValue()).doubleValue()))
/* 237 */         continue;  return true;
/*     */     } 
/* 239 */     return false;
/*     */   }
/*     */   
/*     */   private boolean check() {
/* 243 */     if (fullNullCheck() || (((Boolean)this.disable.getValue()).booleanValue() && this.offTimer.passedMs(((Integer)this.disableTime.getValue()).intValue()))) {
/* 244 */       disable();
/* 245 */       return true;
/*     */     } 
/* 247 */     if (mc.field_71439_g.field_71071_by.field_70461_c != this.lastHotbarSlot && mc.field_71439_g.field_71071_by.field_70461_c != InventoryUtil.findHotbarBlock((this.currentMode == Mode.WEBS) ? BlockWeb.class : BlockObsidian.class)) {
/* 248 */       this.lastHotbarSlot = mc.field_71439_g.field_71071_by.field_70461_c;
/*     */     }
/* 250 */     switchItem(true);
/* 251 */     if (!((Boolean)this.freecam.getValue()).booleanValue() && Phobos.moduleManager.isModuleEnabled(Freecam.class)) {
/* 252 */       return true;
/*     */     }
/* 254 */     this.blocksThisTick = 0;
/* 255 */     this.isSneaking = EntityUtil.stopSneaking(this.isSneaking);
/* 256 */     if (this.retryTimer.passedMs(2000L)) {
/* 257 */       this.retries.clear();
/* 258 */       this.retryTimer.reset();
/*     */     } 
/* 260 */     switch (this.currentMode) {
/*     */       case WEBS:
/* 262 */         this.hasOffhand = InventoryUtil.isBlock(mc.field_71439_g.func_184592_cb().func_77973_b(), BlockWeb.class);
/* 263 */         this.targetSlot = InventoryUtil.findHotbarBlock(BlockWeb.class);
/*     */         break;
/*     */       
/*     */       case OBSIDIAN:
/* 267 */         this.hasOffhand = InventoryUtil.isBlock(mc.field_71439_g.func_184592_cb().func_77973_b(), BlockObsidian.class);
/* 268 */         this.targetSlot = InventoryUtil.findHotbarBlock(BlockObsidian.class);
/*     */         break;
/*     */     } 
/*     */     
/* 272 */     if (((Boolean)this.onlySafe.getValue()).booleanValue() && !EntityUtil.isSafe((Entity)mc.field_71439_g)) {
/* 273 */       disable();
/* 274 */       return true;
/*     */     } 
/* 276 */     if (!this.hasOffhand && this.targetSlot == -1 && (!((Boolean)this.offhand.getValue()).booleanValue() || (!EntityUtil.isSafe((Entity)mc.field_71439_g) && ((Boolean)this.onlySafe.getValue()).booleanValue()))) {
/* 277 */       return true;
/*     */     }
/* 279 */     if (((Boolean)this.offhand.getValue()).booleanValue() && !this.hasOffhand) {
/* 280 */       return true;
/*     */     }
/* 282 */     return !this.timer.passedMs(((Integer)this.delay.getValue()).intValue());
/*     */   }
/*     */   
/*     */   private boolean switchItem(boolean back) {
/* 286 */     if (((Boolean)this.offhand.getValue()).booleanValue()) {
/* 287 */       return true;
/*     */     }
/* 289 */     boolean[] value = InventoryUtil.switchItem(back, this.lastHotbarSlot, this.switchedItem, (InventoryUtil.Switch)this.switchMode.getValue(), (this.currentMode == Mode.WEBS) ? BlockWeb.class : BlockObsidian.class);
/* 290 */     this.switchedItem = value[0];
/* 291 */     return value[1];
/*     */   }
/*     */   
/*     */   public enum PlaceMode {
/* 295 */     SMART,
/* 296 */     ALL;
/*     */   }
/*     */   
/*     */   public enum Mode
/*     */   {
/* 301 */     WEBS,
/* 302 */     OBSIDIAN;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\ShitClient\HayBale-1.0.1-b8.jar!\me\luxtix\haybale\features\modules\combat\HoleFiller.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */