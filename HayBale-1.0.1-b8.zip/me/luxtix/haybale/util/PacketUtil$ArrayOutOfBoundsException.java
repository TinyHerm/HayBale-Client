package me.luxtix.haybale.util;

public class PacketUtil$ArrayOutOfBoundsException extends RuntimeException {}


/* Location:              C:\Users\Administrator\Desktop\ShitClient\HayBale-1.0.1-b8.jar!\me\luxtix\haybal\\util\PacketUtil$ArrayOutOfBoundsException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */