/*      */ package me.luxtix.haybale.util;
/*      */ import com.mojang.realmsclient.gui.ChatFormatting;
/*      */ import java.awt.Color;
/*      */ import java.math.RoundingMode;
/*      */ import java.text.DecimalFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Objects;
/*      */ import me.luxtix.haybale.Phobos;
/*      */ import net.minecraft.block.Block;
/*      */ import net.minecraft.block.state.IBlockState;
/*      */ import net.minecraft.client.Minecraft;
/*      */ import net.minecraft.enchantment.EnchantmentHelper;
/*      */ import net.minecraft.entity.Entity;
/*      */ import net.minecraft.entity.EntityLivingBase;
/*      */ import net.minecraft.entity.EnumCreatureType;
/*      */ import net.minecraft.entity.SharedMonsterAttributes;
/*      */ import net.minecraft.entity.item.EntityEnderCrystal;
/*      */ import net.minecraft.entity.monster.EntityPigZombie;
/*      */ import net.minecraft.entity.passive.EntityWolf;
/*      */ import net.minecraft.entity.player.EntityPlayer;
/*      */ import net.minecraft.init.Blocks;
/*      */ import net.minecraft.item.ItemStack;
/*      */ import net.minecraft.network.Packet;
/*      */ import net.minecraft.network.play.client.CPacketEntityAction;
/*      */ import net.minecraft.network.play.client.CPacketUseEntity;
/*      */ import net.minecraft.potion.Potion;
/*      */ import net.minecraft.potion.PotionEffect;
/*      */ import net.minecraft.util.CombatRules;
/*      */ import net.minecraft.util.DamageSource;
/*      */ import net.minecraft.util.EnumFacing;
/*      */ import net.minecraft.util.EnumHand;
/*      */ import net.minecraft.util.MovementInput;
/*      */ import net.minecraft.util.math.AxisAlignedBB;
/*      */ import net.minecraft.util.math.BlockPos;
/*      */ import net.minecraft.util.math.MathHelper;
/*      */ import net.minecraft.util.math.Vec3d;
/*      */ import net.minecraft.world.Explosion;
/*      */ import net.minecraft.world.World;
/*      */ 
/*      */ public class EntityUtil2 implements Util {
/*   45 */   public static final Vec3d[] antiDropOffsetList = new Vec3d[] { new Vec3d(0.0D, -2.0D, 0.0D) };
/*   46 */   public static final Vec3d[] platformOffsetList = new Vec3d[] { new Vec3d(0.0D, -1.0D, 0.0D), new Vec3d(0.0D, -1.0D, -1.0D), new Vec3d(0.0D, -1.0D, 1.0D), new Vec3d(-1.0D, -1.0D, 0.0D), new Vec3d(1.0D, -1.0D, 0.0D) };
/*   47 */   public static final Vec3d[] legOffsetList = new Vec3d[] { new Vec3d(-1.0D, 0.0D, 0.0D), new Vec3d(1.0D, 0.0D, 0.0D), new Vec3d(0.0D, 0.0D, -1.0D), new Vec3d(0.0D, 0.0D, 1.0D) };
/*   48 */   public static final Vec3d[] OffsetList = new Vec3d[] { new Vec3d(1.0D, 1.0D, 0.0D), new Vec3d(-1.0D, 1.0D, 0.0D), new Vec3d(0.0D, 1.0D, 1.0D), new Vec3d(0.0D, 1.0D, -1.0D), new Vec3d(0.0D, 2.0D, 0.0D) };
/*   49 */   public static final Vec3d[] antiStepOffsetList = new Vec3d[] { new Vec3d(-1.0D, 2.0D, 0.0D), new Vec3d(1.0D, 2.0D, 0.0D), new Vec3d(0.0D, 2.0D, 1.0D), new Vec3d(0.0D, 2.0D, -1.0D) };
/*   50 */   public static final Vec3d[] antiScaffoldOffsetList = new Vec3d[] { new Vec3d(0.0D, 3.0D, 0.0D) };
/*   51 */   public static final Vec3d[] doubleLegOffsetList = new Vec3d[] { new Vec3d(-1.0D, 0.0D, 0.0D), new Vec3d(1.0D, 0.0D, 0.0D), new Vec3d(0.0D, 0.0D, -1.0D), new Vec3d(0.0D, 0.0D, 1.0D), new Vec3d(-2.0D, 0.0D, 0.0D), new Vec3d(2.0D, 0.0D, 0.0D), new Vec3d(0.0D, 0.0D, -2.0D), new Vec3d(0.0D, 0.0D, 2.0D) };
/*      */   
/*      */   public static void attackEntity(Entity entity, boolean packet, boolean swingArm) {
/*   54 */     if (packet) {
/*   55 */       EntityUtil.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketUseEntity(entity));
/*      */     } else {
/*   57 */       EntityUtil.mc.field_71442_b.func_78764_a((EntityPlayer)EntityUtil.mc.field_71439_g, entity);
/*      */     } 
/*   59 */     if (swingArm) {
/*   60 */       EntityUtil.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
/*      */     }
/*      */   }
/*      */   
/*      */   public static float calculate(double posX, double posY, double posZ, EntityLivingBase entity) {
/*   65 */     double distancedsize = entity.func_70011_f(posX, posY, posZ) / 12.0D;
/*   66 */     Vec3d vec3d = new Vec3d(posX, posY, posZ);
/*   67 */     double blockDensity = getBlockDensity(vec3d, entity.func_174813_aQ());
/*   68 */     double v = (1.0D - distancedsize) * blockDensity;
/*   69 */     float damage = (int)((v * v + v) / 2.0D * 7.0D * 12.0D + 1.0D);
/*   70 */     return getBlastReduction(entity, getDamageMultiplied(damage), new Explosion((World)mc.field_71441_e, null, posX, posY, posZ, 6.0F, false, true));
/*      */   }
/*      */   
/*      */   public static EntityPlayer getClosestPlayer(float range) {
/*   74 */     EntityPlayer player = null;
/*   75 */     double maxDistance = 999.0D;
/*   76 */     int size = mc.field_71441_e.field_73010_i.size();
/*   77 */     for (int i = 0; i < size; i++) {
/*   78 */       EntityPlayer entityPlayer = mc.field_71441_e.field_73010_i.get(i);
/*   79 */       if (isPlayerValid(entityPlayer, range)) {
/*   80 */         double distanceSq = mc.field_71439_g.func_70068_e((Entity)entityPlayer);
/*   81 */         if (maxDistance == 999.0D || distanceSq < maxDistance) {
/*   82 */           maxDistance = distanceSq;
/*   83 */           player = entityPlayer;
/*      */         } 
/*      */       } 
/*      */     } 
/*   87 */     return player;
/*      */   }
/*      */   
/*      */   public static boolean isPlayerValid(EntityPlayer player, float range) {
/*   91 */     return (player != mc.field_71439_g && mc.field_71439_g.func_70032_d((Entity)player) < range && !isDead((Entity)player) && !Phobos.friendManager.isFriend(player.func_70005_c_()));
/*      */   }
/*      */   
/*      */   private static float getBlastReduction(EntityLivingBase entity, float damageI, Explosion explosion) {
/*   95 */     float damage = damageI;
/*   96 */     if (entity instanceof EntityPlayer) {
/*   97 */       EntityPlayer ep = (EntityPlayer)entity;
/*   98 */       DamageSource ds = DamageSource.func_94539_a(explosion);
/*   99 */       damage = CombatRules.func_189427_a(damage, ep.func_70658_aO(), (float)ep.func_110148_a(SharedMonsterAttributes.field_189429_h).func_111126_e());
/*  100 */       int k = EnchantmentHelper.func_77508_a(ep.func_184193_aE(), ds);
/*  101 */       float f = MathHelper.func_76131_a(k, 0.0F, 20.0F);
/*  102 */       damage *= 1.0F - f / 25.0F;
/*  103 */       if (entity.func_70644_a(MobEffects.field_76429_m)) {
/*  104 */         damage -= damage / 4.0F;
/*      */       }
/*  106 */       return damage;
/*      */     } 
/*  108 */     damage = CombatRules.func_189427_a(damage, entity.func_70658_aO(), (float)entity.func_110148_a(SharedMonsterAttributes.field_189429_h).func_111126_e());
/*  109 */     return damage;
/*      */   }
/*      */   
/*      */   private static float getDamageMultiplied(float damage) {
/*  113 */     int diff = mc.field_71441_e.func_175659_aa().func_151525_a();
/*  114 */     return damage * ((diff == 0) ? 0.0F : ((diff == 2) ? 1.0F : ((diff == 1) ? 0.5F : 1.5F)));
/*      */   }
/*      */   
/*      */   public static float getBlockDensity(Vec3d vec, AxisAlignedBB bb) {
/*  118 */     double d0 = 1.0D / ((bb.field_72336_d - bb.field_72340_a) * 2.0D + 1.0D);
/*  119 */     double d1 = 1.0D / ((bb.field_72337_e - bb.field_72338_b) * 2.0D + 1.0D);
/*  120 */     double d2 = 1.0D / ((bb.field_72334_f - bb.field_72339_c) * 2.0D + 1.0D);
/*  121 */     double d3 = (1.0D - Math.floor(1.0D / d0) * d0) / 2.0D;
/*  122 */     double d4 = (1.0D - Math.floor(1.0D / d2) * d2) / 2.0D;
/*      */     
/*  124 */     if (d0 >= 0.0D && d1 >= 0.0D && d2 >= 0.0D) {
/*  125 */       int j2 = 0;
/*  126 */       int k2 = 0;
/*      */       float f;
/*  128 */       for (f = 0.0F; f <= 1.0F; f = (float)(f + d0)) {
/*  129 */         float f1; for (f1 = 0.0F; f1 <= 1.0F; f1 = (float)(f1 + d1)) {
/*  130 */           float f2; for (f2 = 0.0F; f2 <= 1.0F; f2 = (float)(f2 + d2)) {
/*  131 */             double d5 = bb.field_72340_a + (bb.field_72336_d - bb.field_72340_a) * f;
/*  132 */             double d6 = bb.field_72338_b + (bb.field_72337_e - bb.field_72338_b) * f1;
/*  133 */             double d7 = bb.field_72339_c + (bb.field_72334_f - bb.field_72339_c) * f2;
/*      */             
/*  135 */             if (rayTraceBlocks(new Vec3d(d5 + d3, d6, d7 + d4), vec) == null) {
/*  136 */               j2++;
/*      */             }
/*      */             
/*  139 */             k2++;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/*  144 */       return j2 / k2;
/*      */     } 
/*  146 */     return 0.0F;
/*      */   }
/*      */ 
/*      */   
/*      */   public static RayTraceResult rayTraceBlocks(Vec3d vec31, Vec3d vec32) {
/*  151 */     int i = MathHelper.func_76128_c(vec32.field_72450_a);
/*  152 */     int j = MathHelper.func_76128_c(vec32.field_72448_b);
/*  153 */     int k = MathHelper.func_76128_c(vec32.field_72449_c);
/*  154 */     int l = MathHelper.func_76128_c(vec31.field_72450_a);
/*  155 */     int i1 = MathHelper.func_76128_c(vec31.field_72448_b);
/*  156 */     int j1 = MathHelper.func_76128_c(vec31.field_72449_c);
/*  157 */     BlockPos blockpos = new BlockPos(l, i1, j1);
/*  158 */     IBlockState iblockstate = mc.field_71441_e.func_180495_p(blockpos);
/*  159 */     Block block = iblockstate.func_177230_c();
/*      */     
/*  161 */     if (block.func_176209_a(iblockstate, false) && block != Blocks.field_150321_G) {
/*  162 */       return iblockstate.func_185910_a((World)mc.field_71441_e, blockpos, vec31, vec32);
/*      */     }
/*      */     
/*  165 */     int k1 = 200;
/*  166 */     double d6 = vec32.field_72450_a - vec31.field_72450_a;
/*  167 */     double d7 = vec32.field_72448_b - vec31.field_72448_b;
/*  168 */     double d8 = vec32.field_72449_c - vec31.field_72449_c;
/*  169 */     while (k1-- >= 0) {
/*  170 */       EnumFacing enumfacing; if (l == i && i1 == j && j1 == k) {
/*  171 */         return null;
/*      */       }
/*      */       
/*  174 */       boolean flag2 = true;
/*  175 */       boolean flag = true;
/*  176 */       boolean flag1 = true;
/*  177 */       double d0 = 999.0D;
/*  178 */       double d1 = 999.0D;
/*  179 */       double d2 = 999.0D;
/*      */       
/*  181 */       if (i > l) {
/*  182 */         d0 = l + 1.0D;
/*  183 */       } else if (i < l) {
/*  184 */         d0 = l + 0.0D;
/*      */       } else {
/*  186 */         flag2 = false;
/*      */       } 
/*      */       
/*  189 */       if (j > i1) {
/*  190 */         d1 = i1 + 1.0D;
/*  191 */       } else if (j < i1) {
/*  192 */         d1 = i1 + 0.0D;
/*      */       } else {
/*  194 */         flag = false;
/*      */       } 
/*      */       
/*  197 */       if (k > j1) {
/*  198 */         d2 = j1 + 1.0D;
/*  199 */       } else if (k < j1) {
/*  200 */         d2 = j1 + 0.0D;
/*      */       } else {
/*  202 */         flag1 = false;
/*      */       } 
/*      */       
/*  205 */       double d3 = 999.0D;
/*  206 */       double d4 = 999.0D;
/*  207 */       double d5 = 999.0D;
/*      */       
/*  209 */       if (flag2) {
/*  210 */         d3 = (d0 - vec31.field_72450_a) / d6;
/*      */       }
/*      */       
/*  213 */       if (flag) {
/*  214 */         d4 = (d1 - vec31.field_72448_b) / d7;
/*      */       }
/*      */       
/*  217 */       if (flag1) {
/*  218 */         d5 = (d2 - vec31.field_72449_c) / d8;
/*      */       }
/*      */       
/*  221 */       if (d3 == -0.0D) {
/*  222 */         d3 = -1.0E-4D;
/*      */       }
/*      */       
/*  225 */       if (d4 == -0.0D) {
/*  226 */         d4 = -1.0E-4D;
/*      */       }
/*      */       
/*  229 */       if (d5 == -0.0D) {
/*  230 */         d5 = -1.0E-4D;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  235 */       if (d3 < d4 && d3 < d5) {
/*  236 */         enumfacing = (i > l) ? EnumFacing.WEST : EnumFacing.EAST;
/*  237 */         vec31 = new Vec3d(d0, vec31.field_72448_b + d7 * d3, vec31.field_72449_c + d8 * d3);
/*  238 */       } else if (d4 < d5) {
/*  239 */         enumfacing = (j > i1) ? EnumFacing.DOWN : EnumFacing.UP;
/*  240 */         vec31 = new Vec3d(vec31.field_72450_a + d6 * d4, d1, vec31.field_72449_c + d8 * d4);
/*      */       } else {
/*  242 */         enumfacing = (k > j1) ? EnumFacing.NORTH : EnumFacing.SOUTH;
/*  243 */         vec31 = new Vec3d(vec31.field_72450_a + d6 * d5, vec31.field_72448_b + d7 * d5, d2);
/*      */       } 
/*      */       
/*  246 */       l = MathHelper.func_76128_c(vec31.field_72450_a) - ((enumfacing == EnumFacing.EAST) ? 1 : 0);
/*  247 */       i1 = MathHelper.func_76128_c(vec31.field_72448_b) - ((enumfacing == EnumFacing.UP) ? 1 : 0);
/*  248 */       j1 = MathHelper.func_76128_c(vec31.field_72449_c) - ((enumfacing == EnumFacing.SOUTH) ? 1 : 0);
/*  249 */       blockpos = new BlockPos(l, i1, j1);
/*  250 */       iblockstate = mc.field_71441_e.func_180495_p(blockpos);
/*  251 */       block = iblockstate.func_177230_c();
/*      */       
/*  253 */       if (block.func_176209_a(iblockstate, false) && block != Blocks.field_150321_G) {
/*  254 */         return iblockstate.func_185910_a((World)mc.field_71441_e, blockpos, vec31, vec32);
/*      */       }
/*      */     } 
/*  257 */     return null;
/*      */   }
/*      */   
/*      */   public static boolean checkForLiquid(Entity entity, boolean b) {
/*  261 */     if (entity == null) {
/*  262 */       return false;
/*      */     }
/*  264 */     double posY = entity.field_70163_u;
/*  265 */     double n = b ? 0.03D : ((entity instanceof EntityPlayer) ? 0.2D : 0.5D);
/*  266 */     double n2 = posY - n;
/*  267 */     for (int i = MathHelper.func_76128_c(entity.field_70165_t); i < MathHelper.func_76143_f(entity.field_70165_t); i++) {
/*  268 */       for (int j = MathHelper.func_76128_c(entity.field_70161_v); j < MathHelper.func_76143_f(entity.field_70161_v); ) {
/*  269 */         if (!(EntityUtil.mc.field_71441_e.func_180495_p(new BlockPos(i, MathHelper.func_76128_c(n2), j)).func_177230_c() instanceof net.minecraft.block.BlockLiquid)) { j++; continue; }
/*  270 */          return true;
/*      */       } 
/*      */     } 
/*  273 */     return false;
/*      */   }
/*      */   
/*      */   public static boolean isAboveLiquid(Entity entity) {
/*  277 */     if (entity == null) {
/*  278 */       return false;
/*      */     }
/*  280 */     double n = entity.field_70163_u + 0.01D;
/*  281 */     for (int i = MathHelper.func_76128_c(entity.field_70165_t); i < MathHelper.func_76143_f(entity.field_70165_t); i++) {
/*  282 */       for (int j = MathHelper.func_76128_c(entity.field_70161_v); j < MathHelper.func_76143_f(entity.field_70161_v); ) {
/*  283 */         if (!(EntityUtil.mc.field_71441_e.func_180495_p(new BlockPos(i, (int)n, j)).func_177230_c() instanceof net.minecraft.block.BlockLiquid)) { j++; continue; }
/*  284 */          return true;
/*      */       } 
/*      */     } 
/*  287 */     return false;
/*      */   }
/*      */   
/*      */   public static boolean isOnLiquid(double offset) {
/*  291 */     if (EntityUtil.mc.field_71439_g.field_70143_R >= 3.0F) {
/*  292 */       return false;
/*      */     }
/*  294 */     AxisAlignedBB bb = (EntityUtil.mc.field_71439_g.func_184187_bx() != null) ? EntityUtil.mc.field_71439_g.func_184187_bx().func_174813_aQ().func_191195_a(0.0D, 0.0D, 0.0D).func_72317_d(0.0D, -offset, 0.0D) : EntityUtil.mc.field_71439_g.func_174813_aQ().func_191195_a(0.0D, 0.0D, 0.0D).func_72317_d(0.0D, -offset, 0.0D);
/*  295 */     boolean onLiquid = false;
/*  296 */     int y = (int)bb.field_72338_b;
/*  297 */     for (int x = MathHelper.func_76128_c(bb.field_72340_a); x < MathHelper.func_76128_c(bb.field_72336_d + 1.0D); x++) {
/*  298 */       for (int z = MathHelper.func_76128_c(bb.field_72339_c); z < MathHelper.func_76128_c(bb.field_72334_f + 1.0D); z++) {
/*  299 */         Block block = EntityUtil.mc.field_71441_e.func_180495_p(new BlockPos(x, y, z)).func_177230_c();
/*  300 */         if (block != Blocks.field_150350_a) {
/*  301 */           if (!(block instanceof net.minecraft.block.BlockLiquid)) {
/*  302 */             return false;
/*      */           }
/*  304 */           onLiquid = true;
/*      */         } 
/*      */       } 
/*  307 */     }  return onLiquid;
/*      */   }
/*      */   
/*      */   public static boolean isOnLiquid() {
/*  311 */     double y = EntityUtil.mc.field_71439_g.field_70163_u - 0.03D;
/*  312 */     for (int x = MathHelper.func_76128_c(EntityUtil.mc.field_71439_g.field_70165_t); x < MathHelper.func_76143_f(EntityUtil.mc.field_71439_g.field_70165_t); x++) {
/*  313 */       for (int z = MathHelper.func_76128_c(EntityUtil.mc.field_71439_g.field_70161_v); z < MathHelper.func_76143_f(EntityUtil.mc.field_71439_g.field_70161_v); ) {
/*  314 */         BlockPos pos = new BlockPos(x, MathHelper.func_76128_c(y), z);
/*  315 */         if (!(EntityUtil.mc.field_71441_e.func_180495_p(pos).func_177230_c() instanceof net.minecraft.block.BlockLiquid)) { z++; continue; }
/*  316 */          return true;
/*      */       } 
/*      */     } 
/*  319 */     return false;
/*      */   }
/*      */   
/*      */   public static boolean isInLiquid() {
/*  323 */     if (EntityUtil.mc.field_71439_g.field_70143_R >= 3.0F) {
/*  324 */       return false;
/*      */     }
/*  326 */     boolean inLiquid = false;
/*  327 */     AxisAlignedBB bb = (EntityUtil.mc.field_71439_g.func_184187_bx() != null) ? EntityUtil.mc.field_71439_g.func_184187_bx().func_174813_aQ() : EntityUtil.mc.field_71439_g.func_174813_aQ();
/*  328 */     int y = (int)bb.field_72338_b;
/*  329 */     for (int x = MathHelper.func_76128_c(bb.field_72340_a); x < MathHelper.func_76128_c(bb.field_72336_d) + 1; x++) {
/*  330 */       for (int z = MathHelper.func_76128_c(bb.field_72339_c); z < MathHelper.func_76128_c(bb.field_72334_f) + 1; z++) {
/*  331 */         Block block = EntityUtil.mc.field_71441_e.func_180495_p(new BlockPos(x, y, z)).func_177230_c();
/*  332 */         if (!(block instanceof net.minecraft.block.BlockAir)) {
/*  333 */           if (!(block instanceof net.minecraft.block.BlockLiquid)) {
/*  334 */             return false;
/*      */           }
/*  336 */           inLiquid = true;
/*      */         } 
/*      */       } 
/*  339 */     }  return inLiquid;
/*      */   }
/*      */   
/*      */   public static void resetTimer() {
/*  343 */     (Minecraft.func_71410_x()).field_71428_T.field_194149_e = 50.0F;
/*      */   }
/*      */   
/*      */   public static BlockPos getFlooredPos(Entity e) {
/*  347 */     return new BlockPos(Math.floor(e.field_70165_t), Math.floor(e.field_70163_u), Math.floor(e.field_70161_v));
/*      */   }
/*      */   
/*      */   public static Vec3d interpolateEntity(Entity entity, float time) {
/*  351 */     return new Vec3d(entity.field_70142_S + (entity.field_70165_t - entity.field_70142_S) * time, entity.field_70137_T + (entity.field_70163_u - entity.field_70137_T) * time, entity.field_70136_U + (entity.field_70161_v - entity.field_70136_U) * time);
/*      */   }
/*      */   
/*      */   public static Vec3d getInterpolatedPos(Entity entity, float partialTicks) {
/*  355 */     return (new Vec3d(entity.field_70142_S, entity.field_70137_T, entity.field_70136_U)).func_178787_e(EntityUtil.getInterpolatedAmount(entity, partialTicks));
/*      */   }
/*      */   
/*      */   public static Vec3d getInterpolatedRenderPos(Entity entity, float partialTicks) {
/*  359 */     return EntityUtil.getInterpolatedPos(entity, partialTicks).func_178786_a((EntityUtil.mc.func_175598_ae()).field_78725_b, (EntityUtil.mc.func_175598_ae()).field_78726_c, (EntityUtil.mc.func_175598_ae()).field_78723_d);
/*      */   }
/*      */   
/*      */   public static Vec3d getInterpolatedRenderPos(Vec3d vec) {
/*  363 */     return (new Vec3d(vec.field_72450_a, vec.field_72448_b, vec.field_72449_c)).func_178786_a((EntityUtil.mc.func_175598_ae()).field_78725_b, (EntityUtil.mc.func_175598_ae()).field_78726_c, (EntityUtil.mc.func_175598_ae()).field_78723_d);
/*      */   }
/*      */   
/*      */   public static Vec3d getInterpolatedAmount(Entity entity, double x, double y, double z) {
/*  367 */     return new Vec3d((entity.field_70165_t - entity.field_70142_S) * x, (entity.field_70163_u - entity.field_70137_T) * y, (entity.field_70161_v - entity.field_70136_U) * z);
/*      */   }
/*      */   
/*      */   public static Vec3d getInterpolatedAmount(Entity entity, Vec3d vec) {
/*  371 */     return EntityUtil.getInterpolatedAmount(entity, vec.field_72450_a, vec.field_72448_b, vec.field_72449_c);
/*      */   }
/*      */   
/*      */   public static Vec3d getInterpolatedAmount(Entity entity, float partialTicks) {
/*  375 */     return EntityUtil.getInterpolatedAmount(entity, partialTicks, partialTicks, partialTicks);
/*      */   }
/*      */   
/*      */   public static double getBaseMoveSpeed() {
/*  379 */     double baseSpeed = 0.2873D;
/*  380 */     if (mc.field_71439_g != null && mc.field_71439_g.func_70644_a(Potion.func_188412_a(1))) {
/*  381 */       int amplifier = mc.field_71439_g.func_70660_b(Potion.func_188412_a(1)).func_76458_c();
/*  382 */       baseSpeed *= 1.0D + 0.2D * (amplifier + 1);
/*      */     } 
/*  384 */     return baseSpeed;
/*      */   }
/*      */   
/*      */   public static boolean isPassive(Entity entity) {
/*  388 */     if (entity instanceof EntityWolf && ((EntityWolf)entity).func_70919_bu()) {
/*  389 */       return false;
/*      */     }
/*  391 */     if (entity instanceof net.minecraft.entity.EntityAgeable || entity instanceof net.minecraft.entity.passive.EntityAmbientCreature || entity instanceof net.minecraft.entity.passive.EntitySquid) {
/*  392 */       return true;
/*      */     }
/*  394 */     return (entity instanceof EntityIronGolem && ((EntityIronGolem)entity).func_70643_av() == null);
/*      */   }
/*      */   
/*      */   public static boolean isSafe(Entity entity, int height, boolean floor, boolean face) {
/*  398 */     return (getUnsafeBlocks(entity, height, floor).size() == 0);
/*      */   }
/*      */   
/*      */   public static boolean stopSneaking(boolean isSneaking) {
/*  402 */     if (isSneaking && EntityUtil.mc.field_71439_g != null) {
/*  403 */       EntityUtil.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketEntityAction((Entity)EntityUtil.mc.field_71439_g, CPacketEntityAction.Action.STOP_SNEAKING));
/*      */     }
/*  405 */     return false;
/*      */   }
/*      */   
/*      */   public static boolean isSafe(Entity entity) {
/*  409 */     return EntityUtil.isSafe(entity, 0, false, true);
/*      */   }
/*      */   
/*      */   public static BlockPos getPlayerPos(EntityPlayer player) {
/*  413 */     return new BlockPos(Math.floor(player.field_70165_t), Math.floor(player.field_70163_u), Math.floor(player.field_70161_v));
/*      */   }
/*      */   
/*      */   public static List<Vec3d> getUnsafeBlocks(Entity entity, int height, boolean floor) {
/*  417 */     return getUnsafeBlocksFromVec3d(entity.func_174791_d(), height, floor);
/*      */   }
/*      */   
/*      */   public static boolean isMobAggressive(Entity entity) {
/*  421 */     if (entity instanceof EntityPigZombie) {
/*  422 */       if (((EntityPigZombie)entity).func_184734_db() || ((EntityPigZombie)entity).func_175457_ck()) {
/*  423 */         return true;
/*      */       }
/*      */     } else {
/*  426 */       if (entity instanceof EntityWolf) {
/*  427 */         return (((EntityWolf)entity).func_70919_bu() && !EntityUtil.mc.field_71439_g.equals(((EntityWolf)entity).func_70902_q()));
/*      */       }
/*  429 */       if (entity instanceof EntityEnderman) {
/*  430 */         return ((EntityEnderman)entity).func_70823_r();
/*      */       }
/*      */     } 
/*  433 */     return EntityUtil.isHostileMob(entity);
/*      */   }
/*      */   
/*      */   public static boolean isNeutralMob(Entity entity) {
/*  437 */     return (entity instanceof EntityPigZombie || entity instanceof EntityWolf || entity instanceof EntityEnderman);
/*      */   }
/*      */   
/*      */   public static boolean isProjectile(Entity entity) {
/*  441 */     return (entity instanceof net.minecraft.entity.projectile.EntityShulkerBullet || entity instanceof net.minecraft.entity.projectile.EntityFireball);
/*      */   }
/*      */   
/*      */   public static boolean isVehicle(Entity entity) {
/*  445 */     return (entity instanceof net.minecraft.entity.item.EntityBoat || entity instanceof net.minecraft.entity.item.EntityMinecart);
/*      */   }
/*      */   
/*      */   public static boolean isFriendlyMob(Entity entity) {
/*  449 */     return ((entity.isCreatureType(EnumCreatureType.CREATURE, false) && !EntityUtil.isNeutralMob(entity)) || entity.isCreatureType(EnumCreatureType.AMBIENT, false) || entity instanceof net.minecraft.entity.passive.EntityVillager || entity instanceof EntityIronGolem || (EntityUtil.isNeutralMob(entity) && !EntityUtil.isMobAggressive(entity)));
/*      */   }
/*      */   
/*      */   public static boolean isHostileMob(Entity entity) {
/*  453 */     return (entity.isCreatureType(EnumCreatureType.MONSTER, false) && !EntityUtil.isNeutralMob(entity));
/*      */   }
/*      */   
/*      */   public static List<Vec3d> getUnsafeBlocksFromVec3d(Vec3d pos, int height, boolean floor) {
/*  457 */     ArrayList<Vec3d> vec3ds = new ArrayList<>();
/*  458 */     for (Vec3d vector : getOffsets(height, floor)) {
/*  459 */       BlockPos targetPos = (new BlockPos(pos)).func_177963_a(vector.field_72450_a, vector.field_72448_b, vector.field_72449_c);
/*  460 */       Block block = EntityUtil.mc.field_71441_e.func_180495_p(targetPos).func_177230_c();
/*  461 */       if (block instanceof net.minecraft.block.BlockAir || block instanceof net.minecraft.block.BlockLiquid || block instanceof net.minecraft.block.BlockTallGrass || block instanceof net.minecraft.block.BlockFire || block instanceof net.minecraft.block.BlockDeadBush || block instanceof net.minecraft.block.BlockSnow)
/*      */       {
/*  463 */         vec3ds.add(vector); } 
/*      */     } 
/*  465 */     return vec3ds;
/*      */   }
/*      */   
/*      */   public static boolean isInHole(Entity entity) {
/*  469 */     return EntityUtil.isBlockValid(new BlockPos(entity.field_70165_t, entity.field_70163_u, entity.field_70161_v));
/*      */   }
/*      */   
/*      */   public static boolean isBlockValid(BlockPos blockPos) {
/*  473 */     return (EntityUtil.isBedrockHole(blockPos) || EntityUtil.isObbyHole(blockPos) || EntityUtil.isBothHole(blockPos));
/*      */   } public static boolean isObbyHole(BlockPos blockPos) { BlockPos[] touchingBlocks;
/*      */     BlockPos[] arrayOfBlockPos1;
/*      */     int i;
/*      */     byte b;
/*  478 */     for (arrayOfBlockPos1 = touchingBlocks = new BlockPos[] { blockPos.func_177978_c(), blockPos.func_177968_d(), blockPos.func_177974_f(), blockPos.func_177976_e(), blockPos.func_177977_b() }, i = arrayOfBlockPos1.length, b = 0; b < i; ) { BlockPos pos = arrayOfBlockPos1[b];
/*  479 */       IBlockState touchingState = EntityUtil.mc.field_71441_e.func_180495_p(pos);
/*  480 */       if (touchingState.func_177230_c() != Blocks.field_150350_a && touchingState.func_177230_c() == Blocks.field_150343_Z) { b++; continue; }
/*  481 */        return false; }
/*      */     
/*  483 */     return true; }
/*      */   public static boolean isBedrockHole(BlockPos blockPos) { BlockPos[] touchingBlocks;
/*      */     BlockPos[] arrayOfBlockPos1;
/*      */     int i;
/*      */     byte b;
/*  488 */     for (arrayOfBlockPos1 = touchingBlocks = new BlockPos[] { blockPos.func_177978_c(), blockPos.func_177968_d(), blockPos.func_177974_f(), blockPos.func_177976_e(), blockPos.func_177977_b() }, i = arrayOfBlockPos1.length, b = 0; b < i; ) { BlockPos pos = arrayOfBlockPos1[b];
/*  489 */       IBlockState touchingState = EntityUtil.mc.field_71441_e.func_180495_p(pos);
/*  490 */       if (touchingState.func_177230_c() != Blocks.field_150350_a && touchingState.func_177230_c() == Blocks.field_150357_h) { b++; continue; }
/*  491 */        return false; }
/*      */     
/*  493 */     return true; } public static boolean isBothHole(BlockPos blockPos) {
/*      */     BlockPos[] touchingBlocks;
/*      */     BlockPos[] arrayOfBlockPos1;
/*      */     int i;
/*      */     byte b;
/*  498 */     for (arrayOfBlockPos1 = touchingBlocks = new BlockPos[] { blockPos.func_177978_c(), blockPos.func_177968_d(), blockPos.func_177974_f(), blockPos.func_177976_e(), blockPos.func_177977_b() }, i = arrayOfBlockPos1.length, b = 0; b < i; ) { BlockPos pos = arrayOfBlockPos1[b];
/*  499 */       IBlockState touchingState = EntityUtil.mc.field_71441_e.func_180495_p(pos);
/*  500 */       if (touchingState.func_177230_c() != Blocks.field_150350_a && (touchingState.func_177230_c() == Blocks.field_150357_h || touchingState.func_177230_c() == Blocks.field_150343_Z)) {
/*      */         b++; continue;
/*  502 */       }  return false; }
/*      */     
/*  504 */     return true;
/*      */   }
/*      */   
/*      */   public static Vec3d[] getUnsafeBlockArray(Entity entity, int height, boolean floor) {
/*  508 */     List<Vec3d> list = getUnsafeBlocks(entity, height, floor);
/*  509 */     Vec3d[] array = new Vec3d[list.size()];
/*  510 */     return list.<Vec3d>toArray(array);
/*      */   }
/*      */   
/*      */   public static Vec3d[] getUnsafeBlockArrayFromVec3d(Vec3d pos, int height, boolean floor) {
/*  514 */     List<Vec3d> list = getUnsafeBlocksFromVec3d(pos, height, floor);
/*  515 */     Vec3d[] array = new Vec3d[list.size()];
/*  516 */     return list.<Vec3d>toArray(array);
/*      */   }
/*      */   
/*      */   public static double getDst(Vec3d vec) {
/*  520 */     return EntityUtil.mc.field_71439_g.func_174791_d().func_72438_d(vec);
/*      */   }
/*      */   
/*      */   public static boolean isTrapped(EntityPlayer player, boolean antiScaffold, boolean antiStep, boolean legs, boolean platform, boolean antiDrop) {
/*  524 */     return (getUntrappedBlocks(player, antiScaffold, antiStep, legs, platform, antiDrop).size() == 0);
/*      */   }
/*      */   
/*      */   public static boolean isTrappedExtended(int extension, EntityPlayer player, boolean antiScaffold, boolean antiStep, boolean legs, boolean platform, boolean antiDrop, boolean raytrace) {
/*  528 */     return (getUntrappedBlocksExtended(extension, player, antiScaffold, antiStep, legs, platform, antiDrop, raytrace).size() == 0);
/*      */   }
/*      */   
/*      */   public static List<Vec3d> getUntrappedBlocks(EntityPlayer player, boolean antiScaffold, boolean antiStep, boolean legs, boolean platform, boolean antiDrop) {
/*  532 */     ArrayList<Vec3d> vec3ds = new ArrayList<>();
/*  533 */     if (!antiStep && getUnsafeBlocks((Entity)player, 2, false).size() == 4) {
/*  534 */       vec3ds.addAll(getUnsafeBlocks((Entity)player, 2, false));
/*      */     }
/*  536 */     for (int i = 0; i < (getTrapOffsets(antiScaffold, antiStep, legs, platform, antiDrop)).length; i++) {
/*  537 */       Vec3d vector = getTrapOffsets(antiScaffold, antiStep, legs, platform, antiDrop)[i];
/*  538 */       BlockPos targetPos = (new BlockPos(player.func_174791_d())).func_177963_a(vector.field_72450_a, vector.field_72448_b, vector.field_72449_c);
/*  539 */       Block block = EntityUtil.mc.field_71441_e.func_180495_p(targetPos).func_177230_c();
/*  540 */       if (block instanceof net.minecraft.block.BlockAir || block instanceof net.minecraft.block.BlockLiquid || block instanceof net.minecraft.block.BlockTallGrass || block instanceof net.minecraft.block.BlockFire || block instanceof net.minecraft.block.BlockDeadBush || block instanceof net.minecraft.block.BlockSnow)
/*      */       {
/*  542 */         vec3ds.add(vector); } 
/*      */     } 
/*  544 */     return vec3ds;
/*      */   }
/*      */   
/*      */   public static boolean isInWater(Entity entity) {
/*  548 */     if (entity == null) {
/*  549 */       return false;
/*      */     }
/*  551 */     double y = entity.field_70163_u + 0.01D;
/*  552 */     for (int x = MathHelper.func_76128_c(entity.field_70165_t); x < MathHelper.func_76143_f(entity.field_70165_t); x++) {
/*  553 */       for (int z = MathHelper.func_76128_c(entity.field_70161_v); z < MathHelper.func_76143_f(entity.field_70161_v); ) {
/*  554 */         BlockPos pos = new BlockPos(x, (int)y, z);
/*  555 */         if (!(EntityUtil.mc.field_71441_e.func_180495_p(pos).func_177230_c() instanceof net.minecraft.block.BlockLiquid)) { z++; continue; }
/*  556 */          return true;
/*      */       } 
/*      */     } 
/*  559 */     return false;
/*      */   }
/*      */   
/*      */   public static boolean isDrivenByPlayer(Entity entityIn) {
/*  563 */     return (EntityUtil.mc.field_71439_g != null && entityIn != null && entityIn.equals(EntityUtil.mc.field_71439_g.func_184187_bx()));
/*      */   }
/*      */   
/*      */   public static boolean isPlayer(Entity entity) {
/*  567 */     return entity instanceof EntityPlayer;
/*      */   }
/*      */   
/*      */   public static boolean isAboveWater(Entity entity) {
/*  571 */     return EntityUtil.isAboveWater(entity, false);
/*      */   }
/*      */   
/*      */   public static boolean isAboveWater(Entity entity, boolean packet) {
/*  575 */     if (entity == null) {
/*  576 */       return false;
/*      */     }
/*  578 */     double y = entity.field_70163_u - (packet ? 0.03D : (EntityUtil.isPlayer(entity) ? 0.2D : 0.5D));
/*  579 */     for (int x = MathHelper.func_76128_c(entity.field_70165_t); x < MathHelper.func_76143_f(entity.field_70165_t); x++) {
/*  580 */       for (int z = MathHelper.func_76128_c(entity.field_70161_v); z < MathHelper.func_76143_f(entity.field_70161_v); ) {
/*  581 */         BlockPos pos = new BlockPos(x, MathHelper.func_76128_c(y), z);
/*  582 */         if (!(EntityUtil.mc.field_71441_e.func_180495_p(pos).func_177230_c() instanceof net.minecraft.block.BlockLiquid)) { z++; continue; }
/*  583 */          return true;
/*      */       } 
/*      */     } 
/*  586 */     return false;
/*      */   }
/*      */   public static double[] calculateLookAt(double px, double py, double pz, EntityPlayer me) {
/*  589 */     double dirx = me.field_70165_t - px;
/*  590 */     double diry = me.field_70163_u - py;
/*  591 */     double dirz = me.field_70161_v - pz;
/*  592 */     double len = Math.sqrt(dirx * dirx + diry * diry + dirz * dirz);
/*  593 */     dirx /= len;
/*  594 */     diry /= len;
/*  595 */     dirz /= len;
/*  596 */     double pitch = Math.asin(diry);
/*  597 */     double yaw = Math.atan2(dirz, dirx);
/*  598 */     pitch = pitch * 180.0D / Math.PI;
/*  599 */     yaw = yaw * 180.0D / Math.PI;
/*  600 */     yaw += 90.0D;
/*  601 */     return new double[] { yaw, pitch };
/*      */   }
/*      */   
/*      */   public static List<Vec3d> getUntrappedBlocksExtended(int extension, EntityPlayer player, boolean antiScaffold, boolean antiStep, boolean legs, boolean platform, boolean antiDrop, boolean raytrace) {
/*  605 */     ArrayList<Vec3d> placeTargets = new ArrayList<>();
/*  606 */     if (extension == 1) {
/*  607 */       placeTargets.addAll(targets(player.func_174791_d(), antiScaffold, antiStep, legs, platform, antiDrop, raytrace));
/*      */     } else {
/*  609 */       int extend = 1;
/*  610 */       for (Vec3d vec3d : MathUtil.getBlockBlocks((Entity)player)) {
/*  611 */         if (extend > extension)
/*  612 */           break;  placeTargets.addAll(targets(vec3d, antiScaffold, antiStep, legs, platform, antiDrop, raytrace));
/*  613 */         extend++;
/*      */       } 
/*      */     } 
/*  616 */     ArrayList<Vec3d> removeList = new ArrayList<>();
/*  617 */     for (Vec3d vec3d : placeTargets) {
/*  618 */       BlockPos pos = new BlockPos(vec3d);
/*  619 */       if (BlockUtil.isPositionPlaceable(pos, raytrace) != -1)
/*  620 */         continue;  removeList.add(vec3d);
/*      */     } 
/*  622 */     for (Vec3d vec3d : removeList) {
/*  623 */       placeTargets.remove(vec3d);
/*      */     }
/*  625 */     return placeTargets;
/*      */   }
/*      */   
/*      */   public static List<Vec3d> targets(Vec3d vec3d, boolean antiScaffold, boolean antiStep, boolean legs, boolean platform, boolean antiDrop, boolean raytrace) {
/*  629 */     ArrayList<Vec3d> placeTargets = new ArrayList<>();
/*  630 */     if (antiDrop) {
/*  631 */       Collections.addAll(placeTargets, BlockUtil.convertVec3ds(vec3d, antiDropOffsetList));
/*      */     }
/*  633 */     if (platform) {
/*  634 */       Collections.addAll(placeTargets, BlockUtil.convertVec3ds(vec3d, platformOffsetList));
/*      */     }
/*  636 */     if (legs) {
/*  637 */       Collections.addAll(placeTargets, BlockUtil.convertVec3ds(vec3d, legOffsetList));
/*      */     }
/*  639 */     Collections.addAll(placeTargets, BlockUtil.convertVec3ds(vec3d, OffsetList));
/*  640 */     if (antiStep) {
/*  641 */       Collections.addAll(placeTargets, BlockUtil.convertVec3ds(vec3d, antiStepOffsetList));
/*      */     } else {
/*  643 */       List<Vec3d> vec3ds = getUnsafeBlocksFromVec3d(vec3d, 2, false);
/*  644 */       if (vec3ds.size() == 4)
/*      */       {
/*  646 */         for (Vec3d vector : vec3ds) {
/*  647 */           BlockPos position = (new BlockPos(vec3d)).func_177963_a(vector.field_72450_a, vector.field_72448_b, vector.field_72449_c);
/*  648 */           switch (BlockUtil.isPositionPlaceable(position, raytrace)) {
/*      */             case 0:
/*      */               break;
/*      */             
/*      */             case -1:
/*      */             case 1:
/*      */             case 2:
/*      */               continue;
/*      */             
/*      */             case 3:
/*  658 */               placeTargets.add(vec3d.func_178787_e(vector)); break;
/*      */             default:
/*      */               // Byte code: goto -> 234
/*      */           } 
/*  662 */           if (antiScaffold) {
/*  663 */             Collections.addAll(placeTargets, BlockUtil.convertVec3ds(vec3d, antiScaffoldOffsetList));
/*      */           }
/*  665 */           return placeTargets;
/*      */         } 
/*      */       }
/*      */     } 
/*  669 */     if (antiScaffold) {
/*  670 */       Collections.addAll(placeTargets, BlockUtil.convertVec3ds(vec3d, antiScaffoldOffsetList));
/*      */     }
/*  672 */     return placeTargets;
/*      */   }
/*      */   
/*      */   public static List<Vec3d> getOffsetList(int y, boolean floor) {
/*  676 */     ArrayList<Vec3d> offsets = new ArrayList<>();
/*  677 */     offsets.add(new Vec3d(-1.0D, y, 0.0D));
/*  678 */     offsets.add(new Vec3d(1.0D, y, 0.0D));
/*  679 */     offsets.add(new Vec3d(0.0D, y, -1.0D));
/*  680 */     offsets.add(new Vec3d(0.0D, y, 1.0D));
/*  681 */     if (floor) {
/*  682 */       offsets.add(new Vec3d(0.0D, (y - 1), 0.0D));
/*      */     }
/*  684 */     return offsets;
/*      */   }
/*      */   
/*      */   public static Vec3d[] getOffsets(int y, boolean floor) {
/*  688 */     List<Vec3d> offsets = getOffsetList(y, floor);
/*  689 */     Vec3d[] array = new Vec3d[offsets.size()];
/*  690 */     return offsets.<Vec3d>toArray(array);
/*      */   }
/*      */   
/*      */   public static Vec3d[] getTrapOffsets(boolean antiScaffold, boolean antiStep, boolean legs, boolean platform, boolean antiDrop) {
/*  694 */     List<Vec3d> offsets = getTrapOffsetsList(antiScaffold, antiStep, legs, platform, antiDrop);
/*  695 */     Vec3d[] array = new Vec3d[offsets.size()];
/*  696 */     return offsets.<Vec3d>toArray(array);
/*      */   }
/*      */   
/*      */   public static List<Vec3d> getTrapOffsetsList(boolean antiScaffold, boolean antiStep, boolean legs, boolean platform, boolean antiDrop) {
/*  700 */     ArrayList<Vec3d> offsets = new ArrayList<>(getOffsetList(1, false));
/*  701 */     offsets.add(new Vec3d(0.0D, 2.0D, 0.0D));
/*  702 */     if (antiScaffold) {
/*  703 */       offsets.add(new Vec3d(0.0D, 3.0D, 0.0D));
/*      */     }
/*  705 */     if (antiStep) {
/*  706 */       offsets.addAll(getOffsetList(2, false));
/*      */     }
/*  708 */     if (legs) {
/*  709 */       offsets.addAll(getOffsetList(0, false));
/*      */     }
/*  711 */     if (platform) {
/*  712 */       offsets.addAll(getOffsetList(-1, false));
/*  713 */       offsets.add(new Vec3d(0.0D, -1.0D, 0.0D));
/*      */     } 
/*  715 */     if (antiDrop) {
/*  716 */       offsets.add(new Vec3d(0.0D, -2.0D, 0.0D));
/*      */     }
/*  718 */     return offsets;
/*      */   }
/*      */   
/*      */   public static Vec3d[] getHeightOffsets(int min, int max) {
/*  722 */     ArrayList<Vec3d> offsets = new ArrayList<>();
/*  723 */     for (int i = min; i <= max; i++) {
/*  724 */       offsets.add(new Vec3d(0.0D, i, 0.0D));
/*      */     }
/*  726 */     Vec3d[] array = new Vec3d[offsets.size()];
/*  727 */     return offsets.<Vec3d>toArray(array);
/*      */   }
/*      */   
/*      */   public static BlockPos getRoundedBlockPos(Entity entity) {
/*  731 */     return new BlockPos(MathUtil.roundVec(entity.func_174791_d(), 0));
/*      */   }
/*      */   
/*      */   public static boolean isLiving(Entity entity) {
/*  735 */     return entity instanceof EntityLivingBase;
/*      */   }
/*      */   
/*      */   public static boolean isAlive(Entity entity) {
/*  739 */     return (EntityUtil.isLiving(entity) && !entity.field_70128_L && ((EntityLivingBase)entity).func_110143_aJ() > 0.0F);
/*      */   }
/*      */   
/*      */   public static boolean isDead(Entity entity) {
/*  743 */     return !EntityUtil.isAlive(entity);
/*      */   }
/*      */   
/*      */   public static float getHealth(Entity entity) {
/*  747 */     if (EntityUtil.isLiving(entity)) {
/*  748 */       EntityLivingBase livingBase = (EntityLivingBase)entity;
/*  749 */       return livingBase.func_110143_aJ() + livingBase.func_110139_bj();
/*      */     } 
/*  751 */     return 0.0F;
/*      */   }
/*      */   
/*      */   public static float getHealth(Entity entity, boolean absorption) {
/*  755 */     if (EntityUtil.isLiving(entity)) {
/*  756 */       EntityLivingBase livingBase = (EntityLivingBase)entity;
/*  757 */       return livingBase.func_110143_aJ() + (absorption ? livingBase.func_110139_bj() : 0.0F);
/*      */     } 
/*  759 */     return 0.0F;
/*      */   }
/*      */   
/*      */   public static boolean canEntityFeetBeSeen(Entity entityIn) {
/*  763 */     return (EntityUtil.mc.field_71441_e.func_147447_a(new Vec3d(EntityUtil.mc.field_71439_g.field_70165_t, EntityUtil.mc.field_71439_g.field_70165_t + EntityUtil.mc.field_71439_g.func_70047_e(), EntityUtil.mc.field_71439_g.field_70161_v), new Vec3d(entityIn.field_70165_t, entityIn.field_70163_u, entityIn.field_70161_v), false, true, false) == null);
/*      */   }
/*      */   
/*      */   public static boolean isntValid(Entity entity, double range) {
/*  767 */     return (entity == null || EntityUtil.isDead(entity) || entity.equals(EntityUtil.mc.field_71439_g) || (entity instanceof EntityPlayer && Phobos.friendManager.isFriend(entity.func_70005_c_())) || EntityUtil.mc.field_71439_g.func_70068_e(entity) > MathUtil.square(range));
/*      */   }
/*      */   
/*      */   public static boolean isValid(Entity entity, double range) {
/*  771 */     return !EntityUtil.isntValid(entity, range);
/*      */   }
/*      */   
/*      */   public static boolean holdingWeapon(EntityPlayer player) {
/*  775 */     return (player.func_184614_ca().func_77973_b() instanceof net.minecraft.item.ItemSword || player.func_184614_ca().func_77973_b() instanceof net.minecraft.item.ItemAxe);
/*      */   }
/*      */   
/*      */   public static double getMaxSpeed() {
/*  779 */     double maxModifier = 0.2873D;
/*  780 */     if (EntityUtil.mc.field_71439_g.func_70644_a(Objects.<Potion>requireNonNull(Potion.func_188412_a(1)))) {
/*  781 */       maxModifier *= 1.0D + 0.2D * (((PotionEffect)Objects.<PotionEffect>requireNonNull(EntityUtil.mc.field_71439_g.func_70660_b(Objects.<Potion>requireNonNull(Potion.func_188412_a(1))))).func_76458_c() + 1);
/*      */     }
/*  783 */     return maxModifier;
/*      */   }
/*      */   
/*      */   public static void mutliplyEntitySpeed(Entity entity, double multiplier) {
/*  787 */     if (entity != null) {
/*  788 */       entity.field_70159_w *= multiplier;
/*  789 */       entity.field_70179_y *= multiplier;
/*      */     } 
/*      */   }
/*      */   
/*      */   public static boolean isEntityMoving(Entity entity) {
/*  794 */     if (entity == null) {
/*  795 */       return false;
/*      */     }
/*  797 */     if (entity instanceof EntityPlayer) {
/*  798 */       return (EntityUtil.mc.field_71474_y.field_74351_w.func_151470_d() || EntityUtil.mc.field_71474_y.field_74368_y.func_151470_d() || EntityUtil.mc.field_71474_y.field_74370_x.func_151470_d() || EntityUtil.mc.field_71474_y.field_74366_z.func_151470_d());
/*      */     }
/*  800 */     return (entity.field_70159_w != 0.0D || entity.field_70181_x != 0.0D || entity.field_70179_y != 0.0D);
/*      */   }
/*      */   
/*      */   public static double getEntitySpeed(Entity entity) {
/*  804 */     if (entity != null) {
/*  805 */       double distTraveledLastTickX = entity.field_70165_t - entity.field_70169_q;
/*  806 */       double distTraveledLastTickZ = entity.field_70161_v - entity.field_70166_s;
/*  807 */       double speed = MathHelper.func_76133_a(distTraveledLastTickX * distTraveledLastTickX + distTraveledLastTickZ * distTraveledLastTickZ);
/*  808 */       return speed * 20.0D;
/*      */     } 
/*  810 */     return 0.0D;
/*      */   }
/*      */   
/*      */   public static boolean is32k(ItemStack stack) {
/*  814 */     return (EnchantmentHelper.func_77506_a(Enchantments.field_185302_k, stack) >= 1000);
/*      */   }
/*      */   
/*      */   public static void moveEntityStrafe(double speed, Entity entity) {
/*  818 */     if (entity != null) {
/*  819 */       MovementInput movementInput = EntityUtil.mc.field_71439_g.field_71158_b;
/*  820 */       double forward = movementInput.field_192832_b;
/*  821 */       double strafe = movementInput.field_78902_a;
/*  822 */       float yaw = EntityUtil.mc.field_71439_g.field_70177_z;
/*  823 */       if (forward == 0.0D && strafe == 0.0D) {
/*  824 */         entity.field_70159_w = 0.0D;
/*  825 */         entity.field_70179_y = 0.0D;
/*      */       } else {
/*  827 */         if (forward != 0.0D) {
/*  828 */           if (strafe > 0.0D) {
/*  829 */             yaw += ((forward > 0.0D) ? -45 : 45);
/*  830 */           } else if (strafe < 0.0D) {
/*  831 */             yaw += ((forward > 0.0D) ? 45 : -45);
/*      */           } 
/*  833 */           strafe = 0.0D;
/*  834 */           if (forward > 0.0D) {
/*  835 */             forward = 1.0D;
/*  836 */           } else if (forward < 0.0D) {
/*  837 */             forward = -1.0D;
/*      */           } 
/*      */         } 
/*  840 */         entity.field_70159_w = forward * speed * Math.cos(Math.toRadians((yaw + 90.0F))) + strafe * speed * Math.sin(Math.toRadians((yaw + 90.0F)));
/*  841 */         entity.field_70179_y = forward * speed * Math.sin(Math.toRadians((yaw + 90.0F))) - strafe * speed * Math.cos(Math.toRadians((yaw + 90.0F)));
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public static boolean rayTraceHitCheck(Entity entity, boolean shouldCheck) {
/*  847 */     return (!shouldCheck || EntityUtil.mc.field_71439_g.func_70685_l(entity));
/*      */   }
/*      */   
/*      */   public static Color getColor(Entity entity, int red, int green, int blue, int alpha, boolean colorFriends) {
/*  851 */     Color color = new Color(red / 255.0F, green / 255.0F, blue / 255.0F, alpha / 255.0F);
/*  852 */     if (entity instanceof EntityPlayer && colorFriends && Phobos.friendManager.isFriend((EntityPlayer)entity)) {
/*  853 */       color = new Color(0.33333334F, 1.0F, 1.0F, alpha / 255.0F);
/*      */     }
/*  855 */     return color;
/*      */   }
/*      */   
/*      */   public static boolean isMoving() {
/*  859 */     return (EntityUtil.mc.field_71439_g.field_191988_bg != 0.0D || EntityUtil.mc.field_71439_g.field_70702_br != 0.0D);
/*      */   }
/*      */   
/*      */   public static boolean isMoving(EntityLivingBase entity) {
/*  863 */     return (entity.field_191988_bg != 0.0F || entity.field_70702_br != 0.0F);
/*      */   }
/*      */   
/*      */   public static EntityPlayer getClosestEnemy(double distance) {
/*  867 */     EntityPlayer closest = null;
/*  868 */     for (EntityPlayer player : EntityUtil.mc.field_71441_e.field_73010_i) {
/*  869 */       if (EntityUtil.isntValid((Entity)player, distance))
/*  870 */         continue;  if (closest == null) {
/*  871 */         closest = player;
/*      */         continue;
/*      */       } 
/*  874 */       if (EntityUtil.mc.field_71439_g.func_70068_e((Entity)player) >= EntityUtil.mc.field_71439_g.func_70068_e((Entity)closest))
/*      */         continue; 
/*  876 */       closest = player;
/*      */     } 
/*  878 */     return closest;
/*      */   }
/*      */   
/*      */   public static boolean checkCollide() {
/*  882 */     if (EntityUtil.mc.field_71439_g.func_70093_af()) {
/*  883 */       return false;
/*      */     }
/*  885 */     if (EntityUtil.mc.field_71439_g.func_184187_bx() != null && (EntityUtil.mc.field_71439_g.func_184187_bx()).field_70143_R >= 3.0F) {
/*  886 */       return false;
/*      */     }
/*  888 */     return (EntityUtil.mc.field_71439_g.field_70143_R < 3.0F);
/*      */   }
/*      */   
/*      */   public static BlockPos getPlayerPosWithEntity() {
/*  892 */     return new BlockPos((EntityUtil.mc.field_71439_g.func_184187_bx() != null) ? (EntityUtil.mc.field_71439_g.func_184187_bx()).field_70165_t : EntityUtil.mc.field_71439_g.field_70165_t, (EntityUtil.mc.field_71439_g.func_184187_bx() != null) ? (EntityUtil.mc.field_71439_g.func_184187_bx()).field_70163_u : EntityUtil.mc.field_71439_g.field_70163_u, (EntityUtil.mc.field_71439_g.func_184187_bx() != null) ? (EntityUtil.mc.field_71439_g.func_184187_bx()).field_70161_v : EntityUtil.mc.field_71439_g.field_70161_v);
/*      */   }
/*      */   public static boolean isCrystalAtFeet(EntityEnderCrystal crystal, double range) {
/*  895 */     for (EntityPlayer player : EntityUtil.mc.field_71441_e.field_73010_i) {
/*  896 */       if (EntityUtil.mc.field_71439_g.func_70068_e((Entity)player) > range * range) {
/*      */         continue;
/*      */       }
/*  899 */       if (Phobos.friendManager.isFriend(player)) {
/*      */         continue;
/*      */       }
/*  902 */       for (Vec3d vec : EntityUtil.doubleLegOffsetList) {
/*  903 */         if ((new BlockPos(player.func_174791_d())).func_177963_a(vec.field_72450_a, vec.field_72448_b, vec.field_72449_c) == crystal.func_180425_c()) {
/*  904 */           return true;
/*      */         }
/*      */       } 
/*      */     } 
/*  908 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public static double[] forward(double speed) {
/*  913 */     float forward = EntityUtil.mc.field_71439_g.field_71158_b.field_192832_b;
/*  914 */     float side = EntityUtil.mc.field_71439_g.field_71158_b.field_78902_a;
/*  915 */     float yaw = EntityUtil.mc.field_71439_g.field_70126_B + (EntityUtil.mc.field_71439_g.field_70177_z - EntityUtil.mc.field_71439_g.field_70126_B) * mc.func_184121_ak();
/*  916 */     if (forward != 0.0F) {
/*  917 */       if (side > 0.0F) {
/*  918 */         yaw += ((forward > 0.0F) ? -45 : 45);
/*  919 */       } else if (side < 0.0F) {
/*  920 */         yaw += ((forward > 0.0F) ? 45 : -45);
/*      */       } 
/*  922 */       side = 0.0F;
/*  923 */       if (forward > 0.0F) {
/*  924 */         forward = 1.0F;
/*  925 */       } else if (forward < 0.0F) {
/*  926 */         forward = -1.0F;
/*      */       } 
/*      */     } 
/*  929 */     double sin = Math.sin(Math.toRadians((yaw + 90.0F)));
/*  930 */     double cos = Math.cos(Math.toRadians((yaw + 90.0F)));
/*  931 */     double posX = forward * speed * cos + side * speed * sin;
/*  932 */     double posZ = forward * speed * sin - side * speed * cos;
/*  933 */     return new double[] { posX, posZ };
/*      */   }
/*      */   public static void swingArmNoPacket(EnumHand hand, EntityLivingBase entity) {
/*  936 */     ItemStack stack = entity.func_184586_b(hand);
/*  937 */     if (!stack.func_190926_b() && stack.func_77973_b().onEntitySwing(entity, stack)) {
/*      */       return;
/*      */     }
/*  940 */     if (!entity.field_82175_bq || entity.field_110158_av >= ((IEntityLivingBase)entity).getArmSwingAnimationEnd() / 2 || entity.field_110158_av < 0) {
/*  941 */       entity.field_110158_av = -1;
/*  942 */       entity.field_82175_bq = true;
/*  943 */       entity.field_184622_au = hand;
/*      */     } 
/*      */   }
/*      */   
/*      */   public static Map<String, Integer> getTextRadarPlayers() {
/*  948 */     Map<String, Integer> output = new HashMap<>();
/*  949 */     DecimalFormat dfHealth = new DecimalFormat("#.#");
/*  950 */     dfHealth.setRoundingMode(RoundingMode.CEILING);
/*  951 */     DecimalFormat dfDistance = new DecimalFormat("#.#");
/*  952 */     dfDistance.setRoundingMode(RoundingMode.CEILING);
/*  953 */     StringBuilder healthSB = new StringBuilder();
/*  954 */     StringBuilder distanceSB = new StringBuilder();
/*  955 */     for (EntityPlayer player : EntityUtil.mc.field_71441_e.field_73010_i) {
/*  956 */       if (player.func_82150_aj() || player.func_70005_c_().equals(EntityUtil.mc.field_71439_g.func_70005_c_()))
/*  957 */         continue;  int hpRaw = (int)EntityUtil.getHealth((Entity)player);
/*  958 */       String hp = dfHealth.format(hpRaw);
/*  959 */       healthSB.append("Â§");
/*  960 */       if (hpRaw >= 20) {
/*  961 */         healthSB.append("a");
/*  962 */       } else if (hpRaw >= 10) {
/*  963 */         healthSB.append("e");
/*  964 */       } else if (hpRaw >= 5) {
/*  965 */         healthSB.append("6");
/*      */       } else {
/*  967 */         healthSB.append("c");
/*      */       } 
/*  969 */       healthSB.append(hp);
/*  970 */       int distanceInt = (int)EntityUtil.mc.field_71439_g.func_70032_d((Entity)player);
/*  971 */       String distance = dfDistance.format(distanceInt);
/*  972 */       distanceSB.append("Â§");
/*  973 */       if (distanceInt >= 25) {
/*  974 */         distanceSB.append("a");
/*  975 */       } else if (distanceInt > 10) {
/*  976 */         distanceSB.append("6");
/*      */       } else {
/*  978 */         distanceSB.append("c");
/*      */       } 
/*  980 */       distanceSB.append(distance);
/*  981 */       output.put(healthSB.toString() + " " + (Phobos.friendManager.isFriend(player) ? (String)ChatFormatting.AQUA : (String)ChatFormatting.RED) + player.func_70005_c_() + " " + distanceSB.toString() + " Â§f0", Integer.valueOf((int)EntityUtil.mc.field_71439_g.func_70032_d((Entity)player)));
/*  982 */       healthSB.setLength(0);
/*  983 */       distanceSB.setLength(0);
/*      */     } 
/*  985 */     if (!output.isEmpty()) {
/*  986 */       output = MathUtil.sortByValue(output, false);
/*      */     }
/*  988 */     return output;
/*      */   }
/*      */   
/*      */   public static void setTimer(float speed) {
/*  992 */     (Minecraft.func_71410_x()).field_71428_T.field_194149_e = 50.0F / speed;
/*      */   }
/*      */   
/*      */   public static Block isColliding(double posX, double posY, double posZ) {
/*  996 */     Block block = null;
/*  997 */     if (mc.field_71439_g != null) {
/*  998 */       AxisAlignedBB bb = (mc.field_71439_g.func_184187_bx() != null) ? mc.field_71439_g.func_184187_bx().func_174813_aQ().func_191195_a(0.0D, 0.0D, 0.0D).func_72317_d(posX, posY, posZ) : mc.field_71439_g.func_174813_aQ().func_191195_a(0.0D, 0.0D, 0.0D).func_72317_d(posX, posY, posZ);
/*  999 */       int y = (int)bb.field_72338_b;
/* 1000 */       for (int x = MathHelper.func_76128_c(bb.field_72340_a); x < MathHelper.func_76128_c(bb.field_72336_d) + 1; x++) {
/* 1001 */         for (int z = MathHelper.func_76128_c(bb.field_72339_c); z < MathHelper.func_76128_c(bb.field_72334_f) + 1; z++) {
/* 1002 */           block = mc.field_71441_e.func_180495_p(new BlockPos(x, y, z)).func_177230_c();
/*      */         }
/*      */       } 
/*      */     } 
/* 1006 */     return block;
/*      */   }
/*      */ 
/*      */   
/*      */   public static boolean isAboveBlock(Entity entity, BlockPos blockPos) {
/* 1011 */     return (entity.field_70163_u >= blockPos.func_177956_o());
/*      */   }
/*      */ }


/* Location:              C:\Users\Administrator\Desktop\ShitClient\HayBale-1.0.1-b8.jar!\me\luxtix\haybal\\util\EntityUtil2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */