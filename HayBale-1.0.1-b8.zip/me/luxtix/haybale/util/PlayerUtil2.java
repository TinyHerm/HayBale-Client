/*     */ package me.luxtix.haybale.util;
/*     */ import com.google.gson.JsonArray;
/*     */ import com.google.gson.JsonElement;
/*     */ import com.google.gson.JsonObject;
/*     */ import com.google.gson.JsonParser;
/*     */ import com.mojang.util.UUIDTypeAdapter;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URL;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Scanner;
/*     */ import java.util.UUID;
/*     */ import javax.net.ssl.HttpsURLConnection;
/*     */ import me.luxtix.haybale.features.command.Command;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.client.network.NetHandlerPlayClient;
/*     */ import net.minecraft.client.network.NetworkPlayerInfo;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.potion.Potion;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ 
/*     */ public class PlayerUtil2 implements Util {
/*  31 */   private static final JsonParser PARSER = new JsonParser();
/*     */   
/*     */   public static String getNameFromUUID(UUID uuid) {
/*     */     try {
/*  35 */       lookUpName process = new lookUpName(uuid);
/*  36 */       Thread thread = new Thread(process);
/*  37 */       thread.start();
/*  38 */       thread.join();
/*  39 */       return process.getName();
/*  40 */     } catch (Exception e) {
/*  41 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static BlockPos getPlayerPos() {
/*  46 */     return new BlockPos(Math.floor(mc.field_71439_g.field_70165_t), Math.floor(mc.field_71439_g.field_70163_u), Math.floor(mc.field_71439_g.field_70161_v));
/*     */   }
/*     */   
/*     */   public static double getBaseMoveSpeed() {
/*  50 */     double baseSpeed = 0.2873D;
/*  51 */     if (mc.field_71439_g != null && mc.field_71439_g.func_70644_a(Potion.func_188412_a(1))) {
/*  52 */       int amplifier = mc.field_71439_g.func_70660_b(Potion.func_188412_a(1)).func_76458_c();
/*  53 */       baseSpeed *= 1.0D + 0.2D * (amplifier + 1);
/*     */     } 
/*  55 */     return baseSpeed;
/*     */   }
/*     */   
/*     */   public static boolean isMoving(EntityLivingBase entity) {
/*  59 */     return (entity.field_191988_bg != 0.0F || entity.field_70702_br != 0.0F);
/*     */   }
/*     */   
/*     */   public static void setSpeed(EntityLivingBase entity, double speed) {
/*  63 */     double[] dir = forward(speed);
/*  64 */     entity.field_70159_w = dir[0];
/*  65 */     entity.field_70179_y = dir[1];
/*     */   }
/*     */   
/*     */   public static double[] forward(double speed) {
/*  69 */     float forward = mc.field_71439_g.field_71158_b.field_192832_b;
/*  70 */     float side = mc.field_71439_g.field_71158_b.field_78902_a;
/*  71 */     float yaw = mc.field_71439_g.field_70126_B + (mc.field_71439_g.field_70177_z - mc.field_71439_g.field_70126_B) * mc.func_184121_ak();
/*  72 */     if (forward != 0.0F) {
/*  73 */       if (side > 0.0F) {
/*  74 */         yaw += ((forward > 0.0F) ? -45 : 45);
/*  75 */       } else if (side < 0.0F) {
/*  76 */         yaw += ((forward > 0.0F) ? 45 : -45);
/*     */       } 
/*  78 */       side = 0.0F;
/*  79 */       if (forward > 0.0F) {
/*  80 */         forward = 1.0F;
/*  81 */       } else if (forward < 0.0F) {
/*  82 */         forward = -1.0F;
/*     */       } 
/*     */     } 
/*  85 */     double sin = Math.sin(Math.toRadians((yaw + 90.0F)));
/*  86 */     double cos = Math.cos(Math.toRadians((yaw + 90.0F)));
/*  87 */     double posX = forward * speed * cos + side * speed * sin;
/*  88 */     double posZ = forward * speed * sin - side * speed * cos;
/*  89 */     return new double[] { posX, posZ };
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getNameFromUUID(String uuid) {
/*     */     try {
/*  95 */       lookUpName process = new lookUpName(uuid);
/*  96 */       Thread thread = new Thread(process);
/*  97 */       thread.start();
/*  98 */       thread.join();
/*  99 */       return process.getName();
/* 100 */     } catch (Exception e) {
/* 101 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static UUID getUUIDFromName(String name) {
/*     */     try {
/* 107 */       lookUpUUID process = new lookUpUUID(name);
/* 108 */       Thread thread = new Thread(process);
/* 109 */       thread.start();
/* 110 */       thread.join();
/* 111 */       return process.getUUID();
/* 112 */     } catch (Exception e) {
/* 113 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static String requestIDs(String data) {
/*     */     try {
/* 119 */       String query = "https://api.mojang.com/profiles/minecraft";
/* 120 */       URL url = new URL(query);
/* 121 */       HttpURLConnection conn = (HttpURLConnection)url.openConnection();
/* 122 */       conn.setConnectTimeout(5000);
/* 123 */       conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
/* 124 */       conn.setDoOutput(true);
/* 125 */       conn.setDoInput(true);
/* 126 */       conn.setRequestMethod("POST");
/* 127 */       OutputStream os = conn.getOutputStream();
/* 128 */       os.write(data.getBytes(StandardCharsets.UTF_8));
/* 129 */       os.close();
/* 130 */       InputStream in = new BufferedInputStream(conn.getInputStream());
/* 131 */       String res = convertStreamToString(in);
/* 132 */       in.close();
/* 133 */       conn.disconnect();
/* 134 */       return res;
/* 135 */     } catch (Exception e) {
/* 136 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static String convertStreamToString(InputStream is) {
/* 141 */     Scanner s = (new Scanner(is)).useDelimiter("\\A");
/* 142 */     return s.hasNext() ? s.next() : "/";
/*     */   }
/*     */   
/*     */   public static List<String> getHistoryOfNames(UUID id) {
/*     */     try {
/* 147 */       JsonArray array = getResources(new URL("https://api.mojang.com/user/profiles/" + getIdNoHyphens(id) + "/names"), "GET").getAsJsonArray();
/* 148 */       List<String> temp = Lists.newArrayList();
/* 149 */       for (JsonElement e : array) {
/* 150 */         JsonObject node = e.getAsJsonObject();
/* 151 */         String name = node.get("name").getAsString();
/* 152 */         long changedAt = node.has("changedToAt") ? node.get("changedToAt").getAsLong() : 0L;
/* 153 */         temp.add(name + "Ã‚Â§8" + (new Date(changedAt)).toString());
/*     */       } 
/* 155 */       Collections.sort(temp);
/* 156 */       return temp;
/* 157 */     } catch (Exception ignored) {
/* 158 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static int findObiInHotbar() {
/* 163 */     for (int i = 0; i < 9; i++) {
/* 164 */       ItemStack stack = mc.field_71439_g.field_71071_by.func_70301_a(i);
/* 165 */       if (stack != ItemStack.field_190927_a && stack.func_77973_b() instanceof ItemBlock) {
/* 166 */         Block block = ((ItemBlock)stack.func_77973_b()).func_179223_d();
/* 167 */         if (block instanceof net.minecraft.block.BlockEnderChest)
/* 168 */           return i; 
/* 169 */         if (block instanceof net.minecraft.block.BlockObsidian)
/* 170 */           return i; 
/*     */       } 
/*     */     } 
/* 173 */     return -1;
/*     */   }
/*     */   
/*     */   public static String getIdNoHyphens(UUID uuid) {
/* 177 */     return uuid.toString().replaceAll("-", "");
/*     */   }
/*     */   
/*     */   private static JsonElement getResources(URL url, String request) throws Exception {
/* 181 */     return getResources(url, request, null);
/*     */   }
/*     */   
/*     */   private static JsonElement getResources(URL url, String request, JsonElement element) throws Exception {
/* 185 */     HttpsURLConnection connection = null;
/*     */     try {
/* 187 */       connection = (HttpsURLConnection)url.openConnection();
/* 188 */       connection.setDoOutput(true);
/* 189 */       connection.setRequestMethod(request);
/* 190 */       connection.setRequestProperty("Content-Type", "application/json");
/* 191 */       if (element != null) {
/* 192 */         DataOutputStream output = new DataOutputStream(connection.getOutputStream());
/* 193 */         output.writeBytes(AdvancementManager.field_192783_b.toJson(element));
/* 194 */         output.close();
/*     */       } 
/* 196 */       Scanner scanner = new Scanner(connection.getInputStream());
/* 197 */       StringBuilder builder = new StringBuilder();
/* 198 */       while (scanner.hasNextLine()) {
/* 199 */         builder.append(scanner.nextLine());
/* 200 */         builder.append('\n');
/*     */       } 
/* 202 */       scanner.close();
/* 203 */       String json = builder.toString();
/* 204 */       JsonElement data = PARSER.parse(json);
/* 205 */       return data;
/*     */     } finally {
/* 207 */       if (connection != null)
/* 208 */         connection.disconnect(); 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static class lookUpUUID implements Runnable {
/*     */     private final String name;
/*     */     private volatile UUID uuid;
/*     */     
/*     */     public lookUpUUID(String name) {
/* 217 */       this.name = name;
/*     */     }
/*     */     
/*     */     public void run() {
/*     */       NetworkPlayerInfo profile;
/*     */       try {
/* 223 */         ArrayList<NetworkPlayerInfo> infoMap = new ArrayList<>(((NetHandlerPlayClient)Objects.<NetHandlerPlayClient>requireNonNull(Util.mc.func_147114_u())).func_175106_d());
/* 224 */         profile = infoMap.stream().filter(networkPlayerInfo -> networkPlayerInfo.func_178845_a().getName().equalsIgnoreCase(this.name)).findFirst().orElse(null);
/* 225 */         assert profile != null;
/* 226 */         this.uuid = profile.func_178845_a().getId();
/* 227 */       } catch (Exception e) {
/* 228 */         profile = null;
/*     */       } 
/* 230 */       if (profile == null) {
/* 231 */         Command.sendMessage("Player isn't online. Looking up UUID..");
/* 232 */         String s = PlayerUtil.requestIDs("[\"" + this.name + "\"]");
/* 233 */         if (s == null || s.isEmpty()) {
/* 234 */           Command.sendMessage("Couldn't find player ID. Are you connected to the internet? (0)");
/*     */         } else {
/* 236 */           JsonElement element = (new JsonParser()).parse(s);
/* 237 */           if (element.getAsJsonArray().size() == 0) {
/* 238 */             Command.sendMessage("Couldn't find player ID. (1)");
/*     */           } else {
/*     */             try {
/* 241 */               String id = element.getAsJsonArray().get(0).getAsJsonObject().get("id").getAsString();
/* 242 */               this.uuid = UUIDTypeAdapter.fromString(id);
/* 243 */             } catch (Exception e) {
/* 244 */               e.printStackTrace();
/* 245 */               Command.sendMessage("Couldn't find player ID. (2)");
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     public UUID getUUID() {
/* 253 */       return this.uuid;
/*     */     }
/*     */     
/*     */     public String getName() {
/* 257 */       return this.name;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class lookUpName implements Runnable {
/*     */     private final String uuid;
/*     */     private final UUID uuidID;
/*     */     private volatile String name;
/*     */     
/*     */     public lookUpName(String input) {
/* 267 */       this.uuid = input;
/* 268 */       this.uuidID = UUID.fromString(input);
/*     */     }
/*     */     
/*     */     public lookUpName(UUID input) {
/* 272 */       this.uuidID = input;
/* 273 */       this.uuid = input.toString();
/*     */     }
/*     */     
/*     */     public void run() {
/* 277 */       this.name = lookUpName();
/*     */     }
/*     */     
/*     */     public String lookUpName() {
/* 281 */       EntityPlayer player = null;
/* 282 */       if (Util.mc.field_71441_e != null) {
/* 283 */         player = Util.mc.field_71441_e.func_152378_a(this.uuidID);
/*     */       }
/* 285 */       if (player == null) {
/* 286 */         String url = "https://api.mojang.com/user/profiles/" + this.uuid.replace("-", "") + "/names";
/*     */         try {
/* 288 */           String nameJson = IOUtils.toString(new URL(url));
/* 289 */           if (nameJson.contains(",")) {
/* 290 */             List<String> names = Arrays.asList(nameJson.split(","));
/* 291 */             Collections.reverse(names);
/* 292 */             return ((String)names.get(1)).replace("{\"name\":\"", "").replace("\"", "");
/*     */           } 
/* 294 */           return nameJson.replace("[{\"name\":\"", "").replace("\"}]", "");
/*     */         }
/* 296 */         catch (IOException exception) {
/* 297 */           exception.printStackTrace();
/* 298 */           return null;
/*     */         } 
/*     */       } 
/* 301 */       return player.func_70005_c_();
/*     */     }
/*     */     
/*     */     public String getName() {
/* 305 */       return this.name;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\ShitClient\HayBale-1.0.1-b8.jar!\me\luxtix\haybal\\util\PlayerUtil2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */