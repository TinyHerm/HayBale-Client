/*     */ package me.luxtix.haybale.util;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ 
/*     */ public class HoleUtil
/*     */   implements Globals {
/*     */   public static BlockSafety isBlockSafe(Block block) {
/*  13 */     if (block == Blocks.field_150357_h) {
/*  14 */       return BlockSafety.UNBREAKABLE;
/*     */     }
/*  16 */     if (block == Blocks.field_150343_Z || block == Blocks.field_150477_bB || block == Blocks.field_150467_bQ) {
/*  17 */       return BlockSafety.RESISTANT;
/*     */     }
/*  19 */     return BlockSafety.BREAKABLE;
/*     */   }
/*     */   
/*     */   public static HoleInfo isHole(BlockPos centreBlock, boolean onlyOneWide, boolean ignoreDown) {
/*  23 */     HoleInfo output = new HoleInfo();
/*  24 */     HashMap<BlockOffset, BlockSafety> unsafeSides = getUnsafeSides(centreBlock);
/*     */     
/*  26 */     if (unsafeSides.containsKey(BlockOffset.DOWN) && 
/*  27 */       unsafeSides.remove(BlockOffset.DOWN, BlockSafety.BREAKABLE) && 
/*  28 */       !ignoreDown) {
/*  29 */       output.setSafety(BlockSafety.BREAKABLE);
/*  30 */       return output;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  35 */     int size = unsafeSides.size();
/*     */     
/*  37 */     unsafeSides.entrySet().removeIf(entry -> (entry.getValue() == BlockSafety.RESISTANT));
/*     */ 
/*     */     
/*  40 */     if (unsafeSides.size() != size) {
/*  41 */       output.setSafety(BlockSafety.RESISTANT);
/*     */     }
/*     */     
/*  44 */     size = unsafeSides.size();
/*     */ 
/*     */     
/*  47 */     if (size == 0) {
/*  48 */       output.setType(HoleType.SINGLE);
/*  49 */       output.setCentre(new AxisAlignedBB(centreBlock));
/*  50 */       return output;
/*     */     } 
/*     */     
/*  53 */     if (size == 1 && !onlyOneWide) {
/*  54 */       return isDoubleHole(output, centreBlock, unsafeSides.keySet().stream().findFirst().get());
/*     */     }
/*  56 */     output.setSafety(BlockSafety.BREAKABLE);
/*  57 */     return output;
/*     */   }
/*     */ 
/*     */   
/*     */   private static HoleInfo isDoubleHole(HoleInfo info, BlockPos centreBlock, BlockOffset weakSide) {
/*  62 */     BlockPos unsafePos = weakSide.offset(centreBlock);
/*     */     
/*  64 */     HashMap<BlockOffset, BlockSafety> unsafeSides = getUnsafeSides(unsafePos);
/*     */     
/*  66 */     int size = unsafeSides.size();
/*     */     
/*  68 */     unsafeSides.entrySet().removeIf(entry -> (entry.getValue() == BlockSafety.RESISTANT));
/*     */ 
/*     */     
/*  71 */     if (unsafeSides.size() != size) {
/*  72 */       info.setSafety(BlockSafety.RESISTANT);
/*     */     }
/*     */     
/*  75 */     if (unsafeSides.containsKey(BlockOffset.DOWN)) {
/*  76 */       info.setType(HoleType.CUSTOM);
/*  77 */       unsafeSides.remove(BlockOffset.DOWN);
/*     */     } 
/*     */ 
/*     */     
/*  81 */     if (unsafeSides.size() > 1) {
/*  82 */       info.setType(HoleType.NONE);
/*  83 */       return info;
/*     */     } 
/*     */ 
/*     */     
/*  87 */     double minX = Math.min(centreBlock.func_177958_n(), unsafePos.func_177958_n());
/*  88 */     double maxX = (Math.max(centreBlock.func_177958_n(), unsafePos.func_177958_n()) + 1);
/*  89 */     double minZ = Math.min(centreBlock.func_177952_p(), unsafePos.func_177952_p());
/*  90 */     double maxZ = (Math.max(centreBlock.func_177952_p(), unsafePos.func_177952_p()) + 1);
/*     */     
/*  92 */     info.setCentre(new AxisAlignedBB(minX, centreBlock.func_177956_o(), minZ, maxX, (centreBlock.func_177956_o() + 1), maxZ));
/*     */     
/*  94 */     if (info.getType() != HoleType.CUSTOM) {
/*  95 */       info.setType(HoleType.DOUBLE);
/*     */     }
/*  97 */     return info;
/*     */   }
/*     */   
/*     */   public static HashMap<BlockOffset, BlockSafety> getUnsafeSides(BlockPos pos) {
/* 101 */     HashMap<BlockOffset, BlockSafety> output = new HashMap<>();
/*     */ 
/*     */     
/* 104 */     BlockSafety temp = isBlockSafe(mc.field_71441_e.func_180495_p(BlockOffset.DOWN.offset(pos)).func_177230_c());
/* 105 */     if (temp != BlockSafety.UNBREAKABLE) {
/* 106 */       output.put(BlockOffset.DOWN, temp);
/*     */     }
/* 108 */     temp = isBlockSafe(mc.field_71441_e.func_180495_p(BlockOffset.NORTH.offset(pos)).func_177230_c());
/* 109 */     if (temp != BlockSafety.UNBREAKABLE) {
/* 110 */       output.put(BlockOffset.NORTH, temp);
/*     */     }
/* 112 */     temp = isBlockSafe(mc.field_71441_e.func_180495_p(BlockOffset.SOUTH.offset(pos)).func_177230_c());
/* 113 */     if (temp != BlockSafety.UNBREAKABLE) {
/* 114 */       output.put(BlockOffset.SOUTH, temp);
/*     */     }
/* 116 */     temp = isBlockSafe(mc.field_71441_e.func_180495_p(BlockOffset.EAST.offset(pos)).func_177230_c());
/* 117 */     if (temp != BlockSafety.UNBREAKABLE) {
/* 118 */       output.put(BlockOffset.EAST, temp);
/*     */     }
/* 120 */     temp = isBlockSafe(mc.field_71441_e.func_180495_p(BlockOffset.WEST.offset(pos)).func_177230_c());
/* 121 */     if (temp != BlockSafety.UNBREAKABLE) {
/* 122 */       output.put(BlockOffset.WEST, temp);
/*     */     }
/* 124 */     return output;
/*     */   }
/*     */   
/*     */   public enum BlockSafety {
/* 128 */     UNBREAKABLE,
/* 129 */     RESISTANT,
/* 130 */     BREAKABLE;
/*     */   }
/*     */   
/*     */   public enum HoleType {
/* 134 */     SINGLE,
/* 135 */     DOUBLE,
/* 136 */     CUSTOM,
/* 137 */     NONE;
/*     */   }
/*     */   
/*     */   public static class HoleInfo
/*     */   {
/*     */     private HoleUtil.HoleType type;
/*     */     private HoleUtil.BlockSafety safety;
/*     */     private AxisAlignedBB centre;
/*     */     
/*     */     public HoleInfo() {
/* 147 */       this(HoleUtil.BlockSafety.UNBREAKABLE, HoleUtil.HoleType.NONE);
/*     */     }
/*     */     
/*     */     public HoleInfo(HoleUtil.BlockSafety safety, HoleUtil.HoleType type) {
/* 151 */       this.type = type;
/* 152 */       this.safety = safety;
/*     */     }
/*     */     
/*     */     public void setType(HoleUtil.HoleType type) {
/* 156 */       this.type = type;
/*     */     }
/*     */     
/*     */     public void setSafety(HoleUtil.BlockSafety safety) {
/* 160 */       this.safety = safety;
/*     */     }
/*     */     
/*     */     public void setCentre(AxisAlignedBB centre) {
/* 164 */       this.centre = centre;
/*     */     }
/*     */     
/*     */     public HoleUtil.HoleType getType() {
/* 168 */       return this.type;
/*     */     }
/*     */     
/*     */     public HoleUtil.BlockSafety getSafety() {
/* 172 */       return this.safety;
/*     */     }
/*     */     
/*     */     public AxisAlignedBB getCentre() {
/* 176 */       return this.centre;
/*     */     }
/*     */   }
/*     */   
/*     */   public enum BlockOffset {
/* 181 */     DOWN(0, -1, 0),
/* 182 */     UP(0, 1, 0),
/* 183 */     NORTH(0, 0, -1),
/* 184 */     EAST(1, 0, 0),
/* 185 */     SOUTH(0, 0, 1),
/* 186 */     WEST(-1, 0, 0);
/*     */     
/*     */     private final int x;
/*     */     private final int y;
/*     */     private final int z;
/*     */     
/*     */     BlockOffset(int x, int y, int z) {
/* 193 */       this.x = x;
/* 194 */       this.y = y;
/* 195 */       this.z = z;
/*     */     }
/*     */     
/*     */     public BlockPos offset(BlockPos pos) {
/* 199 */       return pos.func_177982_a(this.x, this.y, this.z);
/*     */     }
/*     */     
/*     */     public BlockPos forward(BlockPos pos, int scale) {
/* 203 */       return pos.func_177982_a(this.x * scale, 0, this.z * scale);
/*     */     }
/*     */     
/*     */     public BlockPos backward(BlockPos pos, int scale) {
/* 207 */       return pos.func_177982_a(-this.x * scale, 0, -this.z * scale);
/*     */     }
/*     */     
/*     */     public BlockPos left(BlockPos pos, int scale) {
/* 211 */       return pos.func_177982_a(this.z * scale, 0, -this.x * scale);
/*     */     }
/*     */     
/*     */     public BlockPos right(BlockPos pos, int scale) {
/* 215 */       return pos.func_177982_a(-this.z * scale, 0, this.x * scale);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\ShitClient\HayBale-1.0.1-b8.jar!\me\luxtix\haybal\\util\HoleUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */