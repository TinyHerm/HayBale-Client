/*    */ package me.luxtix.haybale.util;
/*    */ 
/*    */ import java.util.Random;
/*    */ import net.minecraft.client.Minecraft;
/*    */ 
/*    */ public interface Globals
/*    */ {
/*  8 */   public static final Minecraft mc = Minecraft.func_71410_x();
/*  9 */   public static final Random random = new Random();
/*    */   public static final char SECTIONSIGN = '§';
/*    */   
/*    */   default boolean nullCheck() {
/* 13 */     return (mc.field_71439_g == null || mc.field_71441_e == null);
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\ShitClient\HayBale-1.0.1-b8.jar!\me\luxtix\haybal\\util\Globals.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */