/*     */ package me.luxtix.haybale.util;
/*     */ 
/*     */ import java.nio.FloatBuffer;
/*     */ import java.nio.IntBuffer;
/*     */ import org.lwjgl.BufferUtils;
/*     */ import org.lwjgl.util.glu.GLU;
/*     */ import org.lwjgl.util.vector.Matrix4f;
/*     */ 
/*     */ 
/*     */ public final class GLUProjection
/*     */ {
/*     */   private static GLUProjection instance;
/*  13 */   private final FloatBuffer coords = BufferUtils.createFloatBuffer(3);
/*     */   
/*     */   private IntBuffer viewport;
/*     */   
/*     */   private FloatBuffer modelview;
/*     */   
/*     */   private FloatBuffer projection;
/*     */   
/*     */   private Vector3D frustumPos;
/*     */   
/*     */   private Vector3D[] frustum;
/*     */   private Vector3D[] invFrustum;
/*     */   private Vector3D viewVec;
/*     */   private double displayWidth;
/*     */   private double displayHeight;
/*     */   private double widthScale;
/*     */   private double heightScale;
/*     */   private double bra;
/*     */   private double bla;
/*     */   private double tra;
/*     */   private double tla;
/*     */   private Line tb;
/*     */   private Line bb;
/*     */   private Line lb;
/*     */   private Line rb;
/*     */   private float fovY;
/*     */   private float fovX;
/*     */   private Vector3D lookVec;
/*     */   
/*     */   public static GLUProjection getInstance() {
/*  43 */     if (instance == null) {
/*  44 */       instance = new GLUProjection();
/*     */     }
/*  46 */     return instance;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateMatrices(IntBuffer viewport, FloatBuffer modelview, FloatBuffer projection, double widthScale, double heightScale) {
/*  52 */     this.viewport = viewport;
/*  53 */     this.modelview = modelview;
/*  54 */     this.projection = projection;
/*  55 */     this.widthScale = widthScale;
/*  56 */     this.heightScale = heightScale;
/*  57 */     float fov = (float)Math.toDegrees(Math.atan(1.0D / this.projection.get(5)) * 2.0D);
/*  58 */     this.displayWidth = this.viewport.get(2);
/*  59 */     this.displayHeight = this.viewport.get(3);
/*  60 */     this.fovX = (float)Math.toDegrees(2.0D * Math.atan(this.displayWidth / this.displayHeight * Math.tan(Math.toRadians(this.fovY) / 2.0D)));
/*  61 */     Vector3D lv = new Vector3D(this.modelview.get(0), this.modelview.get(1), this.modelview.get(2));
/*  62 */     Vector3D uv = new Vector3D(this.modelview.get(4), this.modelview.get(5), this.modelview.get(6));
/*  63 */     Vector3D fv = new Vector3D(this.modelview.get(8), this.modelview.get(9), this.modelview.get(10));
/*  64 */     Vector3D nuv = new Vector3D(0.0D, 1.0D, 0.0D);
/*  65 */     Vector3D nlv = new Vector3D(1.0D, 0.0D, 0.0D);
/*  66 */     double yaw = Math.toDegrees(Math.atan2(nlv.cross(lv).length(), nlv.dot(lv))) + 180.0D;
/*  67 */     if (fv.x < 0.0D) {
/*  68 */       yaw = 360.0D - yaw;
/*     */     }
/*     */     
/*  71 */     double pitch = ((-fv.y > 0.0D && yaw >= 90.0D && yaw < 270.0D) || (fv.y > 0.0D && (yaw < 90.0D || yaw >= 270.0D))) ? Math.toDegrees(Math.atan2(nuv.cross(uv).length(), nuv.dot(uv))) : -Math.toDegrees(Math.atan2(nuv.cross(uv).length(), nuv.dot(uv)));
/*  72 */     this.lookVec = getRotationVector(yaw, pitch);
/*  73 */     Matrix4f modelviewMatrix = new Matrix4f();
/*  74 */     modelviewMatrix.load(this.modelview.asReadOnlyBuffer());
/*  75 */     modelviewMatrix.invert();
/*  76 */     this.frustumPos = new Vector3D(modelviewMatrix.m30, modelviewMatrix.m31, modelviewMatrix.m32);
/*  77 */     this.frustum = getFrustum(this.frustumPos.x, this.frustumPos.y, this.frustumPos.z, yaw, pitch, fov, 1.0D, this.displayWidth / this.displayHeight);
/*  78 */     this.invFrustum = getFrustum(this.frustumPos.x, this.frustumPos.y, this.frustumPos.z, yaw - 180.0D, -pitch, fov, 1.0D, this.displayWidth / this.displayHeight);
/*  79 */     this.viewVec = getRotationVector(yaw, pitch).normalized();
/*  80 */     this.bra = Math.toDegrees(Math.acos(this.displayHeight * heightScale / Math.sqrt(this.displayWidth * widthScale * this.displayWidth * widthScale + this.displayHeight * heightScale * this.displayHeight * heightScale)));
/*  81 */     this.bla = 360.0D - this.bra;
/*  82 */     this.tra = this.bla - 180.0D;
/*  83 */     this.tla = this.bra + 180.0D;
/*  84 */     this.rb = new Line(this.displayWidth * this.widthScale, 0.0D, 0.0D, 0.0D, 1.0D, 0.0D);
/*  85 */     this.tb = new Line(0.0D, 0.0D, 0.0D, 1.0D, 0.0D, 0.0D);
/*  86 */     this.lb = new Line(0.0D, 0.0D, 0.0D, 0.0D, 1.0D, 0.0D);
/*  87 */     this.bb = new Line(0.0D, this.displayHeight * this.heightScale, 0.0D, 1.0D, 0.0D, 0.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Projection project(double x, double y, double z, ClampMode clampModeOutside, boolean extrudeInverted) {
/*  97 */     if (this.viewport == null || this.modelview == null || this.projection == null)
/*  98 */       return new Projection(0.0D, 0.0D, Projection.Type.FAIL); 
/*  99 */     Vector3D posVec = new Vector3D(x, y, z);
/* 100 */     boolean[] frustum = doFrustumCheck(this.frustum, this.frustumPos, x, y, z);
/* 101 */     boolean outsideFrustum = (frustum[0] || frustum[1] || frustum[2] || frustum[3]);
/* 102 */     if (outsideFrustum) {
/*     */       
/* 104 */       boolean opposite = (posVec.sub(this.frustumPos).dot(this.viewVec) <= 0.0D);
/* 105 */       boolean[] invFrustum = doFrustumCheck(this.invFrustum, this.frustumPos, x, y, z);
/* 106 */       boolean outsideInvertedFrustum = (invFrustum[0] || invFrustum[1] || invFrustum[2] || invFrustum[3]);
/* 107 */       if ((extrudeInverted && !outsideInvertedFrustum) || (outsideInvertedFrustum && clampModeOutside != ClampMode.NONE)) {
/* 108 */         if ((extrudeInverted && !outsideInvertedFrustum) || clampModeOutside == ClampMode.DIRECT) {
/*     */ 
/*     */           
/* 111 */           if (!GLU.gluProject((float)x, (float)y, (float)z, this.modelview, this.projection, this.viewport, this.coords))
/* 112 */             return new Projection(0.0D, 0.0D, Projection.Type.FAIL); 
/* 113 */           if (opposite) {
/* 114 */             vecX = this.displayWidth * this.widthScale - this.coords.get(0) * this.widthScale - this.displayWidth * this.widthScale / 2.0D;
/* 115 */             vecY = this.displayHeight * this.heightScale - (this.displayHeight - this.coords.get(1)) * this.heightScale - this.displayHeight * this.heightScale / 2.0D;
/*     */           } else {
/* 117 */             vecX = this.coords.get(0) * this.widthScale - this.displayWidth * this.widthScale / 2.0D;
/* 118 */             vecY = (this.displayHeight - this.coords.get(1)) * this.heightScale - this.displayHeight * this.heightScale / 2.0D;
/*     */           } 
/* 120 */           Vector3D vec = (new Vector3D(vecX, vecY, 0.0D)).snormalize();
/* 121 */           double vecX = vec.x;
/* 122 */           double vecY = vec.y;
/* 123 */           Line vectorLine = new Line(this.displayWidth * this.widthScale / 2.0D, this.displayHeight * this.heightScale / 2.0D, 0.0D, vecX, vecY, 0.0D);
/* 124 */           double angle = Math.toDegrees(Math.acos(vec.y / Math.sqrt(vec.x * vec.x + vec.y * vec.y)));
/* 125 */           if (vecX < 0.0D) {
/* 126 */             angle = 360.0D - angle;
/*     */           }
/* 128 */           new Vector3D(0.0D, 0.0D, 0.0D);
/*     */           
/* 130 */           Vector3D intersect = (angle >= this.bra && angle < this.tra) ? this.rb.intersect(vectorLine) : ((angle >= this.tra && angle < this.tla) ? this.tb.intersect(vectorLine) : ((angle >= this.tla && angle < this.bla) ? this.lb.intersect(vectorLine) : this.bb.intersect(vectorLine)));
/* 131 */           return new Projection(intersect.x, intersect.y, outsideInvertedFrustum ? Projection.Type.OUTSIDE : Projection.Type.INVERTED);
/*     */         } 
/* 133 */         if (clampModeOutside != ClampMode.ORTHOGONAL)
/* 134 */           return new Projection(0.0D, 0.0D, Projection.Type.FAIL); 
/* 135 */         if (!GLU.gluProject((float)x, (float)y, (float)z, this.modelview, this.projection, this.viewport, this.coords))
/* 136 */           return new Projection(0.0D, 0.0D, Projection.Type.FAIL); 
/* 137 */         double d3 = this.coords.get(0) * this.widthScale;
/* 138 */         double d4 = (this.displayHeight - this.coords.get(1)) * this.heightScale;
/* 139 */         if (opposite) {
/* 140 */           d3 = this.displayWidth * this.widthScale - d3;
/* 141 */           d4 = this.displayHeight * this.heightScale - d4;
/*     */         } 
/* 143 */         if (d3 < 0.0D) {
/* 144 */           d3 = 0.0D;
/* 145 */         } else if (d3 > this.displayWidth * this.widthScale) {
/* 146 */           d3 = this.displayWidth * this.widthScale;
/*     */         } 
/* 148 */         if (d4 < 0.0D) {
/* 149 */           d4 = 0.0D;
/* 150 */           return new Projection(d3, d4, Projection.Type.OUTSIDE);
/*     */         } 
/* 152 */         if (d4 <= this.displayHeight * this.heightScale)
/* 153 */           return new Projection(d3, d4, Projection.Type.OUTSIDE); 
/* 154 */         d4 = this.displayHeight * this.heightScale;
/*     */         
/* 156 */         return new Projection(d3, d4, Projection.Type.OUTSIDE);
/*     */       } 
/* 158 */       if (!GLU.gluProject((float)x, (float)y, (float)z, this.modelview, this.projection, this.viewport, this.coords))
/* 159 */         return new Projection(0.0D, 0.0D, Projection.Type.FAIL); 
/* 160 */       double d1 = this.coords.get(0) * this.widthScale;
/* 161 */       double d2 = (this.displayHeight - this.coords.get(1)) * this.heightScale;
/* 162 */       if (!opposite)
/* 163 */         return new Projection(d1, d2, outsideInvertedFrustum ? Projection.Type.OUTSIDE : Projection.Type.INVERTED); 
/* 164 */       d1 = this.displayWidth * this.widthScale - d1;
/* 165 */       d2 = this.displayHeight * this.heightScale - d2;
/* 166 */       return new Projection(d1, d2, outsideInvertedFrustum ? Projection.Type.OUTSIDE : Projection.Type.INVERTED);
/*     */     } 
/* 168 */     if (!GLU.gluProject((float)x, (float)y, (float)z, this.modelview, this.projection, this.viewport, this.coords))
/* 169 */       return new Projection(0.0D, 0.0D, Projection.Type.FAIL); 
/* 170 */     double guiX = this.coords.get(0) * this.widthScale;
/* 171 */     double guiY = (this.displayHeight - this.coords.get(1)) * this.heightScale;
/* 172 */     return new Projection(guiX, guiY, Projection.Type.INSIDE);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean[] doFrustumCheck(Vector3D[] frustumCorners, Vector3D frustumPos, double x, double y, double z) {
/* 177 */     Vector3D point = new Vector3D(x, y, z);
/* 178 */     boolean c1 = crossPlane(new Vector3D[] { frustumPos, frustumCorners[3], frustumCorners[0] }, point);
/* 179 */     boolean c2 = crossPlane(new Vector3D[] { frustumPos, frustumCorners[0], frustumCorners[1] }, point);
/* 180 */     boolean c3 = crossPlane(new Vector3D[] { frustumPos, frustumCorners[1], frustumCorners[2] }, point);
/* 181 */     boolean c4 = crossPlane(new Vector3D[] { frustumPos, frustumCorners[2], frustumCorners[3] }, point);
/* 182 */     return new boolean[] { c1, c2, c3, c4 };
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean crossPlane(Vector3D[] plane, Vector3D point) {
/* 187 */     Vector3D z = new Vector3D(0.0D, 0.0D, 0.0D);
/* 188 */     Vector3D e0 = plane[1].sub(plane[0]);
/* 189 */     Vector3D e1 = plane[2].sub(plane[0]);
/* 190 */     Vector3D normal = e0.cross(e1).snormalize();
/* 191 */     double D = z.sub(normal).dot(plane[2]);
/* 192 */     double dist = normal.dot(point) + D;
/* 193 */     return (dist >= 0.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   public Vector3D[] getFrustum(double x, double y, double z, double rotationYaw, double rotationPitch, double fov, double farDistance, double aspectRatio) {
/* 198 */     double hFar = 2.0D * Math.tan(Math.toRadians(fov / 2.0D)) * farDistance;
/* 199 */     double wFar = hFar * aspectRatio;
/* 200 */     Vector3D view = getRotationVector(rotationYaw, rotationPitch).snormalize();
/* 201 */     Vector3D up = getRotationVector(rotationYaw, rotationPitch - 90.0D).snormalize();
/* 202 */     Vector3D right = getRotationVector(rotationYaw + 90.0D, 0.0D).snormalize();
/* 203 */     Vector3D camPos = new Vector3D(x, y, z);
/* 204 */     Vector3D view_camPos_product = view.add(camPos);
/* 205 */     Vector3D fc = new Vector3D(view_camPos_product.x * farDistance, view_camPos_product.y * farDistance, view_camPos_product.z * farDistance);
/* 206 */     Vector3D topLeftfrustum = new Vector3D(fc.x + up.x * hFar / 2.0D - right.x * wFar / 2.0D, fc.y + up.y * hFar / 2.0D - right.y * wFar / 2.0D, fc.z + up.z * hFar / 2.0D - right.z * wFar / 2.0D);
/* 207 */     Vector3D downLeftfrustum = new Vector3D(fc.x - up.x * hFar / 2.0D - right.x * wFar / 2.0D, fc.y - up.y * hFar / 2.0D - right.y * wFar / 2.0D, fc.z - up.z * hFar / 2.0D - right.z * wFar / 2.0D);
/* 208 */     Vector3D topRightfrustum = new Vector3D(fc.x + up.x * hFar / 2.0D + right.x * wFar / 2.0D, fc.y + up.y * hFar / 2.0D + right.y * wFar / 2.0D, fc.z + up.z * hFar / 2.0D + right.z * wFar / 2.0D);
/* 209 */     Vector3D downRightfrustum = new Vector3D(fc.x - up.x * hFar / 2.0D + right.x * wFar / 2.0D, fc.y - up.y * hFar / 2.0D + right.y * wFar / 2.0D, fc.z - up.z * hFar / 2.0D + right.z * wFar / 2.0D);
/* 210 */     return new Vector3D[] { topLeftfrustum, downLeftfrustum, downRightfrustum, topRightfrustum };
/*     */   }
/*     */ 
/*     */   
/*     */   public Vector3D[] getFrustum() {
/* 215 */     return this.frustum;
/*     */   }
/*     */ 
/*     */   
/*     */   public float getFovX() {
/* 220 */     return this.fovX;
/*     */   }
/*     */ 
/*     */   
/*     */   public float getFovY() {
/* 225 */     return this.fovY;
/*     */   }
/*     */ 
/*     */   
/*     */   public Vector3D getLookVector() {
/* 230 */     return this.lookVec;
/*     */   }
/*     */ 
/*     */   
/*     */   public Vector3D getRotationVector(double rotYaw, double rotPitch) {
/* 235 */     double c = Math.cos(-rotYaw * 0.01745329238474369D - Math.PI);
/* 236 */     double s = Math.sin(-rotYaw * 0.01745329238474369D - Math.PI);
/* 237 */     double nc = -Math.cos(-rotPitch * 0.01745329238474369D);
/* 238 */     double ns = Math.sin(-rotPitch * 0.01745329238474369D);
/* 239 */     return new Vector3D(s * nc, ns, c * nc);
/*     */   }
/*     */   
/*     */   public enum ClampMode
/*     */   {
/* 244 */     ORTHOGONAL,
/* 245 */     DIRECT,
/* 246 */     NONE;
/*     */   }
/*     */ 
/*     */   
/*     */   public static class Projection
/*     */   {
/*     */     private final double x;
/*     */     
/*     */     private final double y;
/*     */     private final Type t;
/*     */     
/*     */     public Projection(double x, double y, Type t) {
/* 258 */       this.x = x;
/* 259 */       this.y = y;
/* 260 */       this.t = t;
/*     */     }
/*     */ 
/*     */     
/*     */     public double getX() {
/* 265 */       return this.x;
/*     */     }
/*     */ 
/*     */     
/*     */     public double getY() {
/* 270 */       return this.y;
/*     */     }
/*     */ 
/*     */     
/*     */     public Type getType() {
/* 275 */       return this.t;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isType(Type type) {
/* 280 */       return (this.t == type);
/*     */     }
/*     */     
/*     */     public enum Type
/*     */     {
/* 285 */       INSIDE,
/* 286 */       OUTSIDE,
/* 287 */       INVERTED,
/* 288 */       FAIL; } } public enum Type { INSIDE, OUTSIDE, INVERTED, FAIL; }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Vector3D
/*     */   {
/*     */     public double x;
/*     */     
/*     */     public double y;
/*     */     
/*     */     public double z;
/*     */     
/*     */     public Vector3D(double x, double y, double z) {
/* 301 */       this.x = x;
/* 302 */       this.y = y;
/* 303 */       this.z = z;
/*     */     }
/*     */ 
/*     */     
/*     */     public Vector3D add(Vector3D v) {
/* 308 */       return new Vector3D(this.x + v.x, this.y + v.y, this.z + v.z);
/*     */     }
/*     */ 
/*     */     
/*     */     public Vector3D add(double x, double y, double z) {
/* 313 */       return new Vector3D(this.x + x, this.y + y, this.z + z);
/*     */     }
/*     */ 
/*     */     
/*     */     public Vector3D sub(Vector3D v) {
/* 318 */       return new Vector3D(this.x - v.x, this.y - v.y, this.z - v.z);
/*     */     }
/*     */ 
/*     */     
/*     */     public Vector3D sub(double x, double y, double z) {
/* 323 */       return new Vector3D(this.x - x, this.y - y, this.z - z);
/*     */     }
/*     */ 
/*     */     
/*     */     public Vector3D normalized() {
/* 328 */       double len = Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z);
/* 329 */       return new Vector3D(this.x / len, this.y / len, this.z / len);
/*     */     }
/*     */ 
/*     */     
/*     */     public double dot(Vector3D v) {
/* 334 */       return this.x * v.x + this.y * v.y + this.z * v.z;
/*     */     }
/*     */ 
/*     */     
/*     */     public Vector3D cross(Vector3D v) {
/* 339 */       return new Vector3D(this.y * v.z - this.z * v.y, this.z * v.x - this.x * v.z, this.x * v.y - this.y * v.x);
/*     */     }
/*     */ 
/*     */     
/*     */     public Vector3D mul(double m) {
/* 344 */       return new Vector3D(this.x * m, this.y * m, this.z * m);
/*     */     }
/*     */ 
/*     */     
/*     */     public Vector3D div(double d) {
/* 349 */       return new Vector3D(this.x / d, this.y / d, this.z / d);
/*     */     }
/*     */ 
/*     */     
/*     */     public double length() {
/* 354 */       return Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z);
/*     */     }
/*     */ 
/*     */     
/*     */     public Vector3D sadd(Vector3D v) {
/* 359 */       this.x += v.x;
/* 360 */       this.y += v.y;
/* 361 */       this.z += v.z;
/* 362 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Vector3D sadd(double x, double y, double z) {
/* 367 */       this.x += x;
/* 368 */       this.y += y;
/* 369 */       this.z += z;
/* 370 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Vector3D ssub(Vector3D v) {
/* 375 */       this.x -= v.x;
/* 376 */       this.y -= v.y;
/* 377 */       this.z -= v.z;
/* 378 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Vector3D ssub(double x, double y, double z) {
/* 383 */       this.x -= x;
/* 384 */       this.y -= y;
/* 385 */       this.z -= z;
/* 386 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Vector3D snormalize() {
/* 391 */       double len = Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z);
/* 392 */       this.x /= len;
/* 393 */       this.y /= len;
/* 394 */       this.z /= len;
/* 395 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Vector3D scross(Vector3D v) {
/* 400 */       this.x = this.y * v.z - this.z * v.y;
/* 401 */       this.y = this.z * v.x - this.x * v.z;
/* 402 */       this.z = this.x * v.y - this.y * v.x;
/* 403 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Vector3D smul(double m) {
/* 408 */       this.x *= m;
/* 409 */       this.y *= m;
/* 410 */       this.z *= m;
/* 411 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Vector3D sdiv(double d) {
/* 416 */       this.x /= d;
/* 417 */       this.y /= d;
/* 418 */       this.z /= d;
/* 419 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 424 */       return "(X: " + this.x + " Y: " + this.y + " Z: " + this.z + ")";
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Line
/*     */   {
/* 430 */     public GLUProjection.Vector3D sourcePoint = new GLUProjection.Vector3D(0.0D, 0.0D, 0.0D);
/* 431 */     public GLUProjection.Vector3D direction = new GLUProjection.Vector3D(0.0D, 0.0D, 0.0D);
/*     */ 
/*     */     
/*     */     public Line(double sx, double sy, double sz, double dx, double dy, double dz) {
/* 435 */       this.sourcePoint.x = sx;
/* 436 */       this.sourcePoint.y = sy;
/* 437 */       this.sourcePoint.z = sz;
/* 438 */       this.direction.x = dx;
/* 439 */       this.direction.y = dy;
/* 440 */       this.direction.z = dz;
/*     */     }
/*     */ 
/*     */     
/*     */     public GLUProjection.Vector3D intersect(Line line) {
/* 445 */       double a = this.sourcePoint.x;
/* 446 */       double b = this.direction.x;
/* 447 */       double c = line.sourcePoint.x;
/* 448 */       double d = line.direction.x;
/* 449 */       double e = this.sourcePoint.y;
/* 450 */       double f = this.direction.y;
/* 451 */       double g = line.sourcePoint.y;
/* 452 */       double h = line.direction.y;
/* 453 */       double te = -(a * h - c * h - d * (e - g));
/* 454 */       double be = b * h - d * f;
/* 455 */       if (be == 0.0D) {
/* 456 */         return intersectXZ(line);
/*     */       }
/* 458 */       double t = te / be;
/* 459 */       GLUProjection.Vector3D result = new GLUProjection.Vector3D(0.0D, 0.0D, 0.0D);
/* 460 */       this.sourcePoint.x += this.direction.x * t;
/* 461 */       this.sourcePoint.y += this.direction.y * t;
/* 462 */       this.sourcePoint.z += this.direction.z * t;
/* 463 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     private GLUProjection.Vector3D intersectXZ(Line line) {
/* 468 */       double a = this.sourcePoint.x;
/* 469 */       double b = this.direction.x;
/* 470 */       double c = line.sourcePoint.x;
/* 471 */       double d = line.direction.x;
/* 472 */       double e = this.sourcePoint.z;
/* 473 */       double f = this.direction.z;
/* 474 */       double g = line.sourcePoint.z;
/* 475 */       double h = line.direction.z;
/* 476 */       double te = -(a * h - c * h - d * (e - g));
/* 477 */       double be = b * h - d * f;
/* 478 */       if (be == 0.0D) {
/* 479 */         return intersectYZ(line);
/*     */       }
/* 481 */       double t = te / be;
/* 482 */       GLUProjection.Vector3D result = new GLUProjection.Vector3D(0.0D, 0.0D, 0.0D);
/* 483 */       this.sourcePoint.x += this.direction.x * t;
/* 484 */       this.sourcePoint.y += this.direction.y * t;
/* 485 */       this.sourcePoint.z += this.direction.z * t;
/* 486 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     private GLUProjection.Vector3D intersectYZ(Line line) {
/* 491 */       double a = this.sourcePoint.y;
/* 492 */       double b = this.direction.y;
/* 493 */       double c = line.sourcePoint.y;
/* 494 */       double d = line.direction.y;
/* 495 */       double e = this.sourcePoint.z;
/* 496 */       double f = this.direction.z;
/* 497 */       double g = line.sourcePoint.z;
/* 498 */       double h = line.direction.z;
/* 499 */       double te = -(a * h - c * h - d * (e - g));
/* 500 */       double be = b * h - d * f;
/* 501 */       if (be == 0.0D) {
/* 502 */         return null;
/*     */       }
/* 504 */       double t = te / be;
/* 505 */       GLUProjection.Vector3D result = new GLUProjection.Vector3D(0.0D, 0.0D, 0.0D);
/* 506 */       this.sourcePoint.x += this.direction.x * t;
/* 507 */       this.sourcePoint.y += this.direction.y * t;
/* 508 */       this.sourcePoint.z += this.direction.z * t;
/* 509 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     public GLUProjection.Vector3D intersectPlane(GLUProjection.Vector3D pointOnPlane, GLUProjection.Vector3D planeNormal) {
/* 514 */       GLUProjection.Vector3D result = new GLUProjection.Vector3D(this.sourcePoint.x, this.sourcePoint.y, this.sourcePoint.z);
/* 515 */       double d = pointOnPlane.sub(this.sourcePoint).dot(planeNormal) / this.direction.dot(planeNormal);
/* 516 */       result.sadd(this.direction.mul(d));
/* 517 */       if (this.direction.dot(planeNormal) == 0.0D) {
/* 518 */         return null;
/*     */       }
/* 520 */       return result;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\ShitClient\HayBale-1.0.1-b8.jar!\me\luxtix\haybal\\util\GLUProjection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */