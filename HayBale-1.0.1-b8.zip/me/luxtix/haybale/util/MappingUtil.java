/*    */ package me.luxtix.haybale.util;
/*    */ 
/*    */ import net.minecraft.client.Minecraft;
/*    */ 
/*    */ public class MappingUtil {
/*  6 */   public static final String tickLength = isObfuscated() ? "field_194149_e" : "tickLength";
/*    */   
/*  8 */   public static final String timer = isObfuscated() ? "field_71428_T" : "timer";
/*    */   
/* 10 */   public static final String placedBlockDirection = isObfuscated() ? "field_149579_d" : "placedBlockDirection";
/*    */   
/* 12 */   public static final String playerPosLookYaw = isObfuscated() ? "field_148936_d" : "yaw";
/*    */   
/* 14 */   public static final String playerPosLookPitch = isObfuscated() ? "field_148937_e" : "pitch";
/*    */   
/* 16 */   public static final String isInWeb = isObfuscated() ? "field_70134_J" : "isInWeb";
/*    */   
/* 18 */   public static final String cPacketPlayerYaw = isObfuscated() ? "field_149476_e" : "yaw";
/*    */   
/* 20 */   public static final String cPacketPlayerPitch = isObfuscated() ? "field_149473_f" : "pitch";
/*    */   
/* 22 */   public static final String renderManagerRenderPosX = isObfuscated() ? "field_78725_b" : "renderPosX";
/*    */   
/* 24 */   public static final String renderManagerRenderPosY = isObfuscated() ? "field_78726_c" : "renderPosY";
/*    */   
/* 26 */   public static final String renderManagerRenderPosZ = isObfuscated() ? "field_78723_d" : "renderPosZ";
/*    */   
/* 28 */   public static final String rightClickDelayTimer = isObfuscated() ? "field_71467_ac" : "rightClickDelayTimer";
/*    */   
/* 30 */   public static final String sPacketEntityVelocityMotionX = isObfuscated() ? "field_70159_w" : "motionX";
/*    */   
/* 32 */   public static final String sPacketEntityVelocityMotionY = isObfuscated() ? "field_70181_x" : "motionY";
/*    */   
/* 34 */   public static final String sPacketEntityVelocityMotionZ = isObfuscated() ? "field_70179_y" : "motionZ";
/*    */   
/*    */   public static boolean isObfuscated() {
/*    */     try {
/* 38 */       return (Minecraft.class.getDeclaredField("instance") == null);
/* 39 */     } catch (Exception var1) {
/* 40 */       return true;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\ShitClient\HayBale-1.0.1-b8.jar!\me\luxtix\haybal\\util\MappingUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */