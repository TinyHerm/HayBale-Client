/*   */ package me.luxtix.haybale.util;
/*   */ 
/*   */ import net.minecraft.client.Minecraft;
/*   */ 
/*   */ public interface Util {
/* 6 */   public static final Minecraft mc = Minecraft.func_71410_x();
/*   */ }


/* Location:              C:\Users\Administrator\Desktop\ShitClient\HayBale-1.0.1-b8.jar!\me\luxtix\haybal\\util\Util.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */