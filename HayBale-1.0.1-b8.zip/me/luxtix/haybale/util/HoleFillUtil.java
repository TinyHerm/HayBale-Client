/*     */ package me.luxtix.haybale.util;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.multiplayer.PlayerControllerMP;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketPlayer;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.util.math.Vec3i;
/*     */ import net.minecraftforge.fml.common.FMLCommonHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HoleFillUtil
/*     */ {
/*     */   public static void placeBlockScaffold(BlockPos pos) {
/*  30 */     Vec3d eyesPos = new Vec3d(player.field_70165_t, player.field_70163_u + player.func_70047_e(), player.field_70161_v);
/*  31 */     for (EnumFacing side : EnumFacing.values()) {
/*  32 */       BlockPos neighbor = pos.func_177972_a(side);
/*  33 */       EnumFacing side2 = side.func_176734_d();
/*  34 */       if (canBeClicked(neighbor)) {
/*  35 */         Vec3d hitVec = (new Vec3d((Vec3i)neighbor)).func_72441_c(0.5D, 0.5D, 0.5D).func_178787_e((new Vec3d(side2.func_176730_m())).func_186678_a(0.5D));
/*  36 */         if (eyesPos.func_72436_e(hitVec) <= 18.0625D) {
/*  37 */           faceVectorPacketInstant(hitVec);
/*  38 */           processRightClickBlock(neighbor, side2, hitVec);
/*  39 */           mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
/*  40 */           mc.field_71467_ac = 4;
/*     */           return;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static float[] getLegitRotations(Vec3d vec) {
/*  48 */     Vec3d eyesPos = getEyesPos();
/*  49 */     double diffX = vec.field_72450_a - eyesPos.field_72450_a;
/*  50 */     double diffY = vec.field_72448_b - eyesPos.field_72448_b;
/*  51 */     double diffZ = vec.field_72449_c - eyesPos.field_72449_c;
/*  52 */     double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
/*  53 */     float yaw = (float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0F;
/*  54 */     float pitch = (float)-Math.toDegrees(Math.atan2(diffY, diffXZ));
/*  55 */     return new float[] { mc.field_71439_g.field_70177_z + MathHelper.func_76142_g(yaw - mc.field_71439_g.field_70177_z), mc.field_71439_g.field_70125_A + MathHelper.func_76142_g(pitch - mc.field_71439_g.field_70125_A) };
/*     */   }
/*     */   
/*     */   private static Vec3d getEyesPos() {
/*  59 */     return new Vec3d(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + mc.field_71439_g.func_70047_e(), mc.field_71439_g.field_70161_v);
/*     */   }
/*     */   
/*     */   public static void faceVectorPacketInstant(Vec3d vec) {
/*  63 */     float[] rotations = getLegitRotations(vec);
/*  64 */     mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Rotation(rotations[0], rotations[1], mc.field_71439_g.field_70122_E));
/*     */   }
/*     */   
/*     */   static void processRightClickBlock(BlockPos pos, EnumFacing side, Vec3d hitVec) {
/*  68 */     getPlayerController().func_187099_a(mc.field_71439_g, mc.field_71441_e, pos, side, hitVec, EnumHand.MAIN_HAND);
/*     */   }
/*     */   
/*     */   public static boolean canBeClicked(BlockPos pos) {
/*  72 */     return getBlock(pos).func_176209_a(getState(pos), false);
/*     */   }
/*     */   
/*     */   private static Block getBlock(BlockPos pos) {
/*  76 */     return getState(pos).func_177230_c();
/*     */   }
/*     */   
/*     */   private static PlayerControllerMP getPlayerController() {
/*  80 */     return (Minecraft.func_71410_x()).field_71442_b;
/*     */   }
/*     */   
/*     */   private static IBlockState getState(BlockPos pos) {
/*  84 */     return mc.field_71441_e.func_180495_p(pos);
/*     */   }
/*     */   
/*     */   public static boolean checkForNeighbours(BlockPos blockPos) {
/*  88 */     if (!hasNeighbour(blockPos)) {
/*  89 */       for (EnumFacing side : EnumFacing.values()) {
/*  90 */         BlockPos neighbour = blockPos.func_177972_a(side);
/*  91 */         if (hasNeighbour(neighbour)) {
/*  92 */           return true;
/*     */         }
/*     */       } 
/*  95 */       return false;
/*     */     } 
/*  97 */     return true;
/*     */   }
/*     */   
/*     */   public static EnumFacing getPlaceableSide(BlockPos pos) {
/* 101 */     for (EnumFacing side : EnumFacing.values()) {
/* 102 */       BlockPos neighbour = pos.func_177972_a(side);
/* 103 */       if (mc.field_71441_e.func_180495_p(neighbour).func_177230_c().func_176209_a(mc.field_71441_e.func_180495_p(neighbour), false)) {
/* 104 */         IBlockState blockState = mc.field_71441_e.func_180495_p(neighbour);
/* 105 */         if (!blockState.func_185904_a().func_76222_j()) {
/* 106 */           return side;
/*     */         }
/*     */       } 
/*     */     } 
/* 110 */     return null;
/*     */   }
/*     */   
/*     */   public static boolean hasNeighbour(BlockPos blockPos) {
/* 114 */     for (EnumFacing side : EnumFacing.values()) {
/* 115 */       BlockPos neighbour = blockPos.func_177972_a(side);
/* 116 */       if (!mc.field_71441_e.func_180495_p(neighbour).func_185904_a().func_76222_j()) {
/* 117 */         return true;
/*     */       }
/*     */     } 
/* 120 */     return false;
/*     */   }
/*     */ 
/*     */   
/* 124 */   public static final List<Block> blackList = Arrays.asList(new Block[] { Blocks.field_150477_bB, (Block)Blocks.field_150486_ae, Blocks.field_150447_bR, Blocks.field_150462_ai, Blocks.field_150467_bQ, Blocks.field_150382_bo, (Block)Blocks.field_150438_bZ, Blocks.field_150409_cd, Blocks.field_150367_z, Blocks.field_150415_aT, Blocks.field_150381_bn });
/* 125 */   public static final List<Block> shulkerList = Arrays.asList(new Block[] { Blocks.field_190977_dl, Blocks.field_190978_dm, Blocks.field_190979_dn, Blocks.field_190980_do, Blocks.field_190981_dp, Blocks.field_190982_dq, Blocks.field_190983_dr, Blocks.field_190984_ds, Blocks.field_190985_dt, Blocks.field_190986_du, Blocks.field_190987_dv, Blocks.field_190988_dw, Blocks.field_190989_dx, Blocks.field_190990_dy, Blocks.field_190991_dz, Blocks.field_190975_dA });
/* 126 */   private static final Minecraft mc = Minecraft.func_71410_x();
/* 127 */   private static Entity player = (Entity)mc.field_71439_g;
/* 128 */   public static FMLCommonHandler fmlHandler = FMLCommonHandler.instance();
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\ShitClient\HayBale-1.0.1-b8.jar!\me\luxtix\haybal\\util\HoleFillUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */