/*     */ package me.luxtix.haybale.util;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import me.luxtix.haybale.Minecraftable;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemBlock;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketEntityAction;
/*     */ import net.minecraft.network.play.client.CPacketHeldItemChange;
/*     */ import net.minecraft.network.play.client.CPacketPlayer;
/*     */ import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.util.math.Vec3i;
/*     */ 
/*     */ public class ItemUtil {
/*  28 */   public static final Minecraft mc = Minecraft.func_71410_x();
/*     */   
/*     */   public static boolean placeBlock(BlockPos pos, EnumHand hand, boolean rotate, boolean packet, boolean isSneaking) {
/*  31 */     boolean sneaking = false;
/*  32 */     EnumFacing side = getFirstFacing(pos);
/*  33 */     if (side == null)
/*  34 */       return isSneaking; 
/*  35 */     BlockPos neighbour = pos.func_177972_a(side);
/*  36 */     EnumFacing opposite = side.func_176734_d();
/*  37 */     Vec3d hitVec = (new Vec3d((Vec3i)neighbour)).func_72441_c(0.5D, 0.5D, 0.5D).func_178787_e((new Vec3d(opposite.func_176730_m())).func_186678_a(0.5D));
/*  38 */     Block neighbourBlock = mc.field_71441_e.func_180495_p(neighbour).func_177230_c();
/*  39 */     if (!mc.field_71439_g.func_70093_af()) {
/*  40 */       mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketEntityAction((Entity)mc.field_71439_g, CPacketEntityAction.Action.START_SNEAKING));
/*  41 */       mc.field_71439_g.func_70095_a(true);
/*  42 */       sneaking = true;
/*     */     } 
/*  44 */     if (rotate)
/*  45 */       faceVector(hitVec, true); 
/*  46 */     rightClickBlock(neighbour, hitVec, hand, opposite, packet);
/*  47 */     mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
/*  48 */     mc.field_71467_ac = 4;
/*  49 */     return (sneaking || isSneaking);
/*     */   }
/*     */   
/*     */   public static List<EnumFacing> getPossibleSides(BlockPos pos) {
/*  53 */     List<EnumFacing> facings = new ArrayList<>();
/*  54 */     for (EnumFacing side : EnumFacing.values()) {
/*  55 */       BlockPos neighbour = pos.func_177972_a(side);
/*  56 */       if (mc.field_71441_e.func_180495_p(neighbour).func_177230_c().func_176209_a(mc.field_71441_e.func_180495_p(neighbour), false)) {
/*  57 */         IBlockState blockState = mc.field_71441_e.func_180495_p(neighbour);
/*  58 */         if (!blockState.func_185904_a().func_76222_j())
/*  59 */           facings.add(side); 
/*     */       } 
/*     */     } 
/*  62 */     return facings;
/*     */   }
/*     */   
/*     */   public static EnumFacing getFirstFacing(BlockPos pos) {
/*  66 */     Iterator<EnumFacing> iterator = getPossibleSides(pos).iterator();
/*  67 */     if (iterator.hasNext()) {
/*  68 */       EnumFacing facing = iterator.next();
/*  69 */       return facing;
/*     */     } 
/*  71 */     return null;
/*     */   }
/*     */   
/*     */   public static Vec3d getEyesPos() {
/*  75 */     return new Vec3d(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + mc.field_71439_g.func_70047_e(), mc.field_71439_g.field_70161_v);
/*     */   }
/*     */   
/*     */   public static float[] getLegitRotations(Vec3d vec) {
/*  79 */     Vec3d eyesPos = getEyesPos();
/*  80 */     double diffX = vec.field_72450_a - eyesPos.field_72450_a;
/*  81 */     double diffY = vec.field_72448_b - eyesPos.field_72448_b;
/*  82 */     double diffZ = vec.field_72449_c - eyesPos.field_72449_c;
/*  83 */     double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
/*  84 */     float yaw = (float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0F;
/*  85 */     float pitch = (float)-Math.toDegrees(Math.atan2(diffY, diffXZ));
/*  86 */     return new float[] { mc.field_71439_g.field_70177_z + 
/*  87 */         MathHelper.func_76142_g(yaw - mc.field_71439_g.field_70177_z), mc.field_71439_g.field_70125_A + 
/*  88 */         MathHelper.func_76142_g(pitch - mc.field_71439_g.field_70125_A) };
/*     */   }
/*     */   
/*     */   public static void faceVector(Vec3d vec, boolean normalizeAngle) {
/*  92 */     float[] rotations = getLegitRotations(vec);
/*  93 */     mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Rotation(rotations[0], normalizeAngle ? MathHelper.func_180184_b((int)rotations[1], 360) : rotations[1], mc.field_71439_g.field_70122_E));
/*     */   }
/*     */   
/*     */   public static void rightClickBlock(BlockPos pos, Vec3d vec, EnumHand hand, EnumFacing direction, boolean packet) {
/*  97 */     if (packet) {
/*  98 */       float f = (float)(vec.field_72450_a - pos.func_177958_n());
/*  99 */       float f1 = (float)(vec.field_72448_b - pos.func_177956_o());
/* 100 */       float f2 = (float)(vec.field_72449_c - pos.func_177952_p());
/* 101 */       mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerTryUseItemOnBlock(pos, direction, hand, f, f1, f2));
/*     */     } else {
/* 103 */       mc.field_71442_b.func_187099_a(mc.field_71439_g, mc.field_71441_e, pos, direction, vec, hand);
/*     */     } 
/* 105 */     mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
/* 106 */     mc.field_71467_ac = 4;
/*     */   }
/*     */   
/*     */   public static int findHotbarBlock(Class clazz) {
/* 110 */     for (int i = 0; i < 9; i++) {
/* 111 */       ItemStack stack = mc.field_71439_g.field_71071_by.func_70301_a(i);
/* 112 */       if (stack != ItemStack.field_190927_a) {
/* 113 */         if (clazz.isInstance(stack.func_77973_b()))
/* 114 */           return i; 
/* 115 */         if (stack.func_77973_b() instanceof ItemBlock) {
/* 116 */           Block block = ((ItemBlock)stack.func_77973_b()).func_179223_d();
/* 117 */           if (clazz.isInstance(block))
/* 118 */             return i; 
/*     */         } 
/*     */       } 
/*     */     } 
/* 122 */     return -1;
/*     */   }
/*     */   
/*     */   public static void switchToSlot(int slot) {
/* 126 */     mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketHeldItemChange(slot));
/* 127 */     mc.field_71439_g.field_71071_by.field_70461_c = slot;
/* 128 */     mc.field_71442_b.func_78765_e();
/*     */   }
/*     */   
/*     */   public static void switchToHotbarSlot(int slot, boolean silent) {
/* 132 */     if (mc.field_71439_g.field_71071_by.field_70461_c == slot || slot < 0)
/*     */       return; 
/* 134 */     if (silent) {
/* 135 */       mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketHeldItemChange(slot));
/* 136 */       mc.field_71442_b.func_78765_e();
/*     */     } else {
/* 138 */       mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketHeldItemChange(slot));
/* 139 */       mc.field_71439_g.field_71071_by.field_70461_c = slot;
/* 140 */       mc.field_71442_b.func_78765_e();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static int getItemFromHotbar(Item item) {
/* 145 */     int slot = -1;
/* 146 */     for (int i = 0; i < 9; i++) {
/* 147 */       ItemStack stack = Minecraftable.mc.field_71439_g.field_71071_by.func_70301_a(i);
/* 148 */       if (stack.func_77973_b() == item)
/* 149 */         slot = i; 
/*     */     } 
/* 151 */     return slot;
/*     */   }
/*     */   
/*     */   public static int getItemCount(Item item) {
/* 155 */     int count = 0;
/* 156 */     int size = Util.mc.field_71439_g.field_71071_by.field_70462_a.size();
/* 157 */     for (int i = 0; i < size; i++) {
/* 158 */       ItemStack itemStack = (ItemStack)Util.mc.field_71439_g.field_71071_by.field_70462_a.get(i);
/* 159 */       if (itemStack.func_77973_b() == item)
/* 160 */         count += itemStack.func_190916_E(); 
/*     */     } 
/* 162 */     ItemStack offhandStack = Util.mc.field_71439_g.func_184592_cb();
/* 163 */     if (offhandStack.func_77973_b() == item)
/* 164 */       count += offhandStack.func_190916_E(); 
/* 165 */     return count;
/*     */   }
/*     */   
/*     */   public static int getItemSlot(Item item) {
/* 169 */     int itemSlot = -1;
/* 170 */     for (int i = 45; i > 0; i--) {
/* 171 */       if (mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b().equals(item)) {
/* 172 */         itemSlot = i;
/*     */         break;
/*     */       } 
/*     */     } 
/* 176 */     return itemSlot;
/*     */   }
/*     */   
/*     */   public static boolean isArmorUnderPercent(EntityPlayer player, float percent) {
/* 180 */     for (int i = 3; i >= 0; i--) {
/* 181 */       ItemStack stack = (ItemStack)player.field_71071_by.field_70460_b.get(i);
/* 182 */       if (getDamageInPercent(stack) < percent)
/* 183 */         return true; 
/*     */     } 
/* 185 */     return false;
/*     */   }
/*     */   
/*     */   public static float getDamageInPercent(ItemStack stack) {
/* 189 */     float green = ((stack.func_77958_k() - stack.func_77952_i()) / stack.func_77958_k());
/* 190 */     float red = 1.0F - green;
/* 191 */     return (100 - (int)(red * 100.0F));
/*     */   }
/*     */   
/*     */   public static int getBlockFromHotbar(Block block) {
/* 195 */     int slot = -1;
/* 196 */     for (int i = 8; i >= 0; i--) {
/* 197 */       if (mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b() == Item.func_150898_a(block)) {
/* 198 */         slot = i;
/*     */         break;
/*     */       } 
/*     */     } 
/* 202 */     return slot;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\ShitClient\HayBale-1.0.1-b8.jar!\me\luxtix\haybal\\util\ItemUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */