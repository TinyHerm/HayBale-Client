/*     */ package me.luxtix.haybale.util;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketEntityAction;
/*     */ import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.RayTraceResult;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.util.math.Vec3i;
/*     */ 
/*     */ public class TestUtil {
/*  22 */   private static final Minecraft mc = Minecraft.func_71410_x();
/*  23 */   public static List<Block> emptyBlocks = Arrays.asList(new Block[] { Blocks.field_150350_a, (Block)Blocks.field_150356_k, (Block)Blocks.field_150353_l, (Block)Blocks.field_150358_i, (Block)Blocks.field_150355_j, Blocks.field_150395_bd, Blocks.field_150431_aC, (Block)Blocks.field_150329_H, (Block)Blocks.field_150480_ab });
/*  24 */   public static List<Block> rightclickableBlocks = Arrays.asList(new Block[] { (Block)Blocks.field_150486_ae, Blocks.field_150447_bR, Blocks.field_150477_bB, Blocks.field_190977_dl, Blocks.field_190978_dm, Blocks.field_190979_dn, Blocks.field_190980_do, Blocks.field_190981_dp, Blocks.field_190982_dq, Blocks.field_190983_dr, Blocks.field_190984_ds, Blocks.field_190985_dt, Blocks.field_190986_du, Blocks.field_190987_dv, Blocks.field_190988_dw, Blocks.field_190989_dx, Blocks.field_190990_dy, Blocks.field_190991_dz, Blocks.field_190975_dA, Blocks.field_150467_bQ, Blocks.field_150471_bO, Blocks.field_150430_aB, (Block)Blocks.field_150441_bU, (Block)Blocks.field_150413_aR, (Block)Blocks.field_150416_aS, (Block)Blocks.field_150455_bV, Blocks.field_180390_bo, Blocks.field_180391_bp, Blocks.field_180392_bq, Blocks.field_180386_br, Blocks.field_180385_bs, Blocks.field_180387_bt, Blocks.field_150382_bo, Blocks.field_150367_z, Blocks.field_150409_cd, Blocks.field_150442_at, Blocks.field_150323_B, Blocks.field_150421_aI, (Block)Blocks.field_150461_bJ, Blocks.field_150324_C, Blocks.field_150460_al, (Block)Blocks.field_180413_ao, (Block)Blocks.field_180414_ap, (Block)Blocks.field_180412_aq, (Block)Blocks.field_180411_ar, (Block)Blocks.field_180410_as, (Block)Blocks.field_180409_at, Blocks.field_150414_aQ, Blocks.field_150381_bn, Blocks.field_150380_bt, (Block)Blocks.field_150438_bZ, Blocks.field_185776_dc, Blocks.field_150483_bI, Blocks.field_185777_dd, Blocks.field_150462_ai });
/*     */   
/*     */   public static boolean canSeeBlock(BlockPos p_Pos) {
/*  27 */     return (mc.field_71439_g != null && mc.field_71441_e.func_147447_a(new Vec3d(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + mc.field_71439_g.func_70047_e(), mc.field_71439_g.field_70161_v), new Vec3d(p_Pos.func_177958_n(), p_Pos.func_177956_o(), p_Pos.func_177952_p()), false, true, false) == null);
/*     */   }
/*     */   
/*     */   public static void placeCrystalOnBlock(BlockPos pos, EnumHand hand) {
/*  31 */     RayTraceResult result = mc.field_71441_e.func_72933_a(new Vec3d(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + mc.field_71439_g.func_70047_e(), mc.field_71439_g.field_70161_v), new Vec3d(pos.func_177958_n() + 0.5D, pos.func_177956_o() - 0.5D, pos.func_177952_p() + 0.5D));
/*  32 */     EnumFacing facing = (result == null || result.field_178784_b == null) ? EnumFacing.UP : result.field_178784_b;
/*  33 */     mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerTryUseItemOnBlock(pos, facing, hand, 0.0F, 0.0F, 0.0F));
/*     */   }
/*     */   
/*     */   public static boolean rayTracePlaceCheck(BlockPos pos, boolean shouldCheck, float height) {
/*  37 */     return (!shouldCheck || mc.field_71441_e.func_147447_a(new Vec3d(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + mc.field_71439_g.func_70047_e(), mc.field_71439_g.field_70161_v), new Vec3d(pos.func_177958_n(), (pos.func_177956_o() + height), pos.func_177952_p()), false, true, false) == null);
/*     */   }
/*     */   
/*     */   public static boolean rayTracePlaceCheck(BlockPos pos, boolean shouldCheck) {
/*  41 */     return rayTracePlaceCheck(pos, shouldCheck, 1.0F); } public static void openBlock(BlockPos pos) {
/*     */     EnumFacing[] facings;
/*     */     EnumFacing[] arrayOfEnumFacing1;
/*     */     int i;
/*     */     byte b;
/*  46 */     for (arrayOfEnumFacing1 = facings = EnumFacing.values(), i = arrayOfEnumFacing1.length, b = 0; b < i; ) { EnumFacing f = arrayOfEnumFacing1[b];
/*  47 */       Block neighborBlock = mc.field_71441_e.func_180495_p(pos.func_177972_a(f)).func_177230_c();
/*  48 */       if (!emptyBlocks.contains(neighborBlock)) { b++; continue; }
/*  49 */        mc.field_71442_b.func_187099_a(mc.field_71439_g, mc.field_71441_e, pos, f.func_176734_d(), new Vec3d((Vec3i)pos), EnumHand.MAIN_HAND);
/*     */       return; }
/*     */   
/*     */   }
/*     */   
/*     */   public static boolean placeBlock(BlockPos pos) {
/*  55 */     if (isBlockEmpty(pos)) {
/*     */       EnumFacing[] facings; EnumFacing[] arrayOfEnumFacing1; int i; byte b;
/*  57 */       for (arrayOfEnumFacing1 = facings = EnumFacing.values(), i = arrayOfEnumFacing1.length, b = 0; b < i; ) { EnumFacing f = arrayOfEnumFacing1[b];
/*  58 */         Block neighborBlock = mc.field_71441_e.func_180495_p(pos.func_177972_a(f)).func_177230_c();
/*  59 */         Vec3d vec = new Vec3d(pos.func_177958_n() + 0.5D + f.func_82601_c() * 0.5D, pos.func_177956_o() + 0.5D + f.func_96559_d() * 0.5D, pos.func_177952_p() + 0.5D + f.func_82599_e() * 0.5D);
/*  60 */         if (emptyBlocks.contains(neighborBlock) || mc.field_71439_g.func_174824_e(mc.func_184121_ak()).func_72438_d(vec) > 4.25D) {
/*     */           b++; continue;
/*  62 */         }  float[] rot = { mc.field_71439_g.field_70177_z, mc.field_71439_g.field_70125_A };
/*  63 */         if (rightclickableBlocks.contains(neighborBlock)) {
/*  64 */           mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketEntityAction((Entity)mc.field_71439_g, CPacketEntityAction.Action.START_SNEAKING));
/*     */         }
/*  66 */         mc.field_71442_b.func_187099_a(mc.field_71439_g, mc.field_71441_e, pos.func_177972_a(f), f.func_176734_d(), new Vec3d((Vec3i)pos), EnumHand.MAIN_HAND);
/*  67 */         if (rightclickableBlocks.contains(neighborBlock)) {
/*  68 */           mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketEntityAction((Entity)mc.field_71439_g, CPacketEntityAction.Action.STOP_SNEAKING));
/*     */         }
/*  70 */         mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
/*  71 */         return true; }
/*     */     
/*     */     } 
/*  74 */     return false;
/*     */   }
/*     */   
/*     */   public static boolean isBlockEmpty(BlockPos pos) {
/*     */     try {
/*  79 */       if (emptyBlocks.contains(mc.field_71441_e.func_180495_p(pos).func_177230_c()))
/*     */       
/*  81 */       { AxisAlignedBB box = new AxisAlignedBB(pos);
/*  82 */         Iterator<Entity> entityIter = mc.field_71441_e.field_72996_f.iterator();
/*     */         while (true)
/*  84 */         { if (entityIter.hasNext())
/*     */           { Entity e;
/*  86 */             if (e = entityIter.next() instanceof net.minecraft.entity.EntityLivingBase && box.func_72326_a(e.func_174813_aQ()))
/*     */               break;  continue; }  return true; }  } 
/*  88 */     } catch (Exception exception) {}
/*     */ 
/*     */     
/*  91 */     return false;
/*     */   }
/*     */   
/*     */   public static boolean canPlaceBlock(BlockPos pos) {
/*  95 */     if (isBlockEmpty(pos)) {
/*     */       EnumFacing[] facings;
/*  97 */       for (EnumFacing f : facings = EnumFacing.values()) {
/*  98 */         if (!emptyBlocks.contains(mc.field_71441_e.func_180495_p(pos.func_177972_a(f)).func_177230_c())) {
/*  99 */           Vec3d vec3d = new Vec3d(pos.func_177958_n() + 0.5D + f.func_82601_c() * 0.5D, pos.func_177956_o() + 0.5D + f.func_96559_d() * 0.5D, pos.func_177952_p() + 0.5D + f.func_82599_e() * 0.5D);
/* 100 */           if (mc.field_71439_g.func_174824_e(mc.func_184121_ak()).func_72438_d(vec3d) <= 4.25D)
/*     */           {
/* 102 */             return true; } 
/*     */         } 
/*     */       } 
/* 105 */     }  return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\ShitClient\HayBale-1.0.1-b8.jar!\me\luxtix\haybal\\util\TestUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */