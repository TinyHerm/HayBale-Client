/*    */ package me.luxtix.haybale.manager;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.concurrent.Executors;
/*    */ import java.util.concurrent.ScheduledExecutorService;
/*    */ import java.util.concurrent.TimeUnit;
/*    */ import java.util.concurrent.atomic.AtomicBoolean;
/*    */ import me.luxtix.haybale.features.Feature;
/*    */ import me.luxtix.haybale.features.modules.client.Managers;
/*    */ import me.luxtix.haybale.features.modules.combat.AutoCrystal;
/*    */ import me.luxtix.haybale.util.BlockUtil;
/*    */ import me.luxtix.haybale.util.DamageUtil;
/*    */ import me.luxtix.haybale.util.EntityUtil;
/*    */ import me.luxtix.haybale.util.Timer;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SafetyManager
/*    */   extends Feature
/*    */   implements Runnable
/*    */ {
/* 25 */   private final Timer syncTimer = new Timer();
/* 26 */   private final AtomicBoolean SAFE = new AtomicBoolean(false);
/*    */   
/*    */   private ScheduledExecutorService service;
/*    */ 
/*    */   
/*    */   public void run() {
/* 32 */     if (AutoCrystal.getInstance().isOff() || (AutoCrystal.getInstance()).threadMode.getValue() == AutoCrystal.ThreadMode.NONE) {
/* 33 */       doSafetyCheck();
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void doSafetyCheck() {
/* 39 */     if (!fullNullCheck()) {
/*    */       
/* 41 */       boolean safe = true;
/* 42 */       EntityPlayer closest = ((Boolean)(Managers.getInstance()).safety.getValue()).booleanValue() ? EntityUtil.getClosestEnemy(18.0D) : null;
/* 43 */       if (((Boolean)(Managers.getInstance()).safety.getValue()).booleanValue() && closest == null) {
/* 44 */         this.SAFE.set(true);
/*    */         return;
/*    */       } 
/* 47 */       ArrayList<Entity> crystals = new ArrayList<>(mc.field_71441_e.field_72996_f);
/* 48 */       for (Entity crystal : crystals) {
/* 49 */         if (!(crystal instanceof net.minecraft.entity.item.EntityEnderCrystal) || DamageUtil.calculateDamage(crystal, (Entity)mc.field_71439_g) <= 4.0D || (closest != null && closest.func_70068_e(crystal) >= 40.0D))
/*    */           continue; 
/* 51 */         safe = false;
/*    */       } 
/*    */       
/* 54 */       if (safe) {
/* 55 */         for (BlockPos pos : BlockUtil.possiblePlacePositions(4.0F, false, ((Boolean)(Managers.getInstance()).oneDot15.getValue()).booleanValue())) {
/* 56 */           if (DamageUtil.calculateDamage(pos, (Entity)mc.field_71439_g) <= 4.0D || (closest != null && closest.func_174818_b(pos) >= 40.0D))
/*    */             continue; 
/* 58 */           safe = false;
/*    */         } 
/*    */       }
/*    */       
/* 62 */       this.SAFE.set(safe);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void onUpdate() {
/* 68 */     run();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getSafetyString() {
/* 73 */     if (this.SAFE.get()) {
/* 74 */       return "§aSecure";
/*    */     }
/* 76 */     return "§cUnsafe";
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isSafe() {
/* 81 */     return this.SAFE.get();
/*    */   }
/*    */ 
/*    */   
/*    */   public ScheduledExecutorService getService() {
/* 86 */     ScheduledExecutorService service = Executors.newSingleThreadScheduledExecutor();
/* 87 */     service.scheduleAtFixedRate(this, 0L, ((Integer)(Managers.getInstance()).safetyCheck.getValue()).intValue(), TimeUnit.MILLISECONDS);
/* 88 */     return service;
/*    */   }
/*    */ }


/* Location:              C:\Users\Administrator\Desktop\ShitClient\HayBale-1.0.1-b8.jar!\me\luxtix\haybale\manager\SafetyManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */