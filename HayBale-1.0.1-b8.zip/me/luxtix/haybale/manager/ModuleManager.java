/*     */ package me.luxtix.haybale.manager;
/*     */ import java.awt.Color;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.stream.Collectors;
/*     */ import me.luxtix.haybale.event.events.Render2DEvent;
/*     */ import me.luxtix.haybale.event.events.Render3DEvent;
/*     */ import me.luxtix.haybale.features.Feature;
/*     */ import me.luxtix.haybale.features.modules.Module;
/*     */ import me.luxtix.haybale.features.modules.client.Colors;
/*     */ import me.luxtix.haybale.features.modules.client.Media;
/*     */ import me.luxtix.haybale.features.modules.combat.AutoCrystal;
/*     */ import me.luxtix.haybale.features.modules.combat.Criticals;
/*     */ import me.luxtix.haybale.features.modules.combat.Selftrap;
/*     */ import me.luxtix.haybale.features.modules.combat.Surround;
/*     */ import me.luxtix.haybale.features.modules.misc.AutoLog;
/*     */ import me.luxtix.haybale.features.modules.misc.AutoReconnect;
/*     */ import me.luxtix.haybale.features.modules.misc.RPC;
/*     */ import me.luxtix.haybale.features.modules.movement.Velocity;
/*     */ import me.luxtix.haybale.features.modules.player.FakePlayer;
/*     */ import me.luxtix.haybale.features.modules.player.Freecam;
/*     */ import me.luxtix.haybale.features.modules.player.LiquidInteract;
/*     */ import me.luxtix.haybale.features.modules.render.ESP;
/*     */ import me.luxtix.haybale.features.modules.render.Fullbright;
/*     */ import net.minecraftforge.common.MinecraftForge;
/*     */ 
/*     */ public class ModuleManager extends Feature {
/*  28 */   public ArrayList<Module> modules = new ArrayList<>();
/*  29 */   public List<Module> sortedModules = new ArrayList<>();
/*  30 */   public List<Module> alphabeticallySortedModules = new ArrayList<>();
/*  31 */   public Map<Module, Color> moduleColorMap = new HashMap<>();
/*     */   
/*     */   public void init() {
/*  34 */     this.modules.add(new OffhandRW());
/*  35 */     this.modules.add(new Surround());
/*  36 */     this.modules.add(new BedAura());
/*  37 */     this.modules.add(new Swing());
/*  38 */     this.modules.add(new Yport());
/*  39 */     this.modules.add(new Flatten());
/*  40 */     this.modules.add(new Quiver());
/*  41 */     this.modules.add(new SilentXp());
/*  42 */     this.modules.add(new SelfAnvil());
/*  43 */     this.modules.add(new CrystalScale());
/*  44 */     this.modules.add(new AutoTrap());
/*  45 */     this.modules.add(new AutoCrystal());
/*  46 */     this.modules.add(new Criticals());
/*  47 */     this.modules.add(new Killaura());
/*  48 */     this.modules.add(new Selftrap());
/*  49 */     this.modules.add(new HandColor());
/*  50 */     this.modules.add(new Webaura());
/*  51 */     this.modules.add(new AutoArmor());
/*  52 */     this.modules.add(new ChatModifier());
/*  53 */     this.modules.add(new NoRotate());
/*  54 */     this.modules.add(new MCF());
/*  55 */     this.modules.add(new NoSoundLag());
/*  56 */     this.modules.add(new AutoLog());
/*  57 */     this.modules.add(new AutoReconnect());
/*  58 */     this.modules.add(new RPC());
/*  59 */     this.modules.add(new StepRW());
/*  60 */     this.modules.add(new ReverseStep());
/*  61 */     this.modules.add(new Strafe());
/*  62 */     this.modules.add(new Velocity());
/*  63 */     this.modules.add(new Speed());
/*  64 */     this.modules.add(new Step());
/*  65 */     this.modules.add(new Phase());
/*  66 */     this.modules.add(new NoSlowDown());
/*  67 */     this.modules.add(new HoleTP());
/*  68 */     this.modules.add(new NoFall());
/*  69 */     this.modules.add(new InstantSelfFill());
/*  70 */     this.modules.add(new LiquidInteract());
/*  71 */     this.modules.add(new FakePlayer());
/*  72 */     this.modules.add(new FastPlace());
/*  73 */     this.modules.add(new Freecam());
/*  74 */     this.modules.add(new Speedmine());
/*  75 */     this.modules.add(new Blink());
/*  76 */     this.modules.add(new MultiTask());
/*  77 */     this.modules.add(new NoRender());
/*  78 */     this.modules.add(new Fullbright());
/*  79 */     this.modules.add(new Chams());
/*  80 */     this.modules.add(new ESP());
/*  81 */     this.modules.add(new HoleESP());
/*  82 */     this.modules.add(new BlockHighlight());
/*  83 */     this.modules.add(new Trajectories());
/*  84 */     this.modules.add(new Tracer());
/*  85 */     this.modules.add(new LogoutSpots());
/*  86 */     this.modules.add(new OffscreenESP());
/*  87 */     this.modules.add(new Cosmetics());
/*  88 */     this.modules.add(new Notifications());
/*  89 */     this.modules.add(new HUD());
/*  90 */     this.modules.add(new ToolTips());
/*  91 */     this.modules.add(new FontMod());
/*  92 */     this.modules.add(new ClickGui());
/*  93 */     this.modules.add(new Managers());
/*  94 */     this.modules.add(new Components());
/*  95 */     this.modules.add(new Capes());
/*  96 */     this.modules.add(new Colors());
/*  97 */     this.modules.add(new ServerModule());
/*  98 */     this.modules.add(new Screens());
/*  99 */     this.modules.add(new Media());
/* 100 */     this.modules.add(new Aspect());
/* 101 */     this.moduleColorMap.put((Module)getModuleByClass(Auto32k.class), new Color(185, 212, 144));
/* 102 */     this.moduleColorMap.put((Module)getModuleByClass(AutoArmor.class), new Color(74, 227, 206));
/* 103 */     this.moduleColorMap.put((Module)getModuleByClass(AutoCrystal.class), new Color(255, 15, 43));
/* 104 */     this.moduleColorMap.put((Module)getModuleByClass(AutoTrap.class), new Color(193, 49, 244));
/* 105 */     this.moduleColorMap.put((Module)getModuleByClass(Criticals.class), new Color(204, 151, 184));
/* 106 */     this.moduleColorMap.put((Module)getModuleByClass(Killaura.class), new Color(255, 37, 0));
/* 107 */     this.moduleColorMap.put((Module)getModuleByClass(Offhand.class), new Color(185, 212, 144));
/* 108 */     this.moduleColorMap.put((Module)getModuleByClass(Selftrap.class), new Color(22, 127, 145));
/* 109 */     this.moduleColorMap.put((Module)getModuleByClass(Surround.class), new Color(100, 0, 150));
/* 110 */     this.moduleColorMap.put((Module)getModuleByClass(Webaura.class), new Color(11, 161, 121));
/* 111 */     this.moduleColorMap.put((Module)getModuleByClass(AutoLog.class), new Color(176, 176, 176));
/* 112 */     this.moduleColorMap.put((Module)getModuleByClass(AutoReconnect.class), new Color(17, 85, 153));
/* 113 */     this.moduleColorMap.put((Module)getModuleByClass(ChatModifier.class), new Color(255, 59, 216));
/* 114 */     this.moduleColorMap.put((Module)getModuleByClass(Godmode.class), new Color(1, 35, 95));
/* 115 */     this.moduleColorMap.put((Module)getModuleByClass(MCF.class), new Color(17, 85, 255));
/* 116 */     this.moduleColorMap.put((Module)getModuleByClass(NoRotate.class), new Color(69, 81, 223));
/* 117 */     this.moduleColorMap.put((Module)getModuleByClass(NoSoundLag.class), new Color(255, 56, 0));
/* 118 */     this.moduleColorMap.put((Module)getModuleByClass(RPC.class), new Color(0, 64, 255));
/* 119 */     this.moduleColorMap.put((Module)getModuleByClass(ToolTips.class), new Color(209, 125, 156));
/* 120 */     this.moduleColorMap.put((Module)getModuleByClass(OffscreenESP.class), new Color(193, 219, 20));
/* 121 */     this.moduleColorMap.put((Module)getModuleByClass(BlockHighlight.class), new Color(103, 182, 224));
/* 122 */     this.moduleColorMap.put((Module)getModuleByClass(Chams.class), new Color(34, 152, 34));
/* 123 */     this.moduleColorMap.put((Module)getModuleByClass(ESP.class), new Color(255, 27, 155));
/* 124 */     this.moduleColorMap.put((Module)getModuleByClass(Fullbright.class), new Color(255, 164, 107));
/* 125 */     this.moduleColorMap.put((Module)getModuleByClass(HandColor.class), new Color(96, 138, 92));
/* 126 */     this.moduleColorMap.put((Module)getModuleByClass(HoleESP.class), new Color(95, 83, 130));
/* 127 */     this.moduleColorMap.put((Module)getModuleByClass(LogoutSpots.class), new Color(2, 135, 134));
/* 128 */     this.moduleColorMap.put((Module)getModuleByClass(Nametags.class), new Color(98, 82, 223));
/* 129 */     this.moduleColorMap.put((Module)getModuleByClass(NoRender.class), new Color(255, 164, 107));
/* 130 */     this.moduleColorMap.put((Module)getModuleByClass(SmallShield.class), new Color(145, 223, 187));
/* 131 */     this.moduleColorMap.put((Module)getModuleByClass(Tracer.class), new Color(255, 107, 107));
/* 132 */     this.moduleColorMap.put((Module)getModuleByClass(Trajectories.class), new Color(98, 18, 223));
/* 133 */     this.moduleColorMap.put((Module)getModuleByClass(XRay.class), new Color(217, 118, 37));
/* 134 */     this.moduleColorMap.put((Module)getModuleByClass(ElytraFlight.class), new Color(55, 161, 201));
/* 135 */     this.moduleColorMap.put((Module)getModuleByClass(HoleTP.class), new Color(68, 178, 142));
/* 136 */     this.moduleColorMap.put((Module)getModuleByClass(NoFall.class), new Color(61, 204, 78));
/* 137 */     this.moduleColorMap.put((Module)getModuleByClass(NoSlowDown.class), new Color(61, 204, 78));
/* 138 */     this.moduleColorMap.put((Module)getModuleByClass(Phase.class), new Color(186, 144, 212));
/* 139 */     this.moduleColorMap.put((Module)getModuleByClass(Speed.class), new Color(55, 161, 196));
/* 140 */     this.moduleColorMap.put((Module)getModuleByClass(Step.class), new Color(144, 212, 203));
/* 141 */     this.moduleColorMap.put((Module)getModuleByClass(Strafe.class), new Color(0, 204, 255));
/* 142 */     this.moduleColorMap.put((Module)getModuleByClass(Velocity.class), new Color(115, 134, 140));
/* 143 */     this.moduleColorMap.put((Module)getModuleByClass(ReverseStep.class), new Color(1, 134, 140));
/* 144 */     this.moduleColorMap.put((Module)getModuleByClass(NoDDoS.class), new Color(67, 191, 181));
/* 145 */     this.moduleColorMap.put((Module)getModuleByClass(Blink.class), new Color(144, 184, 141));
/* 146 */     this.moduleColorMap.put((Module)getModuleByClass(FakePlayer.class), new Color(37, 192, 170));
/* 147 */     this.moduleColorMap.put((Module)getModuleByClass(FastPlace.class), new Color(217, 118, 37));
/* 148 */     this.moduleColorMap.put((Module)getModuleByClass(Freecam.class), new Color(206, 232, 128));
/* 149 */     this.moduleColorMap.put((Module)getModuleByClass(LiquidInteract.class), new Color(85, 223, 235));
/* 150 */     this.moduleColorMap.put((Module)getModuleByClass(MultiTask.class), new Color(17, 223, 235));
/* 151 */     this.moduleColorMap.put((Module)getModuleByClass(Speedmine.class), new Color(152, 166, 113));
/* 152 */     this.moduleColorMap.put((Module)getModuleByClass(TimerSpeed.class), new Color(255, 133, 18));
/* 153 */     this.moduleColorMap.put((Module)getModuleByClass(Capes.class), new Color(26, 135, 104));
/* 154 */     this.moduleColorMap.put((Module)getModuleByClass(ClickGui.class), new Color(26, 81, 135));
/* 155 */     this.moduleColorMap.put((Module)getModuleByClass(Colors.class), new Color(135, 133, 26));
/* 156 */     this.moduleColorMap.put((Module)getModuleByClass(Components.class), new Color(135, 26, 26));
/* 157 */     this.moduleColorMap.put((Module)getModuleByClass(FontMod.class), new Color(135, 26, 88));
/* 158 */     this.moduleColorMap.put((Module)getModuleByClass(HUD.class), new Color(110, 26, 135));
/* 159 */     this.moduleColorMap.put((Module)getModuleByClass(Managers.class), new Color(26, 90, 135));
/* 160 */     this.moduleColorMap.put((Module)getModuleByClass(Notifications.class), new Color(170, 153, 255));
/* 161 */     this.moduleColorMap.put((Module)getModuleByClass(ServerModule.class), new Color(60, 110, 175));
/* 162 */     this.moduleColorMap.put((Module)getModuleByClass(Media.class), new Color(138, 45, 13));
/* 163 */     this.moduleColorMap.put((Module)getModuleByClass(Screens.class), new Color(165, 89, 101));
/* 164 */     for (Module module : this.modules) {
/* 165 */       module.animation.start();
/*     */     }
/*     */   }
/*     */   
/*     */   public Module getModuleByName(String name) {
/* 170 */     for (Module module : this.modules) {
/* 171 */       if (!module.getName().equalsIgnoreCase(name))
/* 172 */         continue;  return module;
/*     */     } 
/* 174 */     return null;
/*     */   }
/*     */   
/*     */   public <T extends Module> T getModuleByClass(Class<T> clazz) {
/* 178 */     for (Module module : this.modules) {
/* 179 */       if (!clazz.isInstance(module))
/* 180 */         continue;  return (T)module;
/*     */     } 
/* 182 */     return null;
/*     */   }
/*     */   
/*     */   public void enableModule(Class<Module> clazz) {
/* 186 */     Object module = getModuleByClass(clazz);
/* 187 */     if (module != null) {
/* 188 */       ((Module)module).enable();
/*     */     }
/*     */   }
/*     */   
/*     */   public void disableModule(Class<Module> clazz) {
/* 193 */     Object module = getModuleByClass(clazz);
/* 194 */     if (module != null) {
/* 195 */       ((Module)module).disable();
/*     */     }
/*     */   }
/*     */   
/*     */   public void enableModule(String name) {
/* 200 */     Module module = getModuleByName(name);
/* 201 */     if (module != null) {
/* 202 */       module.enable();
/*     */     }
/*     */   }
/*     */   
/*     */   public void disableModule(String name) {
/* 207 */     Module module = getModuleByName(name);
/* 208 */     if (module != null) {
/* 209 */       module.disable();
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isModuleEnabled(String name) {
/* 214 */     Module module = getModuleByName(name);
/* 215 */     return (module != null && module.isOn());
/*     */   }
/*     */   
/*     */   public boolean isModuleEnabled(Class<Module> clazz) {
/* 219 */     Object module = getModuleByClass(clazz);
/* 220 */     return (module != null && ((Module)module).isOn());
/*     */   }
/*     */   
/*     */   public Module getModuleByDisplayName(String displayName) {
/* 224 */     for (Module module : this.modules) {
/* 225 */       if (!module.getDisplayName().equalsIgnoreCase(displayName))
/* 226 */         continue;  return module;
/*     */     } 
/* 228 */     return null;
/*     */   }
/*     */   
/*     */   public ArrayList<Module> getEnabledModules() {
/* 232 */     ArrayList<Module> enabledModules = new ArrayList<>();
/* 233 */     for (Module module : this.modules) {
/* 234 */       if (!module.isEnabled() && !module.isSliding())
/* 235 */         continue;  enabledModules.add(module);
/*     */     } 
/* 237 */     return enabledModules;
/*     */   }
/*     */   
/*     */   public ArrayList<Module> getModulesByCategory(Module.Category category) {
/* 241 */     ArrayList<Module> modulesCategory = new ArrayList<>();
/* 242 */     this.modules.forEach(module -> {
/*     */           if (module.getCategory() == category) {
/*     */             modulesCategory.add(module);
/*     */           }
/*     */         });
/* 247 */     return modulesCategory;
/*     */   }
/*     */   
/*     */   public List<Module.Category> getCategories() {
/* 251 */     return Arrays.asList(Module.Category.values());
/*     */   }
/*     */   
/*     */   public void onLoad() {
/* 255 */     this.modules.stream().filter(Module::listening).forEach(MinecraftForge.EVENT_BUS::register);
/* 256 */     this.modules.forEach(Module::onLoad);
/*     */   }
/*     */   
/*     */   public void onUpdate() {
/* 260 */     this.modules.stream().filter(Feature::isEnabled).forEach(Module::onUpdate);
/*     */   }
/*     */   
/*     */   public void onTick() {
/* 264 */     this.modules.stream().filter(Feature::isEnabled).forEach(Module::onTick);
/*     */   }
/*     */   
/*     */   public void onRender2D(Render2DEvent event) {
/* 268 */     this.modules.stream().filter(Feature::isEnabled).forEach(module -> module.onRender2D(event));
/*     */   }
/*     */   
/*     */   public void onRender3D(Render3DEvent event) {
/* 272 */     this.modules.stream().filter(Feature::isEnabled).forEach(module -> module.onRender3D(event));
/*     */   }
/*     */   
/*     */   public void sortModules(boolean reverse) {
/* 276 */     this.sortedModules = (List<Module>)getEnabledModules().stream().filter(Module::isDrawn).sorted(Comparator.comparing(module -> Integer.valueOf(this.renderer.getStringWidth(module.getFullArrayString()) * (reverse ? -1 : 1)))).collect(Collectors.toList());
/*     */   }
/*     */   
/*     */   public void alphabeticallySortModules() {
/* 280 */     this.alphabeticallySortedModules = (List<Module>)getEnabledModules().stream().filter(Module::isDrawn).sorted(Comparator.comparing(Module::getDisplayName)).collect(Collectors.toList());
/*     */   }
/*     */   
/*     */   public void onLogout() {
/* 284 */     this.modules.forEach(Module::onLogout);
/*     */   }
/*     */   
/*     */   public void onLogin() {
/* 288 */     this.modules.forEach(Module::onLogin);
/*     */   }
/*     */   
/*     */   public void onUnload() {
/* 292 */     this.modules.forEach(MinecraftForge.EVENT_BUS::unregister);
/* 293 */     this.modules.forEach(Module::onUnload);
/*     */   }
/*     */   
/*     */   public void onUnloadPost() {
/* 297 */     for (Module module : this.modules) {
/* 298 */       module.enabled.setValue(Boolean.valueOf(false));
/*     */     }
/*     */   }
/*     */   
/*     */   public void onKeyPressed(int eventKey) {
/* 303 */     if (eventKey == 0 || !Keyboard.getEventKeyState() || mc.field_71462_r instanceof me.luxtix.haybale.features.gui.PhobosGui) {
/*     */       return;
/*     */     }
/* 306 */     this.modules.forEach(module -> {
/*     */           if (module.getBind().getKey() == eventKey) {
/*     */             module.toggle();
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   public List<Module> getAnimationModules(Module.Category category) {
/* 314 */     ArrayList<Module> animationModules = new ArrayList<>();
/* 315 */     for (Module module : getEnabledModules()) {
/* 316 */       if (module.getCategory() != category || module.isDisabled() || !module.isSliding() || !module.isDrawn())
/*     */         continue; 
/* 318 */       animationModules.add(module);
/*     */     } 
/* 320 */     return animationModules;
/*     */   }
/*     */ }


/* Location:              C:\Users\Administrator\Desktop\ShitClient\HayBale-1.0.1-b8.jar!\me\luxtix\haybale\manager\ModuleManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */