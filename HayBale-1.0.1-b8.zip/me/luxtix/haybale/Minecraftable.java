/*   */ package me.luxtix.haybale;
/*   */ 
/*   */ import net.minecraft.client.Minecraft;
/*   */ 
/*   */ public interface Minecraftable {
/* 6 */   public static final Minecraft mc = Minecraft.func_71410_x();
/*   */ }


/* Location:              C:\Users\Administrator\Desktop\ShitClient\HayBale-1.0.1-b8.jar!\me\luxtix\haybale\Minecraftable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */